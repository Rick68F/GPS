#ifndef __MAPINFO_HPP__
#define __MAPINFO_HPP__

#include <string>
#include <memory>
#include <fstream>
#include <map>
#include <vector>

#include "Dico.hpp"
#include "commun.hpp"
//#define SDMMC 1

#ifdef ARDUINO
#ifdef SDMMC
#include "SD_MMC.h"
#else
#include <SD.h>
#endif
#endif

// #include "header/dictionary.hpp"
// #include "cache.hpp"

// #include "geometry.hpp"
#include "mapsforge_map_info.hpp"
#include "header/VectorTile.h"
#include "header/TileId.h"
#include "header/QueryParameters.h"
#include "header/BoundingBox.hpp"
#include "header/MercatorProjection.h"

// #include <boost/optional.hpp>
// #include <boost/thread/mutex.hpp>

// #define TAG_KEY_NAME "name"
// #define TAG_KEY_HOUSE_NUMBER "addr:housenumber"
// #define TAG_KEY_ELE "ele"
// #define TAG_KEY_REF "ref"

static const std::string DEBUG_SIGNATURE_BLOCK;                      // Debug message prefix for the block signature.
static const std::string DEBUG_SIGNATURE_POI;                        // Debug message prefix for the POI signature.
static const std::string DEBUG_SIGNATURE_WAY;                        // Debug message prefix for the way signature.
static const int INDEX_CACHE_SIZE = 64;                              // Amount of cache blocks that the index cache should store.
static const std::string INVALID_FIRST_WAY_OFFSET;                   // Error message for an invalid first way offset.
static const int MAXIMUM_WAY_NODES_SEQUENCE_LENGTH = 8192;           // Maximum way nodes sequence length which is considered as valid.
static const int POI_FEATURE_ELEVATION = 0x20;                       // Bitmask for the optional POI feature "elevation".
static const int POI_FEATURE_HOUSE_NUMBER = 0x40;                    // Bitmask for the optional POI feature "house number".
static const int POI_FEATURE_NAME = 0x80;                            // Bitmask for the optional POI feature "name".
static const int POI_LAYER_BITMASK = 0xf0;                           // Bitmask for the POI layer.
static const int POI_LAYER_SHIFT = 4;                                // Bit shift for calculating the POI layer.
static const int POI_NUMBER_OF_TAGS_BITMASK = 0x0f;                  // Bitmask for the number of POI tags.
static const int8_t SIGNATURE_LENGTH_BLOCK = 32;                     // Length of the debug signature at the beginning of each block.
static const int8_t SIGNATURE_LENGTH_POI = 32;                       // Length of the debug signature at the beginning of each POI.
static const int8_t SIGNATURE_LENGTH_WAY = 32;                       // Length of the debug signature at the beginning of each way.
static const std::string TAG_KEY_ELE = "ele";                        // The key of the elevation OpenStreetMap tag.
static const std::string TAG_KEY_HOUSE_NUMBER = "addr:housenumber";  // The key of the house number OpenStreetMap tag.
static const std::string TAG_KEY_NAME = "name";                      // The key of the name OpenStreetMap tag.
static const std::string TAG_KEY_REF = "ref";                        //The key of the reference OpenStreetMap tag.
static const int WAY_FEATURE_DATA_BLOCKS_BYTE = 0x08;                // Bitmask for the optional way data blocks byte.
static const int WAY_FEATURE_DOUBLE_DELTA_ENCODING = 0x04;           // Bitmask for the optional way double delta encoding.
static const int WAY_FEATURE_HOUSE_NUMBER = 0x40;                    // Bitmask for the optional way feature "house number".
static const int WAY_FEATURE_LABEL_POSITION = 0x10;                  // Bitmask for the optional way feature "label position".
static const int WAY_FEATURE_NAME = 0x80;                            // Bitmask for the optional way feature "name".
static const int WAY_FEATURE_REF = 0x20;                             // Bitmask for the optional way feature "reference".
static const int WAY_LAYER_BITMASK = 0xf0;                           // Bitmask for the way layer.
static const int WAY_LAYER_SHIFT = 4;                                // Bit shift for calculating the way layer.
static const int WAY_NUMBER_OF_TAGS_BITMASK = 0x0f;                  // Bitmask for the number of way tags.

std::vector<Tag> wayTags;
std::vector<Tag> poiTags;

#ifdef READBUFFER
static const int MAXIMUM_BUFFER_SIZE = 2500000;
uint8_t *m_bufferData;
int m_bufferData_length;
int m_bufferPosition;
#endif

class MapFileReader;
// class ReadBuffer;

// typedef std::tuple<uint32_t, uint32_t, uint8_t, MapFileReader *> cache_key_type;  // the tile is encoded by its index and a dataset id
// typedef std::shared_ptr<TileData> cache_value_type;
// typedef Cache<cache_key_type, cache_value_type> TileIndex;

class MapFileReader {
public:

  MapFileReader() {}

  /**
     * Opens map file, reads map info and create tile index
     *
     * @throws ReadException on error
     *
     */

  void open(const std::string &file_path);

  ~MapFileReader() {}

  const MapFileInfo &getMapFileInfo() const {
    return info_;
  }


  /**
	 * Reads all map data for the area covered by the given tile at the tile zoom level.
	 * 
	 * @param tile
	 *            defines area and zoom level of read map data.
	 * @return the read map data.
	 */
  VectorTile readMapData(const TileId &tile);

  // read tile data corresponding to given tile key +- offset around it

  //  VectorTile readTile(const TileKey &, int offset = 1);

  // initializes a global in-memory a tile cache to be shared among instances of readers

  static void initTileCache(uint64_t bytes);
  void dbg_way_tags();
  void dbg_poi_tags();
  void dbg_tiles_dump();
  void check_tuile();

  struct SubFileInfo {
    uint8_t base_zoom_;
    uint8_t min_zoom_;
    uint8_t max_zoom_;

#ifdef ARDUINO
    uint32_t offset_, size_;
    std::vector<int32_t> index_;  // tile offsets
#else
    uint64_t offset_, size_;
    std::vector<int64_t> index_;  // tile offsets
#endif
    int32_t min_tx_, min_ty_, max_tx_, max_ty_;  // range of tiles corresponding to the index
    int32_t rows_s_y, cols_s_x;
  };

  struct Foo {
    unsigned int numberOfPois;
    unsigned int numberOfWays;
  };

private:
  // bufferization

  int getBufferSize() const;

  void readTiles();
  void readHeader();
  void readMapInfo();
  void readTagList(std::vector<std::string> &tags);
  void readTagListData(std::vector<Tag> &tags, DICO_WAYS_AND_POIS *&ptr_diko);
  void readSubFileInfo();
  void readTileIndex();

  int8_t getQueryZoomLevel(int8_t zoomLevel);
  static QueryParameters calculateBlocks(const TileId &tile, const BoundingBox &bbox, int zoomLevel, int physicalZoomLevel);
  void decodeWayNodesDoubleDelta(std::vector<GeoPoint> &waySegment, const LatLong &tileCoordinates);
  void decodeWayNodesSingleDelta(std::vector<GeoPoint> &waySegment, const LatLong &tileCoordinates);
  void logDebugSignatures();  // Logs the debug signatures of the current way and block.

  // VectorTile readVectorTile(const QueryParameters &queryParameters, const SubFileParameter &subFileParameter, const LatLong &tileCoordinates);
  VectorTile readVectorTile(const QueryParameters &queryParameters, const MapFileReader::SubFileInfo &subFileParameter, const LatLong &tileCoordinates);
  std::list<PointOfInterest> processPOIs(int numberOfPois, const LatLong &tileCoordinates);
  std::vector< std::vector<GeoPoint> > processWayDataBlock(bool doubleDeltaEncoding, const LatLong &tileCoordinates);
  std::list<Way> processWays(const QueryParameters &queryParameters, int numberOfWays, const LatLong &tileCoordinates);
  LatLong readOptionalLabelPosition(bool featureLabelPosition, const LatLong &tileCoordinates);
  int readOptionalWayDataBlocksByte(bool featureWayDataBlocksByte);
  // std::vector<Foo> readZoomTable(const SubFileParameter &subFileParameter);
  std::vector<Foo> readZoomTable(const MapFileReader::SubFileInfo &subFileParameter);

  uint32_t read_uint32();
  uint64_t read_uint64();
  int32_t read_int32();
  int64_t read_int64();
  int16_t read_int16();
  uint16_t read_uint16();
  uint8_t read_uint8();
  int8_t read_int8();
  std::string read_utf8();
  uint64_t read_var_uint64();
  int64_t read_var_int64();
#ifdef ARDUINO
  int32_t read_offset();
#else
  int64_t read_offset();
#endif
  uint32_t read_var_uint32();
  int32_t read_var_int32();
  void check_buff(int number);
  void check(int number);
  /**
	 * Maximum buffer size which is supported by this implementation.
	 */

  bool readFromFile(int length);
private:


  MapFileInfo info_;
#ifdef ARDUINO
  File strm_;
#else
  std::ifstream strm_;
#endif
  std::string map_file_path_;

  // std::vector<Tag> wayTags;
  // std::vector<Tag> poiTags;

  std::vector<SubFileInfo> sub_files_;
  bool has_debug_info_;
  // boost::mutex mtx_;

  // QIODevice *const m_inputFile;
  // IndexCache m_databaseIndexCache;
  // MapFileHeader m_mapFileHeader;
  // MapFileReader m_readBuffer;
  std::string m_signatureBlock;
  std::string m_signaturePoi;
  std::string m_signatureWay;
};

#endif

//
