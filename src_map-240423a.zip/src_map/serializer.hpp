#ifndef __BINARY_STREAM_HPP__
#define __BINARY_STREAM_HPP__

#include <iostream>
#include <cstdint>
#include "commun.hpp"

#ifdef ARDUINO
#include <SD.h>
#endif

class MapFileReader;

class MapFileISerializer {
public:

  // Initialize using a stream. The stream should be open in binary mode.
#ifdef ARDUINO
  MapFileISerializer(File &strm)
    : strm_(strm) {}
#else
  MapFileISerializer(std::istream &strm)
    : strm_(strm) {}
#endif

  // read from stream
  uint32_t read_uint32();
  uint32_t sd_read_uint32();
  uint64_t read_uint64();
  uint64_t sd_read_uint64();
  int32_t read_int32();
  int32_t sd_read_int32();
  int64_t read_int64();
  int64_t sd_read_int64();
  int16_t read_int16();
  uint16_t read_uint16();
  int16_t sd_read_int16();
  uint16_t sd_read_uint16();
  uint8_t read_uint8();
  int8_t read_int8();
  uint8_t sd_read_uint8();
  int8_t sd_read_int8();
  std::string read_utf8();
  std::string read_utf8(int32_t len);
  std::string sd_read_utf8();
  std::string sd_read_utf8(int32_t len);
  uint32_t read_var_uint32();
  int32_t read_var_int32();
  uint32_t sd_read_var_uint32();
  int32_t sd_read_var_int32();
#ifdef ARDUINO
  int32_t sd_read_offset();
#else
  int64_t sd_read_offset();
#endif

  void read_bytes(uint8_t *buf, uint32_t n);
  void sd_read_bytes(uint8_t *buf, uint32_t n);
  uint32_t readUnsignedInt();
  int32_t readSignedInt();
  void skipBytes(int bytes);
  int getBufferPosition();
  std::string readUTF8EncodedString(int32_t l);
  void setBufferPosition(int bufferPosition);
  int getBufferSize() const;
  void check_buf(int number);

private:
#ifdef ARDUINO
  File &strm_;
#else
  std::istream &strm_;
#endif
};

#endif
