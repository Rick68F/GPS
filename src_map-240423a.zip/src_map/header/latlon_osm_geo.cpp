// utilitaire pour convertion tuile lat et lat tuile
#include <cmath>
#include <cstdint>

int long2tilex(double lon, int z) {
  return (int)(floor((lon + 180.0) / 360.0 * (1 << z)));
}

int lat2tiley(double lat, int z) {
  double latrad = lat * M_PI / 180.0;
  return (int)(floor((1.0 - asinh(tan(latrad)) / M_PI) / 2.0 * (1 << z)));
}

double long2tilex_d(double lon, int z) {
  return ((lon + 180.0) / 360.0 * (1 << z));
}

double lat2tiley_d(double lat, int z) {
  double latrad = lat * M_PI / 180.0;
  return ((1.0 - asinh(tan(latrad)) / M_PI) / 2.0 * (1 << z));
}

double tilex2long(int x, int z) {
  return x / (double)(1 << z) * 360.0 - 180;
}

double tiley2lat(int y, int z) {
  double n = M_PI - 2.0 * M_PI * y / (double)(1 << z);
  return 180.0 / M_PI * atan(0.5 * (exp(n) - exp(-n)));
}

// delimite la postion de la tuile 
void tile_Bounds(uint32_t tx, uint32_t ty, uint32_t zoom, double &minx, double &miny, double &maxx, double &maxy) {
  miny = tiley2lat(ty, zoom);
  maxy = tiley2lat(ty - 1, zoom);  //-1 vers l'equateur
  minx = tilex2long(tx, zoom);
  maxx = tilex2long(tx + 1, zoom);  // +1 vers la droite de terre 
}

//