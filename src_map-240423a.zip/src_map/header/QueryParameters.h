/*
 * Copyright 2010, 2011, 2012 mapsforge.org
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef MAPSFORGE_QUERYPARAMETERS_H
#define MAPSFORGE_QUERYPARAMETERS_H

// #include "qglobal.h"
#include <cstdint>


class TileId;

struct QueryParameters
{
public:
	QueryParameters(int queryZoomLevel, int64_t fromBlockX, int64_t fromBlockY, int64_t toBlockX, int64_t toBlockY);

	QueryParameters(int queryZoomLevel, int64_t fromBlockX, int64_t fromBlockY, int64_t toBlockX, int64_t toBlockY, const TileId &tile, int zoomLevelDifference);

	int64_t fromBlockX;
	int64_t fromBlockY;
	int64_t toBlockX;
	int64_t toBlockY;
	int queryZoomLevel;
	int queryTileBitmask;
	bool useTileBitmask;

private:
	static int getFirstLevelTileBitmask(const TileId &tile);

	static int getSecondLevelTileBitmaskLowerLeft(int64_t subtileX, int64_t subtileY);

	static int getSecondLevelTileBitmaskLowerRight(int64_t subtileX, int64_t subtileY);

	static int getSecondLevelTileBitmaskUpperLeft(int64_t subtileX, int64_t subtileY);

	static int getSecondLevelTileBitmaskUpperRight(int64_t subtileX, int64_t subtileY);

	static int calculateTileBitmask(const TileId &tile, int zoomLevelDifference);
};

#endif
