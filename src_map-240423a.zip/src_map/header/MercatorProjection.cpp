/*
 * Copyright 2010, 2011, 2012, 2013 mapsforge.org
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along  with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include "MercatorProjection.h"
#define LOG_LOCAL_LEVEL ESP_LOG_NONE // ESP_LOG_VERBOSE
#include "esp_log.h"

#include "BoundingBox.hpp"
#include "TileId.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <algorithm>


using namespace std;

int64_t MercatorProjection::latitudeToPixelY(double latitude, int8_t zoomLevel, unsigned short tileSize) {
  double sinLatitude = std::sin(latitude * (M_PI / 180));
  int64_t mapSize = TileId::getMapSize(zoomLevel, tileSize);
  // FIXME improve this formula so that it works correctly without the clipping
  double pixelY = (0.5 - log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * M_PI)) * mapSize;
  return min<int64_t>(max<int64_t>(0, pixelY), mapSize);
}

int64_t MercatorProjection::latitudeToTileY(double latitude, int8_t zoomLevel) {
  const double sinLatitude = std::sin(latitude * (M_PI / 180));
  const int64_t mapSize = 1 << zoomLevel;
  // FIXME improve this formula so that it works correctly without the clipping
  double pixelY = (0.5 - log((1 + sinLatitude) / (1 - sinLatitude)) / (4 * M_PI)) * mapSize;
  return std::min<int64_t>(std::max<int64_t>(0, pixelY), mapSize);
}

int64_t MercatorProjection::longitudeToPixelX(double longitude, int8_t zoomLevel, unsigned short tileSize) {
  const int64_t mapSize = TileId::getMapSize(zoomLevel, tileSize);
  return (longitude + 180) / 360 * mapSize;
}

int64_t MercatorProjection::longitudeToTileX(double longitude, int8_t zoomLevel) {
  const int64_t mapSize = 1 << zoomLevel;
  return (longitude + 180) / 360 * mapSize;
}

LatLong MercatorProjection::tileToCoordinates(const TileId &tile) {
  // if (tile.tileX >= 0) printf("Q_ASSERT(tile.tileX >= 0 );\n");
  // if (tile.tileY >= 0) printf("Q_ASSERT(tile.tileY >= 0 );\n");

  const double mapSize = 1 << tile.zoomLevel;

  ESP_LOGE("tileToCoordinates","\n\nmapsize=%f   tilezoomlevel=%d\n", mapSize, tile.zoomLevel);
  // if (tile.tileX <= mapSize) printf("Q_ASSERT(tile.tileX <= mapSize);\n");  // "invalid tileX coordinate at zoom level " + zoomLevel + ": " + tileX
  // if (tile.tileX <= mapSize) printf("invalid tileX coordinate at zoom level %d: %d\n", tile.zoomLevel, tile.tileX);
  // if (tile.tileY <= mapSize) printf("Q_ASSERT(tile.tileY <= mapSize);\n");  // "invalid tileY coordinate at zoom level " + zoomLevel + ": " + tileY
  // if (tile.tileY <= mapSize) printf("invalid tileY coordinate at zoom level %d: %d\n", tile.zoomLevel, tile.tileY);

  const double longitude = 360 * ((tile.tileX / mapSize) - 0.5);

  const double y = 0.5 - (tile.tileY / mapSize);
  const double latitude = 90 - 360 * std::atan(std::exp(-y * (2 * M_PI))) / M_PI;
  ESP_LOGE("tileToCoordinates","MercatorProjection: lat %f lon %f\n\n\n", latitude, longitude);
  return LatLong(latitude, longitude);
}

int64_t MercatorProjection::boundaryTileBottom(const BoundingBox &boundingBox, int zoomLevel) {
  return latitudeToTileY(boundingBox.minLatitude(), zoomLevel);
}

int64_t MercatorProjection::boundaryTileLeft(const BoundingBox &boundingBox, int zoomLevel) {
  return longitudeToTileX(boundingBox.minLongitude(), zoomLevel);
}

int64_t MercatorProjection::boundaryTileRight(const BoundingBox &boundingBox, int zoomLevel) {
  return longitudeToTileX(boundingBox.maxLongitude(), zoomLevel);
}

int64_t MercatorProjection::boundaryTileTop(const BoundingBox &boundingBox, int zoomLevel) {
  return latitudeToTileY(boundingBox.maxLatitude(), zoomLevel);
}

int64_t MercatorProjection::blocksHeight(const BoundingBox &boundingBox, int zoomLevel) {
  return boundaryTileBottom(boundingBox, zoomLevel) - boundaryTileTop(boundingBox, zoomLevel) + 1;
}

int64_t MercatorProjection::blocksWidth(const BoundingBox &boundingBox, int zoomLevel) {
  return boundaryTileRight(boundingBox, zoomLevel) - boundaryTileLeft(boundingBox, zoomLevel) + 1;
}
