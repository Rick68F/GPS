// https://github.com/JSchaenzle/ESP32-NeoPixel-WS2812-RMT/blob/master/ws2812_control.c
//
// Base de la modif pour creation de la class

#ifndef WS2812_CONTROL_HPP
#define WS2812_CONTROL_HPP

#include <stdint.h>
#include "sdkconfig.h"
#include "esp_err.h"
#include "driver/rmt.h"
#include "esp_check.h"


// #define NUM_LEDS	CONFIG_WS2812_NUM_LEDS
// #define NUM_LEDS 8
#define LED_RMT_TX_CHANNEL 0
#define LED_RMT_TX_GPIO 14
// ****************************************************

#define CONFIG_WS2812_LED_TYPE_RGB

#if defined(CONFIG_WS2812_LED_TYPE_RGB)
#define BITS_PER_LED_CMD 24
#else if defined(CONFIG_WS2812_LED_TYPE_RGBW)
#define BITS_PER_LED_CMD 32
#endif

// #define LED_BUFFER_ITEMS (NUM_LEDS * BITS_PER_LED_CMD)

// These values are determined by measuring pulse timing with logic analyzer and adjusting to match datasheet.
// #define T0H CONFIG_WS2812_T0H  // 0 bit high time
// #define T1H CONFIG_WS2812_T1H  // 1 bit high time
// #define T0L CONFIG_WS2812_T0L  // low time for either bit
// #define T1L CONFIG_WS2812_T1L

/*#define T0H 14  // 0 bit high time
#define T1H 52  // 1 bit high time
#define T0L 52  // low time for either bit
#define T1L 52 */

#define T0H 14  // 0 bit high time
#define T1H 32  // 1 bit high time
#define T0L 28  // low time for either bit
#define T1L 24

// Tag for log messages
static const char *TAG = "NeoPixel WS2812 Driver";

// This is the buffer which the hw peripheral will access while pulsing the output pin
// static rmt_item32_t led_data_buffer[LED_BUFFER_ITEMS];

static void setup_rmt_data_buffer(struct led_state new_state);


// Setup the hardware peripheral. Only call this once.
esp_err_t ws2812_control_init(void);

// Update the LEDs to the new state. Call as needed.
// This function will block the current task until the RMT peripheral is finished sending
// the entire sequence.
esp_err_t ws2812_write_leds(struct led_state new_state);

class WS2812_control {
public:

  int Num_Leds;
  rmt_channel_t Tx_Channel;
  // This structure is used for indicating what the colors of each LED should be set to.
  // There is a 32bit value for each LED. Only the lower 3 bytes are used and they hold the
  // Red (byte 2), Green (byte 1), and Blue (byte 0) values to be set.
  uint32_t *leds;
  rmt_item32_t *led_data_buffer;
  uint8_t bright;

  WS2812_control() {
  }

  ~WS2812_control() {
    free(leds);
    free(led_data_buffer);
  }

  esp_err_t ws2812_control_init(int16_t NumLed, int32_t GpioPort = LED_RMT_TX_GPIO, int8_t Channel = LED_RMT_TX_CHANNEL) {
    Num_Leds = NumLed;
    bright = 20;
    Tx_Channel = (rmt_channel_t)Channel;

    int Size = NumLed * sizeof(leds[0]);
    if ((leds = (uint32_t *)malloc(Size))) {
      memset(leds, 0, Size);
      Num_Leds = NumLed;
    } else {
      Num_Leds = 0;
    }
    if (Num_Leds > 0) {  // 1er maolloc ok

      int Size = NumLed * BITS_PER_LED_CMD * sizeof(rmt_item32_t);
      if ((led_data_buffer = (rmt_item32_t *)malloc(Size))) {
        Num_Leds = NumLed;
      } else {
        Num_Leds = 0;
      }

      rmt_config_t config = {
        .rmt_mode = RMT_MODE_TX,
        .channel = Tx_Channel,
        .gpio_num = (gpio_num_t)GpioPort,
        .clk_div = 2,
        .mem_block_num = 3,
        .tx_config = {
          .idle_level = (rmt_idle_level_t)0,
          .carrier_en = false,
          .loop_en = false,
          .idle_output_en = true,
        },
      };

      ESP_RETURN_ON_ERROR(rmt_config(&config), TAG, "Failed to configure RMT");
      ESP_RETURN_ON_ERROR(rmt_driver_install(config.channel, 0, 0), TAG, "Failed to install RMT driver");

      return (ESP_OK);
    }
    return (!ESP_OK);
  }

  void setColor(uint32_t LedNum, uint32_t color) {
    leds[LedNum] = color;
  }

  void fillColor(uint32_t color) {
    for (int l = 0; l < Num_Leds; l++) leds[l] = color;
  }

  void clear() {
    for (int l = 0; l < Num_Leds; l++) leds[l] = 0;
  }

  void clear(uint32_t LedNum) {
    leds[LedNum] = 0;
  }

  void setBrightness(uint8_t intensity) {
    bright = intensity;
  }

  esp_err_t ws2812_write_leds() {
    setup_rmt_data_buffer();
    ESP_RETURN_ON_ERROR(rmt_write_items(Tx_Channel, led_data_buffer,  Num_Leds * BITS_PER_LED_CMD, false), TAG, "Failed to write items");
    ESP_RETURN_ON_ERROR(rmt_wait_tx_done(Tx_Channel, portMAX_DELAY), TAG, "Failed to wait for RMT transmission to finish");

    return ESP_OK;
  }

  void setup_rmt_data_buffer() {
    for (uint32_t led = 0; led < Num_Leds; led++) {
      uint32_t bits_to_send = leds[led];

      // pour l'intensité de l'affichage
      uint32_t r = (((bits_to_send & 0x00FF0000) >> 16) * bright) >> 8;
      uint32_t g = (((bits_to_send & 0x0000FF00) >> 8) * bright) >> 8;
      uint32_t b = ((bits_to_send & 0x000000FF) * bright) >> 8;
      bits_to_send = r << 16 | g << 8 | b;

      uint32_t mask = 1 << (BITS_PER_LED_CMD - 1);

      for (uint32_t bit = 0; bit < BITS_PER_LED_CMD; bit++) {
        uint32_t bit_is_set = bits_to_send & mask;
        led_data_buffer[(led * BITS_PER_LED_CMD) + bit] = bit_is_set ? (rmt_item32_t){ { { T1H, 1, T1L, 0 } } } : (rmt_item32_t){ { { T0H, 1, T0L, 0 } } };
        mask >>= 1;
      }
    }
  }
};


#endif