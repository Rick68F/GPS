#define WATER 0xAE9B
#define NODEFINE 0xF77D
#define GRASS 0xB756
#define LANDFILL 0xB5B2
#define PARK 0xCFB9
#define BUILDING 0xDE99

#define LTBLUE 0xB6DF
#define LTTEAL 0xBF5F
#define LTGREEN 0xBFF7
#define LTCYAN 0xC7FF
#define LTRED 0xFD34
#define LTMAGENTA 0xFD5F
#define LTYELLOW 0xFFF8
#define LTORANGE 0xFE73
#define LTPINK 0xFDDF
#define LTPURPLE 0xCCFF
#define LTGREY 0xE71C

// #define BLUE 0x001F
#define TEAL 0x0438
// #define GREEN 0x07E0
#define CYAN 0x07FF
// #define RED 0xF800
#define MAGENTA 0xF81F
// #define YELLOW 0xFFE0
// #define ORANGE 0xFC00
// #define PINK 0xF81F
// #define PURPLE 0x8010
#define GREY 0xC618
// #define WHITE 0xFFFF

#define DKBLUE 0x000D
#define DKTEAL 0x020C
#define DKGREEN 0x03E0
#define DKCYAN 0x03EF
#define DKRED 0x6000
#define DKMAGENTA 0x8008
#define DKYELLOW 0x8400
#define DKORANGE 0x8200
#define DKPINK 0x9009
#define DKPURPLE 0x4010
#define DKGREY 0x4A49

// Extracted and merged from https://github.com/marekburiak/ILI9341_due
// New color definitions use for all my libraries
// Replace the few colours in Display.h (around line 363) with this
#define TFT_ALICEBLUE 0xF7DF
#define TFT_ANTIQUEWHITE 0xFF5A
#define TFT_AQUA 0x07FF
#define TFT_AQUAMARINE 0x7FFA
#define TFT_AZURE 0xF7FF
#define TFT_BEIGE 0xF7BB
#define TFT_BISQUE 0xFF38
#define TFT_BLACK 0x0000 /*   0, 0, 0 */
#define TFT_BLANCHEDALMOND 0xFF59
#define TFT_BLUE 0x001F /*   0, 0, 255 */
#define TFT_BLUEVIOLET 0x895C
#define TFT_BROWN 0xA145
#define TFT_BROWN2 0x9A60 /* 150,  75,   0 */
#define TFT_BURLYWOOD 0xDDD0
#define TFT_CADETBLUE 0x5CF4
#define TFT_CHARTREUSE 0x7FE0
#define TFT_CHOCOLATE 0xD343
#define TFT_CORAL 0xFBEA
#define TFT_CORNFLOWERBLUE 0x64BD
#define TFT_CORNSILK 0xFFDB
#define TFT_CRIMSON 0xD8A7
#define TFT_CYAN 0x07FF /*   0, 255, 255 */
#define TFT_DARKBLUE 0x0011
#define TFT_DARKCYAN 0x03EF /*   0, 128, 128 */
#define TFT_DARKCYAN2 0x0451
#define TFT_DARKGOLDENROD 0xBC21
#define TFT_DARKGRAY 0xAD55
#define TFT_DARKGREEN2 0x0320
#define TFT_DARKGREEN 0x03E0 /*   0, 128, 0 */
#define TFT_DARKGREY 0x7BEF  /* 128, 128, 128 */
#define TFT_DARKKHAKI 0xBDAD
#define TFT_DARKMAGENTA 0x8811
#define TFT_DARKOLIVEGREEN 0x5345
#define TFT_DARKORANGE 0xFC60
#define TFT_DARKORCHID 0x9999
#define TFT_DARKRED 0x8800
#define TFT_DARKSALMON 0xECAF
#define TFT_DARKSEAGREEN 0x8DF1
#define TFT_DARKSLATEBLUE 0x49F1
#define TFT_DARKSLATEGRAY 0x2A69
#define TFT_DARKTURQUOISE 0x067A
#define TFT_DARKVIOLET 0x901A
#define TFT_DEEPPINK 0xF8B2
#define TFT_DEEPSKYBLUE 0x05FF
#define TFT_DIMGRAY 0x6B4D
#define TFT_DODGERBLUE 0x1C9F
#define TFT_FIREBRICK 0xB104
#define TFT_FLORALWHITE 0xFFDE
#define TFT_FORESTGREEN 0x2444
#define TFT_FUCHSIA 0xF81F
#define TFT_GAINSBORO 0xDEFB
#define TFT_GHOSTWHITE 0xFFDF
#define TFT_GOLD 0xFEA0 /* 255, 215,   0 */
#define TFT_GOLDENROD 0xDD24
#define TFT_GRAY 0x8410
#define TFT_GREEN2 0x0400
#define TFT_GREEN 0x07E0        /*   0, 255, 0 */
#define TFT_GREENYELLOW 0xAFE5  /* 173, 255, 47 */
#define TFT_GREENYELLOW2 0xB7E0 /* 180, 255,   0 */
#define TFT_HONEYDEW 0xF7FE
#define TFT_HOTPINK 0xFB56
#define TFT_INDIANRED 0xCAEB
#define TFT_INDIGO 0x4810
#define TFT_IVORY 0xFFFE
#define TFT_KHAKI 0xF731
#define TFT_LAVENDER 0xE73F
#define TFT_LAVENDERBLUSH 0xFF9E
#define TFT_LAWNGREEN 0x7FE0
#define TFT_LEMONCHIFFON 0xFFD9
#define TFT_LIGHTBLUE 0xAEDC
#define TFT_LIGHTCORAL 0xF410
#define TFT_LIGHTCYAN 0xE7FF
#define TFT_LIGHTGOLDENRODYELLOW 0xFFDA
#define TFT_LIGHTGREEN 0x9772
#define TFT_LIGHTGREY 0xC618  /* 192, 192, 192 */
#define TFT_LIGHTGREY2 0xD69A /* 211, 211, 211 */
#define TFT_LIGHTPINK 0xFDB8
#define TFT_LIGHTSALMON 0xFD0F
#define TFT_LIGHTSEAGREEN 0x2595
#define TFT_LIGHTSKYBLUE 0x867F
#define TFT_LIGHTSLATEGRAY 0x7453
#define TFT_LIGHTSTEELBLUE 0xB63B
#define TFT_LIGHTYELLOW 0xFFFC
#define TFT_LIME 0x07E0
#define TFT_LIMEGREEN 0x3666
#define TFT_LINEN 0xFF9C
#define TFT_MAGENTA 0xF81F /* 255, 0, 255 */
#define TFT_MAROON 0x7800  /* 128, 0, 0 */
#define TFT_MAROON2 0x8000
#define TFT_MEDIUMAQUAMARINE 0x6675
#define TFT_MEDIUMBLUE 0x0019
#define TFT_MEDIUMORCHID 0xBABA
#define TFT_MEDIUMPURPLE 0x939B
#define TFT_MEDIUMSEAGREEN 0x3D8E
#define TFT_MEDIUMSLATEBLUE 0x7B5D
#define TFT_MEDIUMSPRINGGREEN 0x07D3
#define TFT_MEDIUMTURQUOISE 0x4E99
#define TFT_MEDIUMVIOLETRED 0xC0B0
#define TFT_MIDNIGHTBLUE 0x18CE
#define TFT_MINTCREAM 0xF7FF
#define TFT_MISTYROSE 0xFF3C
#define TFT_MOCCASIN 0xFF36
#define TFT_NAVAJOWHITE 0xFEF5
#define TFT_NAVY 0x000F /*   0, 0, 128 */
#define TFT_NAVY2 0x0010
#define TFT_OLDLACE 0xFFBC
#define TFT_OLIVE 0x7BE0 /* 128, 128, 0 */
#define TFT_OLIVE2 0x8400
#define TFT_OLIVEDRAB 0x6C64
#define TFT_ORANGE 0xFD20  /* 255, 165, 0 */
#define TFT_ORANGE2 0xFDA0 /* 255, 180,   0 */
#define TFT_ORANGERED 0xFA20
#define TFT_ORCHID 0xDB9A
#define TFT_PALEGOLDENROD 0xEF55
#define TFT_PALEGREEN 0x9FD3
#define TFT_PALETURQUOISE 0xAF7D
#define TFT_PALEVIOLETRED 0xDB92
#define TFT_PAPAYAWHIP 0xFF7A
#define TFT_PEACHPUFF 0xFED7
#define TFT_PERU 0xCC27
#define TFT_PINK 0xF81F
#define TFT_PINK2 0xFE19 /* 255, 192, 203 */  //Lighter pink, was 0xFC9F
#define TFT_PLUM 0xDD1B
#define TFT_POWDERBLUE 0xB71C
#define TFT_PURPLE 0x780F /* 128, 0, 128 */
#define TFT_PURPLE2 0x8010
#define TFT_RED 0xF800 /* 255, 0, 0 */
#define TFT_ROSYBROWN 0xBC71
#define TFT_ROYALBLUE 0x435C
#define TFT_SADDLEBROWN 0x8A22
#define TFT_SALMON 0xFC0E
#define TFT_SANDYBROWN 0xF52C
#define TFT_SEAGREEN 0x2C4A
#define TFT_SEASHELL 0xFFBD
#define TFT_SIENNA 0xA285
#define TFT_SILVER 0xC618  /* 192, 192, 192 */
#define TFT_SKYBLUE 0x867D /* 135, 206, 235 */
#define TFT_SLATEBLUE 0x6AD9
#define TFT_SLATEGRAY 0x7412
#define TFT_SNOW 0xFFDF
#define TFT_SPRINGGREEN 0x07EF
#define TFT_STEELBLUE 0x4416
#define TFT_TAN 0xD5B1
#define TFT_TEAL 0x0410
#define TFT_THISTLE 0xDDFB
#define TFT_TOMATO 0xFB08
#define TFT_TURQUOISE 0x471A
#define TFT_VIOLET 0xEC1D
#define TFT_VIOLET2 0x915C /* 180,  46, 226 */
#define TFT_WHEAT 0xF6F6
#define TFT_WHITE 0xFFFF /* 255, 255, 255 */
#define TFT_WHITESMOKE 0xF7BE
#define TFT_YELLOW 0xFFE0 /* 255, 255, 0 */
#define TFT_YELLOWGREEN 0x9E66

#ifndef _RGB565_ERIC
#define _RGB565_ERIC
enum {
  RGB565_BLACK = 0x0000,                 //  ( 000 ,000 ,000 )
  RGB565_MIDNIGHTBLUE = 0x18CE,          //  ( 025 ,025 ,112 )
  RGB565_DARKBLUE = 0x0011,              //  ( 000 ,000 ,139 )
  RGB565_NAVY = 0x0010,                  //  ( 000 ,000 ,128 )
  RGB565_BLUE = 0x001F,                  //  ( 000 ,000 ,255 )
  RGB565_MEDIUMBLUE = 0x0019,            //  ( 000 ,000 ,205 )
  RGB565_DARKGREEN = 0x0320,             //  ( 000 ,100 ,000 )
  RGB565_GREEN = 0x0400,                 //  ( 000 ,128 ,000 )
  RGB565_DARKCYAN = 0x0451,              //  ( 000 ,139 ,139 )
  RGB565_TEAL = 0x0410,                  //  ( 000 ,128 ,128 )
  RGB565_DODGERBLUE = 0x1C9F,            //  ( 030 ,144 ,255 )
  RGB565_DEEPSKYBLUE = 0x05FF,           //  ( 000 ,191 ,255 )
  RGB565_DARKTURQUOISE = 0x067A,         //  ( 000 ,206 ,209 )
  RGB565_LIME = 0x07E0,                  //  ( 000 ,255 ,000 )
  RGB565_SPRINGGREEN = 0x07EF,           //  ( 000 ,255 ,127 )
  RGB565_MEDIUMSPRINGGREEN = 0x07D3,     //  ( 000 ,250 ,154 )
  RGB565_AQUA = 0x07FF,                  //  ( 000 ,255 ,255 )
  RGB565_CYAN = 0x07FF,                  //  ( 000 ,255 ,255 )
  RGB565_DARKSLATEGREY = 0x2A69,         //  ( 047 ,079 ,079 )
  RGB565_FORESTGREEN = 0x2444,           //  ( 034 ,139 ,034 )
  RGB565_SEAGREEN = 0x2C4A,              //  ( 046 ,139 ,087 )
  RGB565_MEDIUMSEAGREEN = 0x3D8E,        //  ( 060 ,179 ,113 )
  RGB565_LIGHTSEAGREEN = 0x2595,         //  ( 032 ,178 ,170 )
  RGB565_LIMEGREEN = 0x3666,             //  ( 050 ,205 ,050 )
  RGB565_INDIGO = 0x4810,                //  ( 075 ,000 ,130 )
  RGB565_DARKSLATEBLUE = 0x49F1,         //  ( 072 ,061 ,139 )
  RGB565_DARKOLIVEGREEN = 0x5345,        //  ( 085 ,107 ,047 )
  RGB565_ROYALBLUE = 0x435C,             //  ( 065 ,105 ,225 )
  RGB565_CADETBLUE = 0x5CF4,             //  ( 095 ,158 ,160 )
  RGB565_STEELBLUE = 0x4416,             //  ( 070 ,130 ,180 )
  RGB565_MEDIUMTURQUOISE = 0x4E99,       //  ( 072 ,209 ,204 )
  RGB565_TURQUOISE = 0x471A,             //  ( 064 ,224 ,208 )
  RGB565_REBECCAPURPLE = 0x6193,         //  ( 102 ,051 ,153 )
  RGB565_SLATEBLUE = 0x6AD9,             //  ( 106 ,090 ,205 )
  RGB565_DIMGREY = 0x6B4D,               //  ( 105 ,105 ,105 )
  RGB565_MEDIUMSLATEBLUE = 0x7B5D,       //  ( 123 ,104 ,238 )
  RGB565_OLIVEDRAB = 0x6C64,             //  ( 107 ,142 ,035 )
  RGB565_LIGHTSLATEGRAY = 0x7453,        //  ( 119 ,136 ,153 )
  RGB565_SLATEGRAY = 0x7412,             //  ( 112 ,128 ,144 )
  RGB565_CORNFLOWERBLUE = 0x64BD,        //  ( 100 ,149 ,237 )
  RGB565_MEDIUMAQUAMARINE = 0x6675,      //  ( 102 ,205 ,170 )
  RGB565_CHARTREUSE = 0x7FE0,            //  ( 127 ,255 ,000 )
  RGB565_LAWNGREEN = 0x7FE0,             //  ( 124 ,252 ,000 )
  RGB565_AQUAMARINE = 0x7FFA,            //  ( 127 ,255 ,212 )
  RGB565_DARKRED = 0x8800,               //  ( 139 ,000 ,000 )
  RGB565_MAROON = 0x8000,                //  ( 128 ,000 ,000 )
  RGB565_DARKMAGENTA = 0x8811,           //  ( 139 ,000 ,139 )
  RGB565_PURPLE = 0x8010,                //  ( 128 ,000 ,128 )
  RGB565_DARKVIOLET = 0x901A,            //  ( 148 ,000 ,211 )
  RGB565_BLUEVIOLET = 0x895C,            //  ( 138 ,043 ,226 )
  RGB565_DARKORCHID = 0x9999,            //  ( 153 ,050 ,204 )
  RGB565_SADDLEBROWN = 0x8A22,           //  ( 139 ,069 ,019 )
  RGB565_MEDIUMPURPLE = 0x939B,          //  ( 147 ,112 ,219 )
  RGB565_OLIVE = 0x8400,                 //  ( 128 ,128 ,000 )
  RGB565_GRAY = 0x8410,                  //  ( 128 ,128 ,128 )
  RGB565_DARKSEAGREEN = 0x8DF1,          //  ( 143 ,188 ,143 )
  RGB565_YELLOWGREEN = 0x9E66,           //  ( 154 ,205 ,050 )
  RGB565_LIGHTSKYBLUE = 0x867F,          //  ( 135 ,206 ,250 )
  RGB565_SKYBLUE = 0x867D,               //  ( 135 ,206 ,235 )
  RGB565_LIGHTGREEN = 0x9772,            //  ( 144 ,238 ,144 )
  RGB565_PALEGREEN = 0x9FD3,             //  ( 152 ,251 ,152 )
  RGB565_BROWN = 0xA145,                 //  ( 165 ,042 ,042 )
  RGB565_FIREBRICK = 0xB104,             //  ( 178 ,034 ,034 )
  RGB565_SIENNA = 0xA285,                //  ( 160 ,082 ,045 )
  RGB565_MEDIUMORCHID = 0xBABA,          //  ( 186 ,085 ,211 )
  RGB565_DARKGOLDENROD = 0xBC21,         //  ( 184 ,134 ,011 )
  RGB565_ROSYBROWN = 0xBC71,             //  ( 188 ,143 ,143 )
  RGB565_DARKKHAKI = 0xBDAD,             //  ( 189 ,183 ,107 )
  RGB565_DARKGREY = 0xAD55,              //  ( 169 ,169 ,169 )
  RGB565_LIGHTBLUE = 0xAEDC,             //  ( 173 ,216 ,230 )
  RGB565_LIGHTSTEELBLUE = 0xB63B,        //  ( 176 ,196 ,222 )
  RGB565_GREENYELLOW = 0xAFE5,           //  ( 173 ,255 ,047 )
  RGB565_PALETURQUOISE = 0xAF7D,         //  ( 175 ,238 ,238 )
  RGB565_POWDERBLUE = 0xB71C,            //  ( 176 ,224 ,230 )
  RGB565_CRIMSON = 0xD8A7,               //  ( 220 ,020 ,060 )
  RGB565_MEDIUMVIOLETRED = 0xC0B0,       //  ( 199 ,021 ,133 )
  RGB565_INDIANRED = 0xCAEB,             //  ( 205 ,092 ,092 )
  RGB565_CHOCOLATE = 0xD343,             //  ( 210 ,105 ,030 )
  RGB565_PALEVIOLETRED = 0xDB92,         //  ( 219 ,112 ,147 )
  RGB565_ORCHID = 0xDB9A,                //  ( 218 ,112 ,214 )
  RGB565_PERU = 0xCC27,                  //  ( 205 ,133 ,063 )
  RGB565_GOLDENROD = 0xDD24,             //  ( 218 ,165 ,032 )
  RGB565_BURLYWOOD = 0xDDD0,             //  ( 222 ,184 ,135 )
  RGB565_TAN = 0xD5B1,                   //  ( 210 ,180 ,140 )
  RGB565_PLUM = 0xDD1B,                  //  ( 221 ,160 ,221 )
  RGB565_THISTLE = 0xDDFB,               //  ( 216 ,191 ,216 )
  RGB565_GAINSBORO = 0xDEFB,             //  ( 220 ,220 ,220 )
  RGB565_LIGHTGRAY = 0xD69A,             //  ( 211 ,211 ,211 )
  RGB565_SILVER = 0xC618,                //  ( 192 ,192 ,192 )
  RGB565_RED = 0xF800,                   //  ( 255 ,000 ,000 )
  RGB565_DEEPPINK = 0xF8B2,              //  ( 255 ,020 ,147 )
  RGB565_FUCHSIA = 0xF81F,               //  ( 255 ,000 ,255 )
  RGB565_MAGENTA = 0xF81F,               //  ( 255 ,000 ,255 )
  RGB565_ORANGERED = 0xFA20,             //  ( 255 ,069 ,000 )
  RGB565_CORAL = 0xFBEA,                 //  ( 255 ,127 ,080 )
  RGB565_TOMATO = 0xFB08,                //  ( 255 ,099 ,071 )
  RGB565_HOTPINK = 0xFB56,               //  ( 255 ,105 ,180 )
  RGB565_DARKORANGE = 0xFC60,            //  ( 255 ,140 ,000 )
  RGB565_DARKSALMON = 0xECAF,            //  ( 233 ,150 ,122 )
  RGB565_SALMON = 0xFC0E,                //  ( 250 ,128 ,114 )
  RGB565_LIGHTCORAL = 0xF410,            //  ( 240 ,128 ,128 )
  RGB565_VIOLET = 0xEC1D,                //  ( 238 ,130 ,238 )
  RGB565_ORANGE = 0xFD20,                //  ( 255 ,165 ,000 )
  RGB565_LIGHTSALMON = 0xFD0F,           //  ( 255 ,160 ,122 )
  RGB565_SANDYBROWN = 0xF52C,            //  ( 244 ,164 ,096 )
  RGB565_LIGHTPINK = 0xFDB8,             //  ( 255 ,182 ,193 )
  RGB565_GOLD = 0xFEA0,                  //  ( 255 ,215 ,000 )
  RGB565_NAVAJOWHITE = 0xFEF5,           //  ( 255 ,222 ,173 )
  RGB565_PEACHPUFF = 0xFED7,             //  ( 255 ,218 ,185 )
  RGB565_WHEAT = 0xF6F6,                 //  ( 245 ,222 ,179 )
  RGB565_PINK = 0xFE19,                  //  ( 255 ,192 ,203 )
  RGB565_YELLOW = 0xFFE0,                //  ( 255 ,255 ,000 )
  RGB565_KHAKI = 0xF731,                 //  ( 240 ,230 ,140 )
  RGB565_MOCCASIN = 0xFF36,              //  ( 255 ,228 ,181 )
  RGB565_PALEGOLDENROD = 0xEF55,         //  ( 238 ,232 ,170 )
  RGB565_ALICEBLUE = 0xF7DF,             //  ( 240 ,248 ,255 )
  RGB565_ANTIQUEWHITE = 0xFF5A,          //  ( 250 ,235 ,215 )
  RGB565_AZURE = 0xF7FF,                 //  ( 240 ,255 ,255 )
  RGB565_BEIGE = 0xF7BB,                 //  ( 245 ,245 ,220 )
  RGB565_BISQUE = 0xFF38,                //  ( 255 ,228 ,196 )
  RGB565_BLANCHEDALMOND = 0xFF59,        //  ( 255 ,235 ,205 )
  RGB565_CORNSILK = 0xFFDB,              //  ( 255 ,248 ,220 )
  RGB565_FLORALWHITE = 0xFFDE,           //  ( 255 ,250 ,240 )
  RGB565_GHOSTWHITE = 0xFFDF,            //  ( 248 ,248 ,255 )
  RGB565_HONEYDEW = 0xF7FE,              //  ( 240 ,255 ,240 )
  RGB565_IVORY = 0xFFFE,                 //  ( 255 ,255 ,240 )
  RGB565_LAVENDER = 0xE73F,              //  ( 230 ,230 ,250 )
  RGB565_LAVENDERBLUSH = 0xFF9E,         //  ( 255 ,240 ,245 )
  RGB565_LEMONCHIFFON = 0xFFD9,          //  ( 255 ,250 ,205 )
  RGB565_LIGHTCYAN = 0xE7FF,             //  ( 224 ,255 ,255 )
  RGB565_LIGHTGOLDENRODYELLOW = 0xFFDA,  //  ( 250 ,250 ,210 )
  RGB565_LIGHTYELLOW = 0xFFFC,           //  ( 255 ,255 ,224 )
  RGB565_LINEN = 0xFF9C,                 //  ( 250 ,240 ,230 )
  RGB565_MINTCREAM = 0xF7FF,             //  ( 245 ,255 ,250 )
  RGB565_MISTYROSE = 0xFF3C,             //  ( 255 ,228 ,225 )
  RGB565_OLDLACE = 0xFFBC,               //  ( 253 ,245 ,230 )
  RGB565_PAPAYAWHIP = 0xFF7A,            //  ( 255 ,239 ,213 )
  RGB565_SEASHELL = 0xFFBD,              //  ( 255 ,245 ,238 )
  RGB565_SNOW = 0xFFDF,                  //  ( 255 ,250 ,250 )
  RGB565_WHITE = 0xFFFF,                 //  ( 255 ,255 ,255 )
  RGB565_WHITESMOKE = 0xF7BE,            //  ( 245 ,245 ,245 )
};
#endif


#ifndef _RGB888_ERIC
#define _RGB888_ERIC
enum {
  RGB888_ALICEBLUE = 0xF0F8FF,             //  ( 240 ,248 ,255 )
  RGB888_ANTIQUEWHITE = 0xFAEBD7,          //  ( 250 ,235 ,215 )
  RGB888_AQUA = 0x00FFFF,                  //  ( 000 ,255 ,255 )
  RGB888_AQUAMARINE = 0x7FFFD4,            //  ( 127 ,255 ,212 )
  RGB888_AZURE = 0xF0FFFF,                 //  ( 240 ,255 ,255 )
  RGB888_BEIGE = 0xF5F5DC,                 //  ( 245 ,245 ,220 )
  RGB888_BISQUE = 0xFFE4C4,                //  ( 255 ,228 ,196 )
  RGB888_BLACK = 0x000000,                 //  ( 000 ,000 ,000 )
  RGB888_BLANCHEDALMOND = 0xFFEBCD,        //  ( 255 ,235 ,205 )
  RGB888_BLUE = 0x0000FF,                  //  ( 000 ,000 ,255 )
  RGB888_BLUEVIOLET = 0x8A2BE2,            //  ( 138 ,043 ,226 )
  RGB888_BROWN = 0xA52A2A,                 //  ( 165 ,042 ,042 )
  RGB888_BURLYWOOD = 0xDEB887,             //  ( 222 ,184 ,135 )
  RGB888_CADETBLUE = 0x5F9EA0,             //  ( 095 ,158 ,160 )
  RGB888_CHARTREUSE = 0x7FFF00,            //  ( 127 ,255 ,000 )
  RGB888_CHOCOLATE = 0xD2691E,             //  ( 210 ,105 ,030 )
  RGB888_CORAL = 0xFF7F50,                 //  ( 255 ,127 ,080 )
  RGB888_CORNFLOWERBLUE = 0x6495ED,        //  ( 100 ,149 ,237 )
  RGB888_CORNSILK = 0xFFF8DC,              //  ( 255 ,248 ,220 )
  RGB888_CRIMSON = 0xDC143C,               //  ( 220 ,020 ,060 )
  RGB888_CYAN = 0x00FFFF,                  //  ( 000 ,255 ,255 )
  RGB888_DARKBLUE = 0x00008B,              //  ( 000 ,000 ,139 )
  RGB888_DARKCYAN = 0x008B8B,              //  ( 000 ,139 ,139 )
  RGB888_DARKGOLDENROD = 0xB8860B,         //  ( 184 ,134 ,011 )
  RGB888_DARKGREEN = 0x006400,             //  ( 000 ,100 ,000 )
  RGB888_DARKGREY = 0xA9A9A9,              //  ( 169 ,169 ,169 )
  RGB888_DARKKHAKI = 0xBDB76B,             //  ( 189 ,183 ,107 )
  RGB888_DARKMAGENTA = 0x8B008B,           //  ( 139 ,000 ,139 )
  RGB888_DARKOLIVEGREEN = 0x556B2F,        //  ( 085 ,107 ,047 )
  RGB888_DARKORANGE = 0xFF8C00,            //  ( 255 ,140 ,000 )
  RGB888_DARKORCHID = 0x9932CC,            //  ( 153 ,050 ,204 )
  RGB888_DARKRED = 0x8B0000,               //  ( 139 ,000 ,000 )
  RGB888_DARKSALMON = 0xE9967A,            //  ( 233 ,150 ,122 )
  RGB888_DARKSEAGREEN = 0x8FBC8F,          //  ( 143 ,188 ,143 )
  RGB888_DARKSLATEBLUE = 0x483D8B,         //  ( 072 ,061 ,139 )
  RGB888_DARKSLATEGREY = 0x2F4F4F,         //  ( 047 ,079 ,079 )
  RGB888_DARKTURQUOISE = 0x00CED1,         //  ( 000 ,206 ,209 )
  RGB888_DARKVIOLET = 0x9400D3,            //  ( 148 ,000 ,211 )
  RGB888_DEEPPINK = 0xFF1493,              //  ( 255 ,020 ,147 )
  RGB888_DEEPSKYBLUE = 0x00BFFF,           //  ( 000 ,191 ,255 )
  RGB888_DIMGREY = 0x696969,               //  ( 105 ,105 ,105 )
  RGB888_DODGERBLUE = 0x1E90FF,            //  ( 030 ,144 ,255 )
  RGB888_FIREBRICK = 0xB22222,             //  ( 178 ,034 ,034 )
  RGB888_FLORALWHITE = 0xFFFAF0,           //  ( 255 ,250 ,240 )
  RGB888_FORESTGREEN = 0x228B22,           //  ( 034 ,139 ,034 )
  RGB888_FUCHSIA = 0xFF00FF,               //  ( 255 ,000 ,255 )
  RGB888_GAINSBORO = 0xDCDCDC,             //  ( 220 ,220 ,220 )
  RGB888_GHOSTWHITE = 0xF8F8FF,            //  ( 248 ,248 ,255 )
  RGB888_GOLD = 0xFFD700,                  //  ( 255 ,215 ,000 )
  RGB888_GOLDENROD = 0xDAA520,             //  ( 218 ,165 ,032 )
  RGB888_GRAY = 0x808080,                  //  ( 128 ,128 ,128 )
  RGB888_GREEN = 0x008000,                 //  ( 000 ,128 ,000 )
  RGB888_GREENYELLOW = 0xADFF2F,           //  ( 173 ,255 ,047 )
  RGB888_HONEYDEW = 0xF0FFF0,              //  ( 240 ,255 ,240 )
  RGB888_HOTPINK = 0xFF69B4,               //  ( 255 ,105 ,180 )
  RGB888_INDIANRED = 0xCD5C5C,             //  ( 205 ,092 ,092 )
  RGB888_INDIGO = 0x4B0082,                //  ( 075 ,000 ,130 )
  RGB888_IVORY = 0xFFFFF0,                 //  ( 255 ,255 ,240 )
  RGB888_KHAKI = 0xF0E68C,                 //  ( 240 ,230 ,140 )
  RGB888_LAVENDER = 0xE6E6FA,              //  ( 230 ,230 ,250 )
  RGB888_LAVENDERBLUSH = 0xFFF0F5,         //  ( 255 ,240 ,245 )
  RGB888_LAWNGREEN = 0x7CFC00,             //  ( 124 ,252 ,000 )
  RGB888_LEMONCHIFFON = 0xFFFACD,          //  ( 255 ,250 ,205 )
  RGB888_LIGHTBLUE = 0xADD8E6,             //  ( 173 ,216 ,230 )
  RGB888_LIGHTCORAL = 0xF08080,            //  ( 240 ,128 ,128 )
  RGB888_LIGHTCYAN = 0xE0FFFF,             //  ( 224 ,255 ,255 )
  RGB888_LIGHTGOLDENRODYELLOW = 0xFAFAD2,  //  ( 250 ,250 ,210 )
  RGB888_LIGHTGRAY = 0xD3D3D3,             //  ( 211 ,211 ,211 )
  RGB888_LIGHTGREEN = 0x90EE90,            //  ( 144 ,238 ,144 )
  RGB888_LIGHTPINK = 0xFFB6C1,             //  ( 255 ,182 ,193 )
  RGB888_LIGHTSALMON = 0xFFA07A,           //  ( 255 ,160 ,122 )
  RGB888_LIGHTSEAGREEN = 0x20B2AA,         //  ( 032 ,178 ,170 )
  RGB888_LIGHTSKYBLUE = 0x87CEFA,          //  ( 135 ,206 ,250 )
  RGB888_LIGHTSLATEGRAY = 0x778899,        //  ( 119 ,136 ,153 )
  RGB888_LIGHTSTEELBLUE = 0xB0C4DE,        //  ( 176 ,196 ,222 )
  RGB888_LIGHTYELLOW = 0xFFFFE0,           //  ( 255 ,255 ,224 )
  RGB888_LIME = 0x00FF00,                  //  ( 000 ,255 ,000 )
  RGB888_LIMEGREEN = 0x32CD32,             //  ( 050 ,205 ,050 )
  RGB888_LINEN = 0xFAF0E6,                 //  ( 250 ,240 ,230 )
  RGB888_MAGENTA = 0xFF00FF,               //  ( 255 ,000 ,255 )
  RGB888_MAROON = 0x800000,                //  ( 128 ,000 ,000 )
  RGB888_MEDIUMAQUAMARINE = 0x66CDAA,      //  ( 102 ,205 ,170 )
  RGB888_MEDIUMBLUE = 0x0000CD,            //  ( 000 ,000 ,205 )
  RGB888_MEDIUMORCHID = 0xBA55D3,          //  ( 186 ,085 ,211 )
  RGB888_MEDIUMPURPLE = 0x9370DB,          //  ( 147 ,112 ,219 )
  RGB888_MEDIUMSEAGREEN = 0x3CB371,        //  ( 060 ,179 ,113 )
  RGB888_MEDIUMSLATEBLUE = 0x7B68EE,       //  ( 123 ,104 ,238 )
  RGB888_MEDIUMSPRINGGREEN = 0x00FA9A,     //  ( 000 ,250 ,154 )
  RGB888_MEDIUMTURQUOISE = 0x48D1CC,       //  ( 072 ,209 ,204 )
  RGB888_MEDIUMVIOLETRED = 0xC71585,       //  ( 199 ,021 ,133 )
  RGB888_MIDNIGHTBLUE = 0x191970,          //  ( 025 ,025 ,112 )
  RGB888_MINTCREAM = 0xF5FFFA,             //  ( 245 ,255 ,250 )
  RGB888_MISTYROSE = 0xFFE4E1,             //  ( 255 ,228 ,225 )
  RGB888_MOCCASIN = 0xFFE4B5,              //  ( 255 ,228 ,181 )
  RGB888_NAVAJOWHITE = 0xFFDEAD,           //  ( 255 ,222 ,173 )
  RGB888_NAVY = 0x000080,                  //  ( 000 ,000 ,128 )
  RGB888_OLDLACE = 0xFDF5E6,               //  ( 253 ,245 ,230 )
  RGB888_OLIVE = 0x808000,                 //  ( 128 ,128 ,000 )
  RGB888_OLIVEDRAB = 0x6B8E23,             //  ( 107 ,142 ,035 )
  RGB888_ORANGE = 0xFFA500,                //  ( 255 ,165 ,000 )
  RGB888_ORANGERED = 0xFF4500,             //  ( 255 ,069 ,000 )
  RGB888_ORCHID = 0xDA70D6,                //  ( 218 ,112 ,214 )
  RGB888_PALEGOLDENROD = 0xEEE8AA,         //  ( 238 ,232 ,170 )
  RGB888_PALEGREEN = 0x98FB98,             //  ( 152 ,251 ,152 )
  RGB888_PALETURQUOISE = 0xAFEEEE,         //  ( 175 ,238 ,238 )
  RGB888_PALEVIOLETRED = 0xDB7093,         //  ( 219 ,112 ,147 )
  RGB888_PAPAYAWHIP = 0xFFEFD5,            //  ( 255 ,239 ,213 )
  RGB888_PEACHPUFF = 0xFFDAB9,             //  ( 255 ,218 ,185 )
  RGB888_PERU = 0xCD853F,                  //  ( 205 ,133 ,063 )
  RGB888_PINK = 0xFFC0CB,                  //  ( 255 ,192 ,203 )
  RGB888_PLUM = 0xDDA0DD,                  //  ( 221 ,160 ,221 )
  RGB888_POWDERBLUE = 0xB0E0E6,            //  ( 176 ,224 ,230 )
  RGB888_PURPLE = 0x800080,                //  ( 128 ,000 ,128 )
  RGB888_REBECCAPURPLE = 0x663399,         //  ( 102 ,051 ,153 )
  RGB888_RED = 0xFF0000,                   //  ( 255 ,000 ,000 )
  RGB888_ROSYBROWN = 0xBC8F8F,             //  ( 188 ,143 ,143 )
  RGB888_ROYALBLUE = 0x4169E1,             //  ( 065 ,105 ,225 )
  RGB888_SADDLEBROWN = 0x8B4513,           //  ( 139 ,069 ,019 )
  RGB888_SALMON = 0xFA8072,                //  ( 250 ,128 ,114 )
  RGB888_SANDYBROWN = 0xF4A460,            //  ( 244 ,164 ,096 )
  RGB888_SEAGREEN = 0x2E8B57,              //  ( 046 ,139 ,087 )
  RGB888_SEASHELL = 0xFFF5EE,              //  ( 255 ,245 ,238 )
  RGB888_SIENNA = 0xA0522D,                //  ( 160 ,082 ,045 )
  RGB888_SILVER = 0xC0C0C0,                //  ( 192 ,192 ,192 )
  RGB888_SKYBLUE = 0x87CEEB,               //  ( 135 ,206 ,235 )
  RGB888_SLATEBLUE = 0x6A5ACD,             //  ( 106 ,090 ,205 )
  RGB888_SLATEGRAY = 0x708090,             //  ( 112 ,128 ,144 )
  RGB888_SNOW = 0xFFFAFA,                  //  ( 255 ,250 ,250 )
  RGB888_SPRINGGREEN = 0x00FF7F,           //  ( 000 ,255 ,127 )
  RGB888_STEELBLUE = 0x4682B4,             //  ( 070 ,130 ,180 )
  RGB888_TAN = 0xD2B48C,                   //  ( 210 ,180 ,140 )
  RGB888_TEAL = 0x008080,                  //  ( 000 ,128 ,128 )
  RGB888_THISTLE = 0xD8BFD8,               //  ( 216 ,191 ,216 )
  RGB888_TOMATO = 0xFF6347,                //  ( 255 ,099 ,071 )
  RGB888_TURQUOISE = 0x40E0D0,             //  ( 064 ,224 ,208 )
  RGB888_VIOLET = 0xEE82EE,                //  ( 238 ,130 ,238 )
  RGB888_WHEAT = 0xF5DEB3,                 //  ( 245 ,222 ,179 )
  RGB888_WHITE = 0xFFFFFF,                 //  ( 255 ,255 ,255 )
  RGB888_WHITESMOKE = 0xF5F5F5,            //  ( 245 ,245 ,245 )
  RGB888_YELLOW = 0xFFFF00,                //  ( 255 ,255 ,000 )
  RGB888_YELLOWGREEN = 0x9ACD32,           //  ( 154 ,205 ,050 )
};
#endif

//
// des couleurs en format 332
//
// RRRGGGBB
//

#ifndef _RGB332_ERIC
#define _RGB332_ERIC
enum {
  RGB332_BLACK = 0,                   //  ( 000 ,000 ,000 )
  RGB332_MIDNIGHTBLUE = 1,            //  ( 025 ,025 ,112 )
  RGB332_DARKBLUE = 2,                //  ( 000 ,000 ,139 )
  RGB332_NAVY = 2,                    //  ( 000 ,000 ,128 )
  RGB332_BLUE = 3,                    //  ( 000 ,000 ,255 )
  RGB332_MEDIUMBLUE = 3,              //  ( 000 ,000 ,205 )
  RGB332_DARKGREEN = 12,              //  ( 000 ,100 ,000 )
  RGB332_GREEN = 16,                  //  ( 000 ,128 ,000 )
  RGB332_DARKCYAN = 18,               //  ( 000 ,139 ,139 )
  RGB332_TEAL = 18,                   //  ( 000 ,128 ,128 )
  RGB332_DODGERBLUE = 19,             //  ( 030 ,144 ,255 )
  RGB332_DEEPSKYBLUE = 23,            //  ( 000 ,191 ,255 )
  RGB332_DARKTURQUOISE = 27,          //  ( 000 ,206 ,209 )
  RGB332_LIME = 28,                   //  ( 000 ,255 ,000 )
  RGB332_SPRINGGREEN = 29,            //  ( 000 ,255 ,127 )
  RGB332_MEDIUMSPRINGGREEN = 30,      //  ( 000 ,250 ,154 )
  RGB332_AQUA = 31,                   //  ( 000 ,255 ,255 )
  RGB332_CYAN = 31,                   //  ( 000 ,255 ,255 )
  RGB332_DARKSLATEGREY = 41,          //  ( 047 ,079 ,079 )
  RGB332_FORESTGREEN = 48,            //  ( 034 ,139 ,034 )
  RGB332_SEAGREEN = 49,               //  ( 046 ,139 ,087 )
  RGB332_MEDIUMSEAGREEN = 53,         //  ( 060 ,179 ,113 )
  RGB332_LIGHTSEAGREEN = 54,          //  ( 032 ,178 ,170 )
  RGB332_LIMEGREEN = 56,              //  ( 050 ,205 ,050 )
  RGB332_INDIGO = 66,                 //  ( 075 ,000 ,130 )
  RGB332_DARKSLATEBLUE = 70,          //  ( 072 ,061 ,139 )
  RGB332_DARKOLIVEGREEN = 76,         //  ( 085 ,107 ,047 )
  RGB332_ROYALBLUE = 79,              //  ( 065 ,105 ,225 )
  RGB332_CADETBLUE = 82,              //  ( 095 ,158 ,160 )
  RGB332_STEELBLUE = 82,              //  ( 070 ,130 ,180 )
  RGB332_MEDIUMTURQUOISE = 91,        //  ( 072 ,209 ,204 )
  RGB332_TURQUOISE = 95,              //  ( 064 ,224 ,208 )
  RGB332_REBECCAPURPLE = 102,         //  ( 102 ,051 ,153 )
  RGB332_SLATEBLUE = 107,             //  ( 106 ,090 ,205 )
  RGB332_DIMGREY = 109,               //  ( 105 ,105 ,105 )
  RGB332_MEDIUMSLATEBLUE = 111,       //  ( 123 ,104 ,238 )
  RGB332_OLIVEDRAB = 112,             //  ( 107 ,142 ,035 )
  RGB332_LIGHTSLATEGRAY = 114,        //  ( 119 ,136 ,153 )
  RGB332_SLATEGRAY = 114,             //  ( 112 ,128 ,144 )
  RGB332_CORNFLOWERBLUE = 115,        //  ( 100 ,149 ,237 )
  RGB332_MEDIUMAQUAMARINE = 122,      //  ( 102 ,205 ,170 )
  RGB332_CHARTREUSE = 124,            //  ( 127 ,255 ,000 )
  RGB332_LAWNGREEN = 124,             //  ( 124 ,252 ,000 )
  RGB332_AQUAMARINE = 127,            //  ( 127 ,255 ,212 )
  RGB332_DARKRED = 128,               //  ( 139 ,000 ,000 )
  RGB332_MAROON = 128,                //  ( 128 ,000 ,000 )
  RGB332_DARKMAGENTA = 130,           //  ( 139 ,000 ,139 )
  RGB332_PURPLE = 130,                //  ( 128 ,000 ,128 )
  RGB332_DARKVIOLET = 131,            //  ( 148 ,000 ,211 )
  RGB332_BLUEVIOLET = 135,            //  ( 138 ,043 ,226 )
  RGB332_DARKORCHID = 135,            //  ( 153 ,050 ,204 )
  RGB332_SADDLEBROWN = 136,           //  ( 139 ,069 ,019 )
  RGB332_MEDIUMPURPLE = 143,          //  ( 147 ,112 ,219 )
  RGB332_OLIVE = 144,                 //  ( 128 ,128 ,000 )
  RGB332_GRAY = 146,                  //  ( 128 ,128 ,128 )
  RGB332_DARKSEAGREEN = 150,          //  ( 143 ,188 ,143 )
  RGB332_YELLOWGREEN = 152,           //  ( 154 ,205 ,050 )
  RGB332_LIGHTSKYBLUE = 155,          //  ( 135 ,206 ,250 )
  RGB332_SKYBLUE = 155,               //  ( 135 ,206 ,235 )
  RGB332_LIGHTGREEN = 158,            //  ( 144 ,238 ,144 )
  RGB332_PALEGREEN = 158,             //  ( 152 ,251 ,152 )
  RGB332_BROWN = 164,                 //  ( 165 ,042 ,042 )
  RGB332_FIREBRICK = 164,             //  ( 178 ,034 ,034 )
  RGB332_SIENNA = 168,                //  ( 160 ,082 ,045 )
  RGB332_MEDIUMORCHID = 171,          //  ( 186 ,085 ,211 )
  RGB332_DARKGOLDENROD = 176,         //  ( 184 ,134 ,011 )
  RGB332_ROSYBROWN = 178,             //  ( 188 ,143 ,143 )
  RGB332_DARKKHAKI = 181,             //  ( 189 ,183 ,107 )
  RGB332_DARKGREY = 182,              //  ( 169 ,169 ,169 )
  RGB332_LIGHTBLUE = 187,             //  ( 173 ,216 ,230 )
  RGB332_LIGHTSTEELBLUE = 187,        //  ( 176 ,196 ,222 )
  RGB332_GREENYELLOW = 188,           //  ( 173 ,255 ,047 )
  RGB332_PALETURQUOISE = 191,         //  ( 175 ,238 ,238 )
  RGB332_POWDERBLUE = 191,            //  ( 176 ,224 ,230 )
  RGB332_CRIMSON = 192,               //  ( 220 ,020 ,060 )
  RGB332_MEDIUMVIOLETRED = 194,       //  ( 199 ,021 ,133 )
  RGB332_INDIANRED = 201,             //  ( 205 ,092 ,092 )
  RGB332_CHOCOLATE = 204,             //  ( 210 ,105 ,030 )
  RGB332_PALEVIOLETRED = 206,         //  ( 219 ,112 ,147 )
  RGB332_ORCHID = 207,                //  ( 218 ,112 ,214 )
  RGB332_PERU = 208,                  //  ( 205 ,133 ,063 )
  RGB332_GOLDENROD = 212,             //  ( 218 ,165 ,032 )
  RGB332_BURLYWOOD = 214,             //  ( 222 ,184 ,135 )
  RGB332_TAN = 214,                   //  ( 210 ,180 ,140 )
  RGB332_PLUM = 215,                  //  ( 221 ,160 ,221 )
  RGB332_THISTLE = 215,               //  ( 216 ,191 ,216 )
  RGB332_GAINSBORO = 219,             //  ( 220 ,220 ,220 )
  RGB332_LIGHTGRAY = 219,             //  ( 211 ,211 ,211 )
  RGB332_SILVER = 219,                //  ( 192 ,192 ,192 )
  RGB332_RED = 224,                   //  ( 255 ,000 ,000 )
  RGB332_DEEPPINK = 226,              //  ( 255 ,020 ,147 )
  RGB332_FUCHSIA = 227,               //  ( 255 ,000 ,255 )
  RGB332_MAGENTA = 227,               //  ( 255 ,000 ,255 )
  RGB332_ORANGERED = 232,             //  ( 255 ,069 ,000 )
  RGB332_CORAL = 237,                 //  ( 255 ,127 ,080 )
  RGB332_TOMATO = 237,                //  ( 255 ,099 ,071 )
  RGB332_HOTPINK = 238,               //  ( 255 ,105 ,180 )
  RGB332_DARKORANGE = 240,            //  ( 255 ,140 ,000 )
  RGB332_DARKSALMON = 241,            //  ( 233 ,150 ,122 )
  RGB332_SALMON = 241,                //  ( 250 ,128 ,114 )
  RGB332_LIGHTCORAL = 242,            //  ( 240 ,128 ,128 )
  RGB332_VIOLET = 243,                //  ( 238 ,130 ,238 )
  RGB332_ORANGE = 244,                //  ( 255 ,165 ,000 )
  RGB332_LIGHTSALMON = 245,           //  ( 255 ,160 ,122 )
  RGB332_SANDYBROWN = 245,            //  ( 244 ,164 ,096 )
  RGB332_LIGHTPINK = 247,             //  ( 255 ,182 ,193 )
  RGB332_GOLD = 248,                  //  ( 255 ,215 ,000 )
  RGB332_NAVAJOWHITE = 250,           //  ( 255 ,222 ,173 )
  RGB332_PEACHPUFF = 250,             //  ( 255 ,218 ,185 )
  RGB332_WHEAT = 250,                 //  ( 245 ,222 ,179 )
  RGB332_PINK = 251,                  //  ( 255 ,192 ,203 )
  RGB332_YELLOW = 252,                //  ( 255 ,255 ,000 )
  RGB332_KHAKI = 254,                 //  ( 240 ,230 ,140 )
  RGB332_MOCCASIN = 254,              //  ( 255 ,228 ,181 )
  RGB332_PALEGOLDENROD = 254,         //  ( 238 ,232 ,170 )
  RGB332_ALICEBLUE = 255,             //  ( 240 ,248 ,255 )
  RGB332_ANTIQUEWHITE = 255,          //  ( 250 ,235 ,215 )
  RGB332_AZURE = 255,                 //  ( 240 ,255 ,255 )
  RGB332_BEIGE = 255,                 //  ( 245 ,245 ,220 )
  RGB332_BISQUE = 255,                //  ( 255 ,228 ,196 )
  RGB332_BLANCHEDALMOND = 255,        //  ( 255 ,235 ,205 )
  RGB332_CORNSILK = 255,              //  ( 255 ,248 ,220 )
  RGB332_FLORALWHITE = 255,           //  ( 255 ,250 ,240 )
  RGB332_GHOSTWHITE = 255,            //  ( 248 ,248 ,255 )
  RGB332_HONEYDEW = 255,              //  ( 240 ,255 ,240 )
  RGB332_IVORY = 255,                 //  ( 255 ,255 ,240 )
  RGB332_LAVENDER = 255,              //  ( 230 ,230 ,250 )
  RGB332_LAVENDERBLUSH = 255,         //  ( 255 ,240 ,245 )
  RGB332_LEMONCHIFFON = 255,          //  ( 255 ,250 ,205 )
  RGB332_LIGHTCYAN = 255,             //  ( 224 ,255 ,255 )
  RGB332_LIGHTGOLDENRODYELLOW = 255,  //  ( 250 ,250 ,210 )
  RGB332_LIGHTYELLOW = 255,           //  ( 255 ,255 ,224 )
  RGB332_LINEN = 255,                 //  ( 250 ,240 ,230 )
  RGB332_MINTCREAM = 255,             //  ( 245 ,255 ,250 )
  RGB332_MISTYROSE = 255,             //  ( 255 ,228 ,225 )
  RGB332_OLDLACE = 255,               //  ( 253 ,245 ,230 )
  RGB332_PAPAYAWHIP = 255,            //  ( 255 ,239 ,213 )
  RGB332_SEASHELL = 255,              //  ( 255 ,245 ,238 )
  RGB332_SNOW = 255,                  //  ( 255 ,250 ,250 )
  RGB332_WHITE = 255,                 //  ( 255 ,255 ,255 )
  RGB332_WHITESMOKE = 255,            //  ( 245 ,245 ,245 )
};
#endif
