# set -x 

ls -1 *.png | while read fic
do
echo "Fichier a traiter $fic"
# fic2=`echo $fic | rev | cut -f 2- -d '.' | rev`
fic2="`echo $fic |cut -f1 -d '.'`.raw"
echo ${fic2}
 if [ -f "$fic2" ]; then
   echo "${fic2} existe deja"
 else
   ffmpeg -vcodec png -i "${fic}" -vcodec rawvideo -f rawvideo -pix_fmt rgb565 ${fic2}
 fi
 
  /home/eric/Bureau/LangC/ficher2progmem/fichier2progmem ${fic2} > ${fic2}.h

done

echo  "// Most Icons are comming from 'https://icons8.com'" > icons.hpp
cat *.h >> icons.hpp

