#pragma once 

#include <stdint.h>

extern const uint8_t u8g2_font_timR08_tf[];
extern const uint8_t u8g2_font_timR10_tf[];
extern const uint8_t u8g2_font_timR12_tf[];
extern const uint8_t u8g2_font_timR14_tf[];
extern const uint8_t u8g2_font_timR18_tf[];
extern const uint8_t u8g2_font_timR24_tf[];
