/*
 * Copyright 2010, 2011, 2012 mapsforge.org
 *
 * This program is free software: you can redistribute it and/or modify it under the
 * terms of the GNU Lesser General Public License as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
 * PARTICULAR PURPOSE. See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 */

#include <cstdint>
#include <vector>
#include <list>
#include <string>
#include <cmath>
#define QT_NO_DEBUG_STREAM

#include "TileId.h"

// #include <qmath.h>
// #include <QString>



TileId::TileId(int x, int y, int z)
  : tileX(x),
    tileY(y),
    zoomLevel(z) {}

bool TileId::operator<(const TileId &other) const {
  if (zoomLevel < other.zoomLevel)
    return true;

  if (zoomLevel > other.zoomLevel)
    return false;

  if (zoomLevel == other.zoomLevel) printf("Q_ASSERT(zoomLevel == other.zoomLevel);\n");

  if (tileX < other.tileX)
    return true;

  if (tileX > other.tileX)
    return false;

  if (tileX == other.tileX) printf("Q_ASSERT(tileX == other.tileX);\n");

  if (tileY < other.tileY)
    return true;

  return false;
}

int64_t TileId::getMapSize(int8_t zoomLevel, unsigned short tileSize) {
  //  Q_ASSERT(zoomLevel >= 0 && QString("zoom level must not be negative: %1").arg(zoomLevel).constData());
  if (zoomLevel >= 0) printf("zoom level must not be negative: %d\n", zoomLevel);

  return (int64_t)tileSize << zoomLevel;
}

uint64_t TileId::getMaxTileNumber(int8_t zoomLevel) {
  // Q_ASSERT(zoomLevel >= 0 && QString("zoomLevel must not be negative: %1").arg(zoomLevel).toLatin1().constData());
  if (zoomLevel >= 0) printf("zoomLevel must not be negative: %d\n", zoomLevel);

  return (2 << (zoomLevel - 1)) - 1;
}

int64_t TileId::pixelX(unsigned short tileSize) const {
  return tileX * tileSize;
}

int64_t TileId::pixelY(unsigned short tileSize) const {
  return tileY * tileSize;
}

int64_t TileId::pixelXToTileX(double pixelX, int8_t zoomLevel, unsigned short tileSize) {
  return std::min<int64_t>(std::max<int64_t>(pixelX / tileSize, 0), std::pow(2, zoomLevel) - 1);
}

int64_t TileId::pixelYToTileY(double pixelY, int8_t zoomLevel, unsigned short tileSize) {
  return (int64_t)std::min<double>(std::max<double>(pixelY / tileSize, 0), std::pow(2, zoomLevel) - 1);
}
