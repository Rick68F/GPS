#include <Arduino.h>

#include <LovyanGFX.hpp>
#include <SPI.h>
// #include <lgfx_user/LGFX_ESP32_SC01_Plus.hpp>
// #include <lgfx_user/LGFX_ESP32S3_RGB_ESP32-8048S043.h>
#include <lgfx_user/LGFX_ESP32_S3_SSD1963.hpp>

static LGFX lcd;

#include "commun.hpp"
#include "couleurs.hpp"
#include "Couleurs332.hpp"
#include "ProgressBar.hpp"

//#define LOCAL_DISPLAY_HEIGHT 320
// #define LOCAL_DISPLAY_WIDTH 480

static const uint32_t Tuile_Size = 256;                         // taille x et y de la tuile
static const uint32_t Tuile_XLong = 3;                          // nbr de tuiles sur la longitude soit X
static const uint32_t Tuile_YLat = 3;                           // nbr de tuiles sur la latitude soit Y
static const uint32_t Taille_XLong = Tuile_XLong * Tuile_Size;  //taille en pixel du cache sur X ou Longitude
static const uint32_t Taille_YLat = Tuile_YLat * Tuile_Size;    //taille en pixel du cache sur Y ou Latitude
static const int32_t Taille_Fenetre = 256;
static const uint32_t Taille_Gpx = 64;
static const uint32_t Taille_Ywin = Taille_Fenetre / 2 - Taille_Gpx / 2;
static const uint32_t Taille_Xwin = Taille_Fenetre / 2 - Taille_Gpx / 2;

struct BoundBox {
  double m_minLongitude;
  double m_minLatitude;
  double m_maxLongitude;
  double m_maxLatitude;
} BB_Tuiles;

struct MAPLACE {
  double lat, lng;   // latitude et longitude
  int tuily, tuilx;  // numero de tuile
  int ty, tx;        // postition dans le tableau de cache des tuiles
  int py, px;        // postition pour le scroll pixel
  uint8_t zoom;
} ma_Place;
/*
  Listfiles

  This example shows how print out the files in a
  directory on a SD card

  The circuit:
   SD card attached to SPI bus as follows on RP2040:
   ************ SPI0 ************
   ** MISO (AKA RX) - pin 0, 4, or 16
   ** MOSI (AKA TX) - pin 3, 7, or 19
   ** CS            - pin 1, 5, or 17
   ** SCK           - pin 2, 6, or 18
   ************ SPI1 ************
   ** MISO (AKA RX) - pin  8 or 12
   ** MOSI (AKA TX) - pin 11 or 15
   ** CS            - pin  9 or 13
   ** SCK           - pin 10 or 14

  created   Nov 2010
  by David A. Mellis
  modified 9 Apr 2012
  by Tom Igoe
  modified 2 Feb 2014
  by Scott Fitzgerald
  modified 12 Feb 2023
  by Earle F. Philhower, III
  modified 26 Dec 2023
  by Richard Teel

  This example code is in the public domain.

*/

// This are GP pins for SPI0 on the Raspberry Pi Pico board, and connect
// to different *board* level pinouts.  Check the PCB while wiring.
// Only certain pins can be used by the SPI hardware, so if you change
// these be sure they are legal or the program will crash.
// See: https://datasheets.raspberrypi.com/picow/PicoW-A4-Pinout.pdf
// #define SDMMC 1

#include "FS.h"
#ifdef SDMMC
#include "SD_MMC.h"
#include "sdmmc_cmd.h"

// Default pins for ESP-S3
// Warning: ESP32-S3-WROOM-2 is using most of the default GPIOs (33-37) to interface with on-board OPI flash.
//   If the SD_MMC is initialized with default pins it will result in rebooting loop - please
//   reassign the pins elsewhere using the mentioned command `setPins`.
// Note: ESP32-S3-WROOM-1 does not have GPIO 33 and 34 broken out.
// Note: if it's ok to use default pins, you do not need to call the setPins
int clk = 2;
int cmd = 1;
int d0 = 40;
int d1 = 39;
int d2 = 42;
int d3 = 41;  // GPIO 34 is not broken-out on ESP32-S3-DevKitC-1 v1.1
#else
/*const int _MISO = 16;
const int _MOSI = 19;
const int _CS = 17;
const int _SCK = 18; */
// RP2040 ??

#include <SPI.h>
#include <SD.h>
#endif

File root;

#include "MapData.hpp"

// #include <fmt/core.h>

// #include <iomanip>
#include "header/latlon_osm_geo.hpp"
// #include <iostream>

using namespace std;
// typedef char byte;

MapFileReader reader;

#include "header/TileId.h"
#include "DrawBuf.hpp"

// osmtiles.setPsram(true);
// osmtiles.setColorDepth(lgfx::rgb332_1Byte);
// osmtiles.createSprite(TILE_SIZE * 3, TILE_SIZE * 3);
// bufosm.initBuff(osmtiles.getBuffer(),    0,     0,   TILE_SIZE * 3, TILE_SIZE * 3);



static LGFX_Sprite osmtiles;
DrawBuf bufosm;  // la classe

struct TAB_TUILE {
  int x_long;
  int y_lat;
} tab_tuile[Tuile_YLat][Tuile_XLong];

static LGFX_Sprite gpxtrack;
static LGFX_Sprite window(&lcd);

QueueHandle_t xQueue;
TaskHandle_t TaskTuile;
enum { LECTURE,
       WAIT };
int Status_TaskTuile = WAIT;

/* Define the structure type that will be passed on the queue. */
typedef struct DEMANDE {
  int dy, dx;      // ou la placer dans le sprite ou si yy xx zz sont a zero le scroll a effectuer
  int yy, xx, zz;  // yy,xx,zz la tuile demandée
} xTuileALire;

double llat;
double llon;
int zzoom;

uint8_t niveau_de_detail = VISU_SANS_BAT;  // VISU_MAXI

void BB_Carte();
void lit_tuile(int xx, int yy, int zz);


static void vReceiverTask(void *pvParameters) {
  // Declare the variable that will hold the values received from the  queue.
  BaseType_t xStatus;
  const TickType_t xTicksToWait = pdMS_TO_TICKS(100);
  Serial.print("Task1 is running on core ");
  Serial.println(xPortGetCoreID());

  DEMANDE tada;

  /* This task is also defined within an infinite loop. */
  for (;;) {
    /* This call should always find the queue empty because this task will
           immediately remove any data that is written to the queue. */
    /*  if (uxQueueMessagesWaiting(xQueue) != 0) {
      Serial.printf("Queue should have been empty!\r\n");  // n'a rien a voir puisque je balance x tuiles
    } */

    /* Receive data from the queue.

           The first parameter is the queue from which data is to be received.
           The queue is created before the scheduler is started, and therefore
           before this task runs for the first time.

           The second parameter is the buffer into which the received data will
           be placed. In this case the buffer is simply the address of a 
           variable that has the required size to hold the received data.

           The last parameter is the block time – the maximum amount of time 
           that the task will remain in the Blocked state to wait for data to 
           be available should the queue already be empty. */

    xStatus = xQueueReceive(xQueue, &tada, portMAX_DELAY);  //attente indefinie
    // xStatus = xQueueReceive(xQueue, &tada, xTicksToWait);

    if (xStatus == pdPASS) {
      Status_TaskTuile = LECTURE;
      /* Data was successfully received from the queue, print out the
               received value. */
      Serial.printf(" %d %d %d %d %d\n", tada.yy, tada.xx, tada.zz, tada.dy, tada.dx);
      if (tada.yy == 0) osmtiles.scroll(tada.dy, tada.dx);
      else lit_tuile(tada.dy, tada.dx, tada.yy, tada.xx, tada.zz);
      delay(5);  // evite le watch dog
      Status_TaskTuile = WAIT;
    } else {
      /* Data was not received from the queue even after waiting for 
               100ms. This must be an error as the sending tasks are free 
               running and will be continuously writing to the queue. */
      Serial.printf("Could not receive from the queue.\r\n");  // ne devrait pas arriver
    }
  }
}


void setup() {

  // Open serial communications and wait for port to open:
  Serial.begin(115200);
  lcd.init();
  delay(2000);
  while (!Serial) {
    delay(1);  // wait for serial port to connect. Needed for native USB port only
  }
  Serial.printf("\nTotal heap: %d\n", ESP.getHeapSize());
  Serial.printf("Free heap: %d\n", ESP.getFreeHeap());
  Serial.printf("Total PSRAM: %d\n", ESP.getPsramSize());
  Serial.printf("Free PSRAM: %d\n", ESP.getFreePsram());
  if (ESP.getPsramSize() == 0) {
    Serial.println("\nPlease activate PSRAM...");
    lcd.setTextColor(0x00FFFFU, 0xFF0000U);
    lcd.drawString("string!", 10, 10);

    while (1) {}
  }


  Serial.println("\nInitializing SD card...");
  Serial.printf("Running on %d\n", xPortGetCoreID());

  bool sdInitialized = false;

/* 3.5"
  static const uint8_t SS = 41;
  static const uint8_t MOSI = 40;
  static const uint8_t MISO = 38;
  static const uint8_t SCK = 39;
  // SPIClass SPI_SD(MOSI, MISO, SCK);
  // SPIClass SPI_SD(40,38,39);
  SPI.begin(39, 38, 40, -1);
  if (!SD.begin(41)) { */
#ifdef SDMMC
  if (!SD_MMC.setPins(clk, cmd, d0, d1, d2, d3)) {
    Serial.println("Pin change failed!");
    return;
  }
  // SD_MMC.begin("/root", true, false, SDMMC_FREQ_DEFAULT)
  if (!SD_MMC.begin()) {
#else
  if (!SD.begin()) {  // ecran 800*480
#endif
    Serial.println("Card Mount Failed");
    return;
  }

#ifdef SDMMC
  uint8_t cardType = SD_MMC.cardType();
#else
  uint8_t cardType = SD.cardType();
#endif

  if (cardType == CARD_NONE) {
    Serial.println("No SD card attached");
    return;
  }

  Serial.print("SD Card Type: ");
  if (cardType == CARD_MMC) {
    Serial.println("MMC");
  } else if (cardType == CARD_SD) {
    Serial.println("SDSC");
  } else if (cardType == CARD_SDHC) {
    Serial.println("SDHC");
  } else {
    Serial.println("UNKNOWN");
  }

#ifdef SDMMC
  uint64_t cardSize = SD_MMC.cardSize() / (1024 * 1024);
#else
  uint64_t cardSize = SD.cardSize() / (1024 * 1024);
#endif
  Serial.printf("SD Card Size: %lluMB\n", cardSize);

  uint16_t tab_coul[9] = { TFT_RED, TFT_GREEN, TFT_BLUE, TFT_ORANGE, TFT_WHITE, TFT_BLACK, TFT_BROWN, TFT_PINK, TFT_NAVY };
#if 0
  listDir(SD, "/", 0);
#endif
  osmtiles.setPsram(true);
  osmtiles.setColorDepth(lgfx::rgb332_1Byte);

  window.setPsram(true);
  window.setColorDepth(lgfx::rgb332_1Byte);
  window.createSprite(Taille_Fenetre, Taille_Fenetre);

  osmtiles.createSprite(Tuile_Size * Tuile_XLong, Tuile_Size * Tuile_YLat);
  bufosm.initBuff(osmtiles.getBuffer(), 0, 0, Tuile_Size * Tuile_XLong, Tuile_Size * Tuile_YLat, window.getBuffer());

  gpxtrack.setPsram(true);
  gpxtrack.setColorDepth(1);
  gpxtrack.createSprite(Taille_Gpx, Taille_Gpx);
  gpxtrack.setBitmapColor(TFT_RED, TFT_BLACK);
  gpxtrack.fillSprite(0);
  gpxtrack.drawCircle(32, 32, 10, 1);


  /* The queue is created to hold a maximum of  xxx  structures of tiles */
  xQueue = xQueueCreate(Tuile_YLat * Tuile_XLong, sizeof(xTuileALire));

  if (xQueue != NULL) {
    // creation de la tache qui va chager les tuiles dans le sprite
    xTaskCreatePinnedToCore(vReceiverTask, "Sender1", 10000, NULL, 1, &TaskTuile, 0);
    // xTaskCreatePinnedToCore(vReceiverTask, "Receiver", 10000, NULL, 2, &TaskTuile, 0);
    /* Start the scheduler so the created tasks start executing. */
    // vTaskStartScheduler();
  } else {
    Serial.printf("La file d'attente n'a pas pu etre creer\n");
    Serial.printf("donc pas de tuiles\n");
    Serial.printf("c'est la fin des haricots\n");
    while (1) {}
    /* The queue could not be created. */
  }

  // osmtiles.fillSprite(TFT_RED);
  for (int i = 0; i < Tuile_YLat; i++) {

    for (int j = 0; j < Tuile_XLong; j++) {
      // osmtiles.fillRect(i * TILE_SIZE, j * TILE_SIZE, TILE_SIZE, TILE_SIZE, GRASS);  //lcd.color565(3 + i * 4, (i + j) * 2, 3 + j * 4));
      // osmtiles.fillRect(i * TILE_SIZE, j * TILE_SIZE, TILE_SIZE, TILE_SIZE, lcd.color565(3 + i * 4, (i + j) * 2, 3 + j * 4));
      osmtiles.fillRect(i * Tuile_Size, j * Tuile_Size, Tuile_Size, Tuile_Size, tab_coul[i * Tuile_XLong + j]);  //lcd.color565(3 + i * 4, (i + j) * 2, 3 + j * 4));

      osmtiles.pushSprite(&lcd, 0, 0);
      // delay(1000);
    }
  }
  Serial.printf("\nTotal heap: %d\n", ESP.getHeapSize());
  Serial.printf("Free heap: %d\n", ESP.getFreeHeap());
  Serial.printf("Total PSRAM: %d\n", ESP.getPsramSize());
  Serial.printf("Free PSRAM: %d\n", ESP.getFreePsram());
  // Serial.printf("\nTaille Struct DICO %d\n", sizeof(DICO));

  Serial.println("Init done!");

  /*
  for (int k = 0; k < 10; k++) {
    delay(1000);
    osmtiles.scroll(10, -20);
    osmtiles.pushSprite(&lcd, 0, 0);
  }
*/


  // while (1) {}
}

void logMemory() {
  Serial.printf("Used PSRAM: %d\n", ESP.getPsramSize() - ESP.getFreePsram());
}

void print_tab_tuiles() {
  Serial.printf("\t");
  for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) Serial.printf("\ty_lat x_long");
  Serial.printf("\n\t");
  for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) Serial.printf("\t    %d\t", xxx);
  Serial.printf("\n");
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    Serial.printf("Tab tuile %d", yyy);
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      Serial.printf("\t%d\t%d", tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long);
    }
    Serial.printf("\n");
  }
  Serial.printf("\n");
}

void vers_gauche() {
  // osmtiles.scroll(Tuile_Size, 0);
  BaseType_t xStatus;
  DEMANDE ma_demande;

  ma_demande = { Tuile_Size, 0, 0, 0, 0 };
  xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
  if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Scroll\r\n");

  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      tab_tuile[yyy][xxx].x_long--;
    }
  }

  int_fast16_t xxx = 0;
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    // lit_tuile(yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom);
    ma_demande = { yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom };
    xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
    if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Tuile\r\n");
  }
}

void vers_droite() {
  //  osmtiles.scroll(-(Tuile_Size), 0);
  BaseType_t xStatus;
  DEMANDE ma_demande;
  ma_demande = { -(Tuile_Size), 0, 0, 0, 0 };
  xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
  if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Scroll\r\n");

  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      tab_tuile[yyy][xxx].x_long++;
    }
  }

  int_fast16_t xxx = Tuile_XLong - 1;
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    // lit_tuile(yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom);
    ma_demande = { yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom };
    xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
    if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Tuile\r\n");
  }
}

void vers_bas() {
  // osmtiles.scroll(0, -(Tuile_Size));
  BaseType_t xStatus;
  DEMANDE ma_demande;
  ma_demande = { 0, -(Tuile_Size), 0, 0, 0 };
  xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
  if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Scroll\r\n");
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      tab_tuile[yyy][xxx].y_lat++;
    }
  }

  int_fast16_t yyy = Tuile_YLat - 1;
  for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
    // lit_tuile(yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom);
    ma_demande = { yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom };
    xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
    if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Tuile\r\n");
  }
}

void vers_haut() {
  //osmtiles.scroll(0, Tuile_Size);
  BaseType_t xStatus;
  DEMANDE ma_demande;
  ma_demande = { 0, Tuile_Size, 0, 0, 0 };
  xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
  if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Scroll\r\n");
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      tab_tuile[yyy][xxx].y_lat--;
    }
  }

  int_fast16_t yyy = 0;
  for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
    //lit_tuile(yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom);
    ma_demande = { yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom };
    xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);
    if (xStatus != pdPASS) Serial.printf("Could not send to the queue. Tuile\r\n");
  }
}

void La_Tuile() {
  Serial.printf("\n1. La_Tuile %f %f %d - %d %d - %d %d - %d %d\n", ma_Place.lat, ma_Place.lng, ma_Place.zoom, ma_Place.tuily, ma_Place.tuilx, ma_Place.ty, ma_Place.tx, ma_Place.py, ma_Place.px);
  ma_Place.tuily = lat2tiley(ma_Place.lat, ma_Place.zoom);
  ma_Place.tuilx = long2tilex(ma_Place.lng, ma_Place.zoom);
  Serial.printf("2. La_Tuile %f %f %d - %d %d - %d %d - %d %d\n", ma_Place.lat, ma_Place.lng, ma_Place.zoom, ma_Place.tuily, ma_Place.tuilx, ma_Place.ty, ma_Place.tx, ma_Place.py, ma_Place.px);
}
void La_Place() {
  Serial.printf("\n1. La_Place %f %f %d - %d %d - %d %d - %d %d\n", ma_Place.lat, ma_Place.lng, ma_Place.zoom, ma_Place.tuily, ma_Place.tuilx, ma_Place.ty, ma_Place.tx, ma_Place.py, ma_Place.px);
  int pos_y = ma_Place.ty * Tuile_Size + (lat2tiley_d(ma_Place.lat, ma_Place.zoom) - ma_Place.tuily) * Tuile_Size;
  int pos_x = ma_Place.tx * Tuile_Size + (long2tilex_d(ma_Place.lng, ma_Place.zoom) - ma_Place.tuilx) * Tuile_Size;

  Serial.printf("\n1.1 La_Place %d %d\n", pos_y, pos_x);


  ma_Place.py = (lat2tiley_d(ma_Place.lat, ma_Place.zoom) - ma_Place.tuily) * Tuile_Size + (ma_Place.tuily - tab_tuile[ma_Place.ty][ma_Place.tx].y_lat + ma_Place.ty) * Tuile_Size;
  ma_Place.px = (long2tilex_d(ma_Place.lng, ma_Place.zoom) - ma_Place.tuilx) * Tuile_Size + (ma_Place.tuilx - tab_tuile[ma_Place.ty][ma_Place.tx].x_long + ma_Place.tx) * Tuile_Size;
  Serial.printf("2. La_Place %f %f %d - %d %d - %d %d - %d %d\n", ma_Place.lat, ma_Place.lng, ma_Place.zoom, ma_Place.tuily, ma_Place.tuilx, ma_Place.ty, ma_Place.tx, ma_Place.py, ma_Place.px);
}

// void draw_line(int x1, int y1, int x2, int y2, uint16_t couleur, int thickness = 1, int roundcap = false);
void atoidejouer() {
  Serial.printf("Taille LatY %d  longX %d  \n", Taille_YLat, Taille_XLong);
  Serial.printf("\n\nOn peu jouer maintenant\n");

  while (1) {


    if (Serial.available()) {  // If anything comes in Serial (USB),
      char c = Serial.read();
      Serial.printf("%c", c);
      switch (c) {
        case '8': ma_Place.lat += 0.0005; break;
        case '2': ma_Place.lat -= 0.0005; break;
        case '4': ma_Place.lng -= 0.0005; break;
        case '6': ma_Place.lng += 0.0005; break;
      }

      if (c != 10) {
        // ma_Place.lat = llat, ma_Place.lng = llon, ma_Place.zoom = zzoom;
        La_Tuile();
        La_Place();

        // Serial.printf("le moins %d %d \n", (ma_Place.tuily - tab_tuile[Tuile_Centre_YLat][Tuile_Centre_XLong].y_lat) + Tuile_Centre_YLat, (ma_Place.tuilx - tab_tuile[Tuile_Centre_YLat][Tuile_Centre_XLong].x_long) + Tuile_Centre_XLong);

        print_tab_tuiles();


        if (ma_Place.tuily < tab_tuile[ma_Place.ty][ma_Place.tx].y_lat) vers_haut();
        else if (ma_Place.tuily > tab_tuile[ma_Place.ty][ma_Place.tx].y_lat) vers_bas();
        if (ma_Place.tuilx < tab_tuile[ma_Place.ty][ma_Place.tx].x_long) vers_gauche();
        else if (ma_Place.tuilx > tab_tuile[ma_Place.ty][ma_Place.tx].x_long) vers_droite();


        /*if (ma_Place.py < Seuil_Scroll_Y) vers_haut();
        else if (ma_Place.py > (Taille_YLat - Seuil_Scroll_Y)) vers_bas();
        if (ma_Place.px < Seuil_Scroll_X) vers_gauche();
        else if (ma_Place.px > (Taille_XLong - Seuil_Scroll_X)) vers_droite();*/

        print_tab_tuiles();
        La_Tuile();
        La_Place();
        uint64_t mainstart1 = esp_timer_get_time();
        osmtiles.pushSprite(&window, 0 - (ma_Place.px - window.width() / 2), 0 - (ma_Place.py - window.height() / 2));
        uint64_t mainend1 = esp_timer_get_time();
        Serial.printf(" duree pushSprite %ld\n", mainend1 - mainstart1);
        // parcours.pushSprite(110, 110, 0);  //, TFT_RED);
        gpxtrack.pushSprite(&window, Taille_Xwin, Taille_Ywin, 0);  // le 0 fait que il n'affiche que la couleur choisie
        window.pushSprite(&lcd, 50, 50);
        uint64_t mainstart = esp_timer_get_time();
        bufosm.pushToWindow(650, 200);
        uint64_t mainend = esp_timer_get_time();
        Serial.printf(" duree pushTo %ld\n", mainend - mainstart);
        window.pushSprite(&lcd, 350, 50);
      }
    }
  }
}

void BB_Carte() {

  BB_Tuiles.m_minLatitude = tiley2lat(tab_tuile[Tuile_YLat - 1][Tuile_XLong - 1].y_lat + 1, zzoom);
  BB_Tuiles.m_minLongitude = tilex2long(tab_tuile[0][0].x_long, zzoom);
  BB_Tuiles.m_maxLatitude = tiley2lat(tab_tuile[0][0].y_lat, zzoom);
  BB_Tuiles.m_maxLongitude = tilex2long(tab_tuile[Tuile_YLat - 1][Tuile_XLong - 1].x_long + 1, zzoom);

  Serial.printf("\nBB tuiles %lf %lf %lf %lf\n", BB_Tuiles.m_minLatitude, BB_Tuiles.m_minLongitude, BB_Tuiles.m_maxLatitude, BB_Tuiles.m_maxLongitude);
}

void Carte_Initiale(double LatY, double LongX, int Zoom) {  // coordonnees GPS carte complète

  ma_Place.lat = LatY, ma_Place.lng = LongX, ma_Place.zoom = Zoom;
  ma_Place.ty = (Tuile_YLat - 1) / 2;
  ma_Place.tx = (Tuile_XLong - 1) / 2;

  La_Tuile();

  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      tab_tuile[yyy][xxx].y_lat = ma_Place.tuily + yyy - ma_Place.ty;
      tab_tuile[yyy][xxx].x_long = ma_Place.tuilx + xxx - ma_Place.tx;
    }
  }

  BB_Carte();
  print_tab_tuiles();
  // int_fast16_t lalong = long2tilex(llon, zzoom);
  // int_fast16_t lalat = lat2tiley(llat, zzoom);

  // lit_tuile(long2tilex(llon, zzoom), lat2tiley(llat, zzoom), zzoom);
}

void Charge_Les_Tuiles() {
  BaseType_t xStatus;
  DEMANDE ma_demande;
  for (int_fast16_t yyy = 0; yyy < Tuile_YLat; yyy++) {
    for (int_fast16_t xxx = 0; xxx < Tuile_XLong; xxx++) {
      ma_demande = { yyy * Tuile_Size, xxx * Tuile_Size, tab_tuile[yyy][xxx].y_lat, tab_tuile[yyy][xxx].x_long, zzoom };
      xStatus = xQueueSendToBack(xQueue, &ma_demande, 0);

      if (xStatus != pdPASS) {
        /* The send operation could not complete because the queue was full-
               this must be an error as the queue should never contain more than
               one item! */
        Serial.printf("Could not send to the queue.\r\n");
      }
    }
  }
}

void loop() {
  // nothing happens after setup finishes.
  uint64_t mainstart = esp_timer_get_time();

  lcd.fillScreen(TFT_BLACK);
  lcd.setTextSize(2);
  lcd.setRotation(2);
  lcd.setCursor(lcd.width() / 2, lcd.height() / 2);
  lcd.setTextColor(TFT_CYAN);
  lcd.print("/alsace.map");

  unsigned long om;

  bufosm.drawRoadSegment(30, 150, 210, 150, RGB332_YELLOW, NULL, 10, BORDER);
  bufosm.drawRoadSegment(50, 50, 200, 150, RGB332_WHITE, NULL, 3, BORDER);

  lcd.drawLine(30 + 10, 150, 210 + 10, 150, TFT_MAGENTA);

  Serial.println(" Alsace ");
  reader.open("/alsace.map");
  //    Serial.printf("?? %d  \n",info_.);
  // 20:41:57.105 ->   FILE: alsace.map  SIZE: 85340698
  // 20:41:57.138 ->   FILE: Alsace2.map  SIZE: 12684565
  // 20:41:57.201 ->   FILE: NordFrance.map  SIZE: 593145864
  llat = 47.88061373191233;
  llon = 7.228799782228023;
  zzoom = 16;


  //   while (1) {};

  // nouveau monde
  // llat = 47.873425204633634;
  // llon = 7.247569357522884;

  Serial.printf("Maison %f %f %d %d %d\n", llat, llon, lat2tiley(llat, zzoom), long2tilex(llon, zzoom), zzoom);



  Carte_Initiale(llat, llon, zzoom);  // calcul des tuiles initiales
  Charge_Les_Tuiles();                // affichage dans le cache

  // lit_tuile(8523, 5696, 14);
  // lit_tuile(8523, 5697, 14);
  // delay(3000);

  // affiche la carte centrée
  La_Place();
  ProgressBar TileBar;

  TileBar.initProgressBar(30, 100, 200, 20, 0, Tuile_YLat * Tuile_XLong);
  while (uxQueueMessagesWaiting(xQueue) != 0) {
    // Serial.printf("Queue should have been empty!\r\n");  // n'a rien a voir puisque je balance x tuiles
    TileBar.rendu(uxQueueMessagesWaiting(xQueue));
    delay(500);
  }
  while (Status_TaskTuile != WAIT) delay(50);

  osmtiles.pushSprite(&lcd, 0 - (ma_Place.px - lcd.width() / 2), 0 - (ma_Place.py - lcd.height() / 2));

  Serial.printf("\nTotal heap: %d\n", ESP.getHeapSize());
  Serial.printf("Free heap: %d\n", ESP.getFreeHeap());
  Serial.printf("Total PSRAM: %d\n", ESP.getPsramSize());
  Serial.printf("Free PSRAM: %d\n", ESP.getFreePsram());

  // logMemory();
  // byte *psdRamBuffer = (byte *)ps_malloc(500000);
  // logMemory();
  // free(psdRamBuffer);

  uint16_t tempo[512];
  /* scroll
  lcd.fillRect(0, 0, TAILLE_FENETRE + 20, TAILLE_FENETRE + 20, TFT_BLACK);
  for (int j = 256; j < 256 + 128; j++) {
    for (int i = 0; i < TAILLE_FENETRE; i++) {
      osmtiles.readRect(j, i, TAILLE_FENETRE, 1, (lgfx::rgb332_t *)tempo);
      lcd.pushImage(10, i + 10, TAILLE_FENETRE, 1, (lgfx::rgb332_t *)tempo, 0);
    }
    // delay(100);
  }*/
  logMemory();
  uint64_t mainend = esp_timer_get_time();
  Serial.printf(" duree %ld\n", mainend - mainstart);
  Serial.println(" Fin ");

  atoidejouer();

  while (1) {}
}



void listDir(fs::FS &fs, const char *dirname, uint8_t levels) {
  Serial.printf("Listing directory: %s\n", dirname);

  File root = fs.open(dirname);
  if (!root) {
    Serial.println("Failed to open directory");
    return;
  }
  if (!root.isDirectory()) {
    Serial.println("Not a directory");
    return;
  }

  File file = root.openNextFile();
  while (file) {
    if (file.isDirectory()) {
      Serial.print("  DIR : ");
      Serial.println(file.name());
      if (levels) {
        listDir(fs, file.path(), levels - 1);
      }
    } else {
      Serial.print("  FILE: ");
      Serial.print(file.name());
      Serial.print("  SIZE: ");
      Serial.println(file.size());
    }
    file = root.openNextFile();
  }
}
