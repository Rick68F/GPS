#include <cstdio>
#include <iostream>
#include <cstdint>
#include <cmath>
#include <algorithm>
#include "src/latlon_osm_geo.hpp"

struct tui_geo {
  uint16_t lat;
  uint16_t lon;
};

static const int max_x = 3;
static const int max_y = 3;

tui_geo tui_tui[max_y][max_x];

int lalong;
int lalat;

void print_table() {
  // printf("lon_x %6d lat_y %6d\t\tlon %f lat %f\n\n", lalong, lalat, llon, llat);
  for (int l_on = 0; l_on < max_y; l_on++) {
    for (int l_at = 0; l_at < max_y; l_at++) {
      printf("\t%6d/%6d", tui_tui[l_on][l_at].lon, tui_tui[l_on][l_at].lat);
    }
    printf("\n");
  }
}
#define CENTRE 1

void init_table() {
  for (int la_lon = 0; la_lon < max_y; la_lon++) {
    for (int la_lat = 0; la_lat < max_y; la_lat++) {
      tui_tui[la_lat][la_lon].lat = lalat + la_lat - CENTRE;
      tui_tui[la_lat][la_lon].lon = lalong + la_lon - CENTRE;
    }
  }
}

void maj_position() {
  lalong = long2tilex(llon, zzoom);
  lalat = lat2tiley(llat, zzoom);
}

void shift_right() {
  printf("Right\n");
  int x, y;
  // max_lon_x
  for (y = 0; y < max_y; y++) {        //y
    for (x = 0; x < max_x - 1; x++) {  //x
      tui_tui[y][x].lon = tui_tui[y][x + 1].lon;
    }
    tui_tui[y][x].lon = tui_tui[y][x - 1].lon + 1;
  }
}
void shift_left() {
  printf("Left\n");
  int x, y;
  for (y = 0; y < max_y; y++) {        //y
    for (x = max_x - 1; x > 0; x--) {  //x
      tui_tui[y][x].lon = tui_tui[y][x - 1].lon;
    }
    tui_tui[y][x].lon = tui_tui[y][x + 1].lon - 1;
  }
}
void shift_up() {
  printf("Up\n");
  int x, y;
  for (x = 0; x < max_x; x++) {        //x
    for (y = max_y - 1; y > 0; y--) {  //y
      tui_tui[y][x].lat = tui_tui[y - 1][x].lat;
    }
    tui_tui[y][x].lat = tui_tui[y + 1][x].lat - 1;
  }
}

void shift_down() {
  printf("Down\n");
  int x, y;
  for (x = 0; x < max_x; x++) {        //x
    for (y = 0; y < max_y - 1; y++) {  //y
      tui_tui[y][x].lat = tui_tui[y + 1][x].lat;
    }
    tui_tui[y][x].lat = tui_tui[y - 1][x].lat + 1;
  }
}

/*
int main_nnnn() {

  maj_position();
  init_table();

  print_table();
  int ch;
  while ((ch = std::cin.get()) != 0) {
    if (ch != 10) printf("Received Input: %c %d\n", ch, ch);
    switch (ch) {
      case '2': llat -= .004; break;
      case '4': llon -= .004; break;
      case '6': llon += .004; break;
      case '8': llat += .004; break;
    }
    maj_position();
    // if ((tui_tui[2][2].lon > lalong) && (ch = '2')) shift_down();
    // if (tui_tui[2][2].lat > lalat) shift_left();
    // if (tui_tui[2][2].lat < lalat) shift_right();
    // if (tui_tui[2][2].lon < lalong) shift_up();
    if (ch != 10) {
      if ((tui_tui[CENTRE][CENTRE].lat < lalat) && (ch == '2')) shift_down();
      if ((tui_tui[CENTRE][CENTRE].lat > lalat) && (ch == '8')) shift_up();
      if ((tui_tui[CENTRE][CENTRE].lon > lalong) && (ch == '4')) shift_left();
      if ((tui_tui[CENTRE][CENTRE].lon < lalong) && (ch == '6')) shift_right();
      print_table();
    }
  }
  return 0;
}
*/