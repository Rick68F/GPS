#ifndef __CHASSE_BUG_HPP__
#define __CHASSE_BUG_HPP__

#include "mapsforge_map_reader.hpp"
#include <iostream>
#include <string>

using std::cin;
using std::cout;
using std::endl;
using std::string;
 


#endif