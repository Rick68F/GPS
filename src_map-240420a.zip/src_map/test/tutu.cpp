// splicing lists
#include <iostream>
#include <list>
#include <vector>

using namespace std;

int main ()
{
  std::list<int> mylist1, mylist2, mylist3;
  std::vector<int> myvect1;
  std::list<int>::iterator it;
  std::vector<int>::iterator itv;

  // set some initial values:
  for (int i=1; i<=4; ++i)
     mylist1.push_back(i);      // mylist1: 1 2 3 4

  for (int i=1; i<=3; ++i)
     mylist2.push_back(i*10);   // mylist2: 10 20 30

for (int i=1; i<=3; ++i)
     mylist3.push_back(i*3);   // mylist2: 10 20 30

for (int i=1; i<=3; ++i)
     myvect1.push_back(i*43);   // mylist2: 10 20 30

  it = mylist1.begin();
  ++it;                         // points to 2

  mylist1.splice (it, mylist2); // mylist1: 1 10 20 30 2 3 4
                                // mylist2 (empty)
                                // "it" still points to 2 (the 5th element)
                                          
  mylist2.splice (mylist2.begin(),mylist1, it);
                                // mylist1: 1 10 20 30 3 4
                                // mylist2: 2
                                // "it" is now invalid.
  
  it = mylist1.begin();
  std::advance(it,3);           // "it" points now to 30

  mylist1.splice ( mylist1.begin(), mylist1, it, mylist1.end());
                                // mylist1: 30 3 4 1 10 20

  std::cout << "mylist1 contains:";
  for (it=mylist1.begin(); it!=mylist1.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';

  std::cout << "mylist2 contains:";
  for (it=mylist2.begin(); it!=mylist2.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';

  std::cout << "mylist3 contains:";
  for (it=mylist3.begin(); it!=mylist3.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';
  
  std::cout << "myvect1 contains:";
  for (itv=myvect1.begin(); itv!=myvect1.end(); ++itv)
    std::cout << ' ' << *itv;
  std::cout << '\n';
  
it = mylist1.end();

  mylist1.splice ( mylist1.end(), mylist3);
                                // mylist1: 30 3 4 1 10 20

std::cout << "myvect1 contains:";
 // for ( auto itvv=myvect1.begin(); itvv!=myvect1.end(); ++itvv)
 //   std::cout << ' ' << *itvv;
 //   mylist1.push_back(*itvv);
 // std::cout << '\n';
  
  for (auto& itit : myvect1) {
    cout << itit << endl;
     mylist1.push_back(itit);
}
  std::cout << "mylist1 contains:";
  for (it=mylist1.begin(); it!=mylist1.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';

  std::cout << "mylist2 contains:";
  for (it=mylist2.begin(); it!=mylist2.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';

  std::cout << "mylist3 contains:";
  for (it=mylist3.begin(); it!=mylist3.end(); ++it)
    std::cout << ' ' << *it;
  std::cout << '\n';

  std::cout << "myvect1 contains:";
  for (itv=myvect1.begin(); itv!=myvect1.end(); ++itv)
    std::cout << ' ' << *itv;
  std::cout << '\n';
  
  return 0;
}
