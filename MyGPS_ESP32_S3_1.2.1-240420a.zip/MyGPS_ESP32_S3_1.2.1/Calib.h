// ex de calib en fin de fichier
// calibration values
float xCalM = 0.0, yCalM = 0.0;  // gradients
float xCalC = 0.0, yCalC = 0.0;  // y axis crossing points

int8_t blockWidth = 20;  // block size
int8_t blockHeight = 20;
int16_t blockX = 0, blockY = 0;  // block position (pixels)

enum { STATUS_ACTIF = 0,
       STATUS_CACHE,
       STATUS_BARRE,
       STATUS_BARRE2
};

class ScreenPoint {
public:
  int16_t x;
  int16_t y;

  ScreenPoint() {
    // default contructor
  }

  ScreenPoint(int16_t xIn, int16_t yIn) {
    x = xIn;
    y = yIn;
  }
};

class Button {
public:

  int16_t x;
  int16_t y;
  int16_t width;
  int16_t height;
  char *text;
  const uint16_t *Bitmap;
  uint8_t actif;
  uint8_t txtsize;
  uint16_t coul_contour;
  uint16_t coul_fill;
  uint16_t coul_text;
  bool rev;

  Button() {
  }

  //  void initButton(int xPos, int yPos, int butWidth, int butHeight, char *butText) {
  void initButton(int16_t xPos, int16_t yPos, int16_t butWidth, int16_t butHeight, char *butText, const uint16_t *bufBitmap = NULL, uint8_t boutonactif = 0, uint8_t textsize = 2, uint16_t couleur_contour = TFT_WHITE, uint16_t fill = TFT_BLACK, uint16_t textcolor = TFT_GREEN) {
    x = xPos;
    y = yPos;
    width = butWidth;
    height = butHeight;
    text = butText;
    txtsize = textsize;
    actif = boutonactif;
    Bitmap = bufBitmap;
    coul_contour = couleur_contour;
    coul_fill = fill;
    coul_text = textcolor;
    rev = false;
    render();
  }

  void changeBitmap(const uint16_t *bufBitmap) {
    Bitmap = bufBitmap;
    render();
  }

  void changeStatus(uint8_t boutonactif) {
    actif = boutonactif;
    render();
  }

  void revert() {
    rev = !rev;
    render();
  }

  void render() {
    if (Bitmap == NULL) {
      tft.fillRect(x, y, width, height, (rev ? coul_text : coul_fill));  // draw rectangle
      tft.drawRect(x, y, width, height, coul_contour);                   // draw rectangle
      tft.setTextColor((rev ? coul_fill : coul_text));
      tft.setTextFont(txtsize);
      tft.drawString(text, x + 3, y + 1);
    } else {
      switch (actif) {
        case STATUS_ACTIF: tft.pushImage(x, y, width, height, Bitmap); break;
        case STATUS_CACHE: tft.fillRect(x, y, width, height, TFT_BLACK); break;
        case STATUS_BARRE:
          tft.pushImage(x, y, width, height, Bitmap);
          tft.drawLine(x, y, x + width, y + height, TFT_WHITE);
          tft.drawLine(x + 1, y, x + width - 1, y + height, TFT_BLACK);
          tft.drawLine(x, y + 1, x + width, y + height - 1, TFT_BLACK);
          tft.drawLine(x, y + height, x + width, y, TFT_WHITE);
          tft.drawLine(x + 1, y + height, x + width - 1, y, TFT_BLACK);
          tft.drawLine(x, y + height + 1, x + width, y + 1, TFT_BLACK);
          break;
        case STATUS_BARRE2:
          tft.pushImage(x, y, width, height, Bitmap);
          tft.drawLine(x, y, x + (width - 1), y + (height - 1), TFT_WHITE);
          tft.drawLine(x + 1, y, x + (width - 1), y + (height - 1) - 1, TFT_BLACK);
          tft.drawLine(x, y + 1, x + (width - 1) - 1, y + (height - 1), TFT_BLACK);
          tft.drawLine(x, y + (height - 1), x + (width - 1), y, TFT_WHITE);
          tft.drawLine(x + 1, y + (height - 1), x + (width - 1), y + 1, TFT_BLACK);
          tft.drawLine(x, y + (height - 1) - 1, x + (width - 1) - 1, y, TFT_BLACK);
          break;
      }
    }
  }

  bool isClicked(ScreenPoint sp) {
    if ((sp.x >= x) && (sp.x <= (x + width)) && (sp.y >= y) && (sp.y <= (y + height)) && (actif == STATUS_ACTIF)) {
      return true;
    } else {
      return false;
    }
  }
};

// Button button;

#define NBRE_ITEM_MENU 10
uint8_t menu_depart = 0;
Button boutons_Menu[NBRE_ITEM_MENU];
char ButtonBuf[NBRE_ITEM_MENU][32];
#define NBRE_ITEM_ACTION 12
uint8_t choix_action = 0;
Button boutons_Action[NBRE_ITEM_ACTION];


// ecran 8bits parallel config 517
// x1 = 3511, y1 = 474 x2 = 399, y2 = 3578
// xCalM = -0.09, xCalC = 335.90 yCalM = 0.06, yCalC = -10.54
// calibrateTouchScreen();
// calibrateCalc(3513, 484, 420, 3622);
/*x1 = 3715, y1 = 524, x2 = 539, y2 = 3612
xCalM = -0.09, xCalC = 347.52, yCalM = 0.06, yCalC = -13.94
x1 = 3513, y1 = 484x2 = 420, y2 = 3622
xCalM = -0.09, xCalC = 338.02yCalM = 0.06, yCalC = -10.85
x1 = 3695, y1 = 512, x2 = 565, y2 = 3627
x1 = 3685, y1 = 552, x2 = 561, y2 = 3669
xCalM = -0.09, xCalC = 350.28, yCalM = 0.06, yCalC = -15.42
*/
// config ecran spi config 518 (ili9488 480x320)
// x1 = 3797, y1 = 3652, x2 = 361, y2 = 421
// xCalM = -0.13, xCalC = 506.23, yCalM = -0.09, yCalC = 336.48
//x1 = 3790, y1 = 3663, x2 = 368, y2 = 425
//xCalM = -0.13, xCalC = 507.32, yCalM = -0.09, yCalC = 336.75
//x1 = 3816, y1 = 3665, x2 = 346, y2 = 425
//xCalM = -0.13, xCalC = 503.87, yCalM = -0.09, yCalC = 336.73


//