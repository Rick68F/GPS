//void my_tile(int tx_offset, int ty_offset, uint8_t zoom) {
void my_tile_ram(int tllng, int tllat, int xxx, int yyy) {

  int ll_lng = tllng - TUILE_BASE_LNG + xxx;
  int ll_lat = tllat - TUILE_BASE_LAT + yyy;

  Serial.printf("----> %d %d %d %d\n", xxx, yyy, ll_lng, ll_lat);

  DataTuile = &Tuiles[xxx][yyy];

  Serial.printf("Tblng %d Tblat %d dlng %d  dlat %d\n", Tbase.lng, Tbase.lat, tllng, tllat);
  Serial.printf("------ dlng %d  dlat %d\n", ll_lng, ll_lat);

  // int16_t rc = png.openFLASH((uint8_t *)Tiles[tllng - ty_lng][tllat - ty_lat], Tsbase[tllng - ty_lng][tllat - ty_lat], pngDraw);
  int16_t rc = png.openFLASH((uint8_t *)Tiles[ll_lng][ll_lat], Tsbase[ll_lng][ll_lat], pngDraw);
  // rc = png.openFLASH((uint8_t *)t16_34084_22814, sizeof(t16_34084_22814), pngDraw);
  // Serial.printf("image specs: (%d x %d), %d bpp, pixel type: %d\n", png.getWidth(), png.getHeight(), png.getBpp(), png.getPixelType());

  if (rc == PNG_SUCCESS) {
    rc = png.decode(NULL, 0);
    png.close();
  }
}