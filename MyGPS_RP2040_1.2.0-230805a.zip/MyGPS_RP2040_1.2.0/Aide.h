
/*
  Serial.println(gps.location.lat(), 6); // Latitude in degrees (double)
  Serial.println(gps.location.lng(), 6); // Longitude in degrees (double)
  Serial.print(gps.location.rawLat().negative ? "-" : "+");
  Serial.println(gps.location.rawLat().deg); // Raw latitude in whole degrees
  Serial.println(gps.location.rawLat().billionths);// ... and billionths (u16/u32)
  Serial.print(gps.location.rawLng().negative ? "-" : "+");
  Serial.println(gps.location.rawLng().deg); // Raw longitude in whole degrees
  Serial.println(gps.location.rawLng().billionths);// ... and billionths (u16/u32)
  Serial.println(gps.date.value()); // Raw date in DDMMYY format (u32)
  Serial.println(gps.date.year()); // Year (2000+) (u16)
  Serial.println(gps.date.month()); // Month (1-12) (u8)
  Serial.println(gps.date.day()); // Day (1-31) (u8)
  Serial.println(gps.time.value()); // Raw time in HHMMSSCC format (u32)
  Serial.println(gps.time.hour()); // Hour (0-23) (u8)
  Serial.println(gps.time.minute()); // Minute (0-59) (u8)
  Serial.println(gps.time.second()); // Second (0-59) (u8)
  Serial.println(gps.time.centisecond()); // 100ths of a second (0-99) (u8)
  Serial.println(gps.speed.value()); // Raw speed in 100ths of a knot (i32)
  Serial.println(gps.speed.knots()); // Speed in knots (double)
  Serial.println(gps.speed.mph()); // Speed in miles per hour (double)
  Serial.println(gps.speed.mps()); // Speed in meters per second (double)
  Serial.println(gps.speed.kmph()); // Speed in kilometers per hour (double)
  Serial.println(gps.course.value()); // Raw course in 100ths of a degree (i32)
  Serial.println(gps.course.deg()); // Course in degrees (double)
  Serial.println(gps.altitude.value()); // Raw altitude in centimeters (i32)
  Serial.println(gps.altitude.meters()); // Altitude in meters (double)
  Serial.println(gps.altitude.miles()); // Altitude in miles (double)
  Serial.println(gps.altitude.kilometers()); // Altitude in kilometers (double)
  Serial.println(gps.altitude.feet()); // Altitude in feet (double)
  Serial.println(gps.satellites.value()); // Number of satellites in use (u32)
  Serial.println(gps.hdop.value()); // Horizontal Dim. of Precision (100ths-i32)
  

  Besoin de quoi 
  Entete
  Serial.println(gps.date.value()); // Raw date in DDMMYY format (u32) 4 octets
  Serial.println(gps.time.value()); // Raw time in HHMMSSCC format (u32)
  Serial.println(gps.satellites.value()); // Number of satellites in use (u32)                  3x4 12
  
  Corps
  Serial.println(gps.location.lat(), 6); // Latitude in degrees (double) 8 octets               8
  Serial.println(gps.location.lng(), 6); // Longitude in degrees (double)                       +8
  Serial.println(gps.speed.kmph()); // Speed in kilometers per hour (double)                    +8  
  Serial.println(gps.course.value()); // Raw course in 100ths of a degree (i32) 4 octets        +4
  Serial.println(gps.altitude.value()); // Raw altitude in centimeters (i32)                    +4  3x8+2x4 = 24 + 8 = 32
  */


  /* 
 Different hardware manufacturers use different colour order
 configurations at the hardware level.  This may result in
 incorrect colours being displayed.

 Incorrectly displayed colours could also be the result of
 using the wrong display driver in the library setup file.

 Typically displays have a control register (MADCTL) that can
 be used to set the Red Green Blue (RGB) colour order to RGB
 or BRG so that red and blue are swapped on the display.

 This control register is also used to manage the display
 rotation and coordinate mirroring. The control register
 typically has 8 bits, for the ILI9341 these are:

 Bit Function
 7   Mirror Y coordinate (row address order)
 6   Mirror X coordinate (column address order)
 5   Row/column exchange (for rotation)
 4   Refresh direction (top to bottom or bottom to top in portrait orientation)
 3   RGB order (swaps red and blue)
 2   Refresh direction (top to bottom or bottom to top in landscape orientation)
 1   Not used
 0   Not used

 The control register bits can be written with this example command sequence:
 
    tft.writecommand(TFT_MADCTL);
    tft.writedata(0x48);          // Bits 6 and 3 set
    
 0x48 is the default value for ILI9341 (0xA8 for ESP32 M5STACK)
 in rotation 0 orientation.
 
 Another control register can be used to "invert" colours,
 this swaps black and white as well as other colours (e.g.
 green to magenta, red to cyan, blue to yellow).
 
 To invert colours insert this line after tft.init() or tft.begin():

    tft.invertDisplay( invert ); // Where invert is true or false

*/

/*
void setup(void) {
  tft.init();

  tft.fillScreen(TFT_BLACK);

  // Set "cursor" at top left corner of display (0,0) and select font 4
  tft.setCursor(0, 0, 4);

  // Set the font colour to be white with a black background
  tft.setTextColor(TFT_WHITE, TFT_BLACK);

  // We can now plot text on screen using the "print" class
  tft.println("Initialised default\n");
  tft.println("White text");

  tft.setTextColor(TFT_RED, TFT_BLACK);
  tft.println("Red text");

  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.println("Green text");

  tft.setTextColor(TFT_BLUE, TFT_BLACK);
  tft.println("Blue text");

  delay(5000);
}

void loop() {

  tft.invertDisplay(false);  // Where i is true or false

  tft.fillScreen(TFT_BLACK);

  tft.setCursor(0, 0, 4);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.println("Invert OFF\n");

  tft.println("White text");

  tft.setTextColor(TFT_RED, TFT_BLACK);
  tft.println("Red text");

  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.println("Green text");

  tft.setTextColor(TFT_BLUE, TFT_BLACK);
  tft.println("Blue text");

  delay(5000);


  // Binary inversion of colours
  tft.invertDisplay(true);  // Where i is true or false

  tft.fillScreen(TFT_BLACK);

  tft.setCursor(0, 0, 4);

  tft.setTextColor(TFT_WHITE, TFT_BLACK);
  tft.println("Invert ON\n");

  tft.println("White text");

  tft.setTextColor(TFT_RED, TFT_BLACK);
  tft.println("Red text");

  tft.setTextColor(TFT_GREEN, TFT_BLACK);
  tft.println("Green text");

  tft.setTextColor(TFT_BLUE, TFT_BLACK);
  tft.println("Blue text");

  delay(5000);
} */

/*
*
* Read and write demo of the AT24CX library
* Written by Christian Paul, 2014-11-24
* 
* 
*/
/*
// include libraries
#include <Wire.h>
#include <AT24CX.h>

// EEPROM object
AT24CX mem;

// setup
void setup() {
  // serial init
  Serial.begin(115200);
  Serial.println("AT24CX read/write demo");
  Serial.println("----------------------");
}

// main loop
void loop() {
  // read and write byte
  Serial.println("Write 42 to address 12");
  mem.write(12, 42);
  Serial.println("Read byte from address 12 ...");
  byte b = mem.read(12);
  Serial.print("... read: ");
  Serial.println(b, DEC);
  Serial.println();
  
  // read and write integer
  Serial.println("Write 65000 to address 15");
  mem.writeInt(15, 65000);
  Serial.println("Read integer from address 15 ...");
  unsigned int i = mem.readInt(15);
  Serial.print("... read: ");
  Serial.println(i, DEC);
  Serial.println();

  // read and write long
  Serial.println("Write 3293732729 to address 20");
  mem.writeLong(20, 3293732729UL);
  Serial.println("Read long from address 20 ...");
  unsigned long l = mem.readLong(20);
  Serial.print("... read: ");
  Serial.println(l, DEC);
  Serial.println();

  // read and write long
  Serial.println("Write 1111111111 to address 31");
  mem.writeLong(31, 1111111111);
  Serial.println("Read long from address 31 ...");
  unsigned long l2 = mem.readLong(31);
  Serial.print("... read: ");
  Serial.println(l2, DEC);
  Serial.println();
  
  // read and write float
  Serial.println("Write 3.14 to address 40");
  mem.writeFloat(40, 3.14);
  Serial.println("Read float from address 40 ...");
  float f = mem.readFloat(40);
  Serial.print("... read: ");
  Serial.println(f, DEC);
  Serial.println();  

  // read and write double
  Serial.println("Write 3.14159265359 to address 50");
  mem.writeDouble(50, 3.14159265359);
  Serial.println("Read double from address 50 ...");
  double d = mem.readDouble(50);
  Serial.print("... read: ");
  Serial.println(d, DEC);
  Serial.println();
  
  // read and write char
  Serial.print("Write chars: '");
  char msg[] = "This is a message";
  Serial.print(msg);
  Serial.println("' to address 200");
  mem.writeChars(200, msg, sizeof(msg));
  Serial.println("Read chars from address 200 ...");
  char msg2[30];
  mem.readChars(200, msg2, sizeof(msg2));
  Serial.print("... read: '");
  Serial.print(msg2);
  Serial.println("'");
  Serial.println();

  // write array of bytes 
  Serial.println("Write array of 80 bytes at address 1000");
  byte xy[] = {0,0,0,1,1,1,2,2,2,3,3,3,4,4,4,5,5,5,6,6,6,7,7,7,8,8,8,9,9,9,    // 10 x 3 = 30
              10,11,12,13,14,15,16,17,18,19,                                   //          10
              120,121,122,123,124,125,126,127,128,129,                         //          10
              130,131,132,133,134,135,136,137,138,139,                         //          10
              200,201,202,203,204,205,206,207,208,209,210,211,212,213,214,215,216,217,218,219};                   //          20
  mem.write(1000, (byte*)xy, sizeof(xy));

  // read bytes with multiple steps
  Serial.println("Read 80 single bytes starting at address 1000");
  for (int i=0; i<sizeof(xy); i++) {
    byte sb = mem.read(1000+i);
    Serial.print("[");
    Serial.print(1000+i);
    Serial.print("] = ");
    Serial.println(sb);
  } 
  Serial.println();

  // read bytes with one step
  Serial.println("Read 80 bytes with one operation at address 1000");
  byte z[80];
  memset(&z[0], 32, sizeof(z));
  mem.read(1000, z, sizeof(z));
  for (int i=0; i<sizeof(z); i++) {
    Serial.print("[");
    Serial.print(1000+i);
    Serial.print("] = ");
    Serial.println(z[i]);
  } 
  
  // stop
  while (1==1) {}
}
*/
//This example code is in the Public Domain (or CC0 licensed, at your option.)
//By Evandro Copercini - 2018
//
//This example creates a bridge between Serial and Classical Bluetooth (SPP)
//and also demonstrate that SerialBT have the same functionalities of a normal Serial
/*
#include "BluetoothSerial.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth is not enabled! Please run `make menuconfig` to and enable it
#endif

#if !defined(CONFIG_BT_SPP_ENABLED)
#error Serial Bluetooth not available or not enabled. It is only available for the ESP32 chip.
#endif

BluetoothSerial SerialBT;

void setup() {
  Serial.begin(115200);
  SerialBT.begin("ESP32test"); //Bluetooth device name
  Serial.println("The device started, now you can pair it with bluetooth!");
}

void loop() {
  if (Serial.available()) {
    SerialBT.write(Serial.read());
  }
  if (SerialBT.available()) {
    Serial.write(SerialBT.read());
  }
  delay(20);
}
*/
/*
// <<---------------------------------------------------------------------------//CFG-MSG packets:
 // <<---------------------------------------------------------------------------//off packets
 byte turn_Off_GPGGA[NMEA_LEN] = {//---------------------------------------------//GPGGA off
  0xB5, // Header char 1
  0x62, // Header char 2
  0x06, // class
  0x01, // id
  0x08, // length char 1
  0x00, // length char 2
  0xF0, // payload (NMEA sentence ID char 1)
  0x00, // payload (NMEA sentence ID char 2)
  0x00, // payload I/O Target 0 - DDC       - (1 - enable sentence, 0 - disable)
  0x00, // payload I/O Target 1 - Serial Port 1 - (1 - enable sentence, 0 - disable)
  0x00, // payload I/O Target 2 - Serial Port 2 - (1 - enable sentence, 0 - disable)
  0x00, // payload I/O Target 3 - USB       - (1 - enable sentence, 0 - disable)
  0x00, // payload I/O Target 4 - SPI       - (1 - enable sentence, 0 - disable)
  0x00, // payload I/O Target 5 - Reserved    - (1 - enable sentence, 0 - disable)
  0xFF, // CK_A
  0x23  // CK_B
 };

 // <<---------------------------------------------------------------------------//on packets
 byte turn_On_GPGGA[NMEA_LEN] = {//---------------------------------------------//GPGGA on
  0xB5, // Header char 1
  0x62, // Header char 2
  0x06, // class
  0x01, // id
  0x08, // length char 1
  0x00, // length char 2
  0xF0, // payload (NMEA sentence ID char 1)
  0x00, // payload (NMEA sentence ID char 2)
  0x01, // payload I/O Target 0 - DDC - (1 - enable sentence, 0 - disable)
  0x01, // payload I/O Target 1 - Serial Port 1 - (1 - enable sentence, 0 - disable)
  0x01, // payload I/O Target 2 - Serial Port 2 - (1 - enable sentence, 0 - disable)
  0x01, // payload I/O Target 3 - USB - (1 - enable sentence, 0 - disable)
  0x01, // payload I/O Target 4 - SPI - (1 - enable sentence, 0 - disable)
  0x01, // payload I/O Target 5 - Reserved - (1 - enable sentence, 0 - disable)
  0x05, // CK_A
  0x38  // CK_B
 };
 // <<---------------------------------------------------------------------------//CFG-MSG packets

 // <<---------------------------------------------------------------------------//CFG-RATE packets:
 byte updateFreq[FREQ_LEN] = {
  0xB5, // sync char 1
  0x62, // sync char 2
  0x06, // class
  0x08, // id
  0x06, // length
  0x00, // length
  0x64, // payload
  0x00, // payload
  0x01, // payload
  0x00, // payload
  0x01, // payload
  0x00, // payload
  0x7A, // CK_A
  0x12, // CK_B
 };
 // <<---------------------------------------------------------------------------//CFG-RATE packets

 // <<---------------------------------------------------------------------------//CFG-PRT packets:
 byte changeBaud[BAUD_LEN] = {
  0xB5, // sync char 1
  0x62, // sync char 2
  0x06, // class
  0x00, // id
  0x14, // length
  0x00, // length
  0x01, // payload
  0x00, // payload
  0x00, // payload
  0x00, // payload
  0xD0, // payload
  0x08, // payload
  0x00, // payload
  0x00, // payload
  0x00, // payload
  0xC2, // payload
  0x01, // payload
  0x00, // payload
  0x07, // payload
  0x00, // payload
  0x03, // payload
  0x00, // payload
  0x00, // payload
  0x00, // payload
  0x00, // payload
  0x00, // payload
  0xC0, // CK_A
  0x7E, // CK_B
 };*/
 // <<---------------------------------------------------------------------------//CFG-PRT packets
/*
  NMEA Baudrate Change Sentences
4800/8/N/1      $PSRF100,1,4800,8,1,0*0E
    9600/8/N/1      $PSRF100,1,9600,8,1,0*0D
   19200/8/N/1      $PSRF100,1,19200,8,1,0*38
   38400/8/N/1      $PSRF100,1,38400,8,1,0*3D

Till Next Time */

/*
//#include <NeoSWSerial.h>//Include Software Serial Library
#include <U8glib.h> // Include the OLED library
U8GLIB_SSD1306_128X64 u8g(U8G_I2C_OPT_NONE | U8G_I2C_OPT_DEV_0); // Define a certain part of the OLED library
#include "TinyGPS++.h"// include  GPS library


#define u8g_logo_sat_width 19                                   //
#define u8g_logo_sat_height 19                                  //
const unsigned char u8g_logo_sat[] = {                          //
  //
  0x80, 0x1F, 0x00, 0xF0, 0x70, 0x00, 0x18, 0xC0, 0x00, 0x0C, 0x80, 0x01, //
  0x06, 0x02, 0x03, 0x02, 0x02, 0x02, 0x02, 0x02, 0x06, 0x03, 0x07, 0x04, //
  0x01, 0x07, 0x04, 0x01, 0x07, 0x04, 0x01, 0x07, 0x04, 0x83, 0x0D, 0x04, // GPS ICON Image
  0x82, 0x08, 0x02, 0x82, 0x08, 0x02, 0x06, 0x00, 0x03, 0x0C, 0x80, 0x01, //
  0x18, 0xC0, 0x00, 0x70, 0x70, 0x00, 0xC0, 0x1F, 0x00,          //
  //
};                                                              //
#define serial_connection Serial
//NeoSWSerial serial_connection(3, 4); //Define Serial Pins
TinyGPSPlus gps; // Define gps object
//Creating some variables:

double gps_speed;
double Lat;
double Long;
double timehour;
double timedistance;
double traveleddistancesum;
double traveleddistance;
double traveleddistance1;

//GPS Module Setup, this is sent in "void GPSSETUP()"
const unsigned char UBLOX_INIT[] PROGMEM = {
  //0xB5,0x62,0x06,0x08,0x06,0x00,0xF4,0x01,0x01,0x00,0x01,0x00,0x0B,0x77//(2 Hz)
 // 0xB5,0x62,0x06,0x08,0x06,0x00,0xC8,0x00,0x01,0x00,0x01,0x00,0xDE,0x6A, //(5Hz)
    //0xB5,0x62,0x06,0x08,0x06,0x00,0xC8,0x00,0x01,0x00,0x01,0x00,0xDE,0x6A, //(5Hz)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0xE8,0x03,0x01,0x00,0x01,0x00,0x01,0x39, //(1Hz)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0x64,0x00,0x01,0x00,0x01,0x00,0x7A,0x12, //(10Hz)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0xBC,0x02,0x01,0x00,0x01,0x00,0xD4,0x2C,//(1,43 Hz/700 ms)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0x58,0x02,0x01,0x00,0x01,0x00,0x70,0xD4, //(1,67Hz/600 ms)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0x64,0x00,0x01,0x00,0x01,0x00,0x7A,0x12, //(10Hz)
  //0xB5,0x62,0x06,0x08,0x06,0x00,0xE8,0x03,0x01,0x00,0x01,0x00,0x01,0x39 //(1Hz)
  0xB5, 0x62, 0x06, 0x08, 0x06, 0x00, 0xFA, 0x00, 0x01, 0x00, 0x01, 0x00, 0x10, 0x96, //(4HZ)

  // The next sentence will set the baudrate to the one you choose
  //0xB5,0x62,0x06,0x00,0x14,0x00,0x01,0x00,0x00,0x00,0xD0,0x08,0x00,0x00,0x00,0x96,0x00,0x00,0x23,0x00,0x02,0x00,0x00,0x00,0x00,0x00,0xAE,0x6A,
  0xB5, 0x62, 0x06, 0x00, 0x14, 0x00, 0x01, 0x00, 0x00, 0x00, 0xD0, 0x08, 0x00, 0x00, 0x00, 0x96, 0x00, 0x00, 0x23, 0x00, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0xAF, 0x70, // 38400
  //0xB5,0x62,0x06,0x00,0x14,0x00,0x01,0x00,0x00,0x00,0xD0,0x08,0x00,0x00,0x00,0xC2,0x01,0x00,0x23,0x00,0x03,0x00,0x00,0x00,0x00,0x00,0xDC,0x5E, //115200
};


void setup() {
Serial.begin(9600);
  GPSSETUP();
  // delay(1000);
}


void loop() {
  // Calculate traveled distance since the arduino is powered:
  traveleddistancesum = (gps.speed.mps() * (millis() - timedistance) / 1000);
  timedistance = millis();
  traveleddistance = ((traveleddistance + traveleddistancesum));
  traveleddistance1 = ((traveleddistance) / 1000);

  //---------------------------------------------------------------------------------------//
  //--------------------------------------Start GPS Prosess--------------------------------//
  //---------------------------------------------------------------------------------------//
  uint8_t GPSchar; //Creating a variable for the gps data


  while (1)
  {
    if (serial_connection.available() > 0)
    {


      GPSchar = serial_connection.read();


      gps.encode(GPSchar);

      //Serial.write(GPSchar);

    }

    if (gps.location.isUpdated() && gps.altitude.isUpdated())
    {
      break;// if gps location is updated than continue the loop
    }
  }
  
  // Setting variables:
  gps_speed = (gps.speed.kmph());
  Lat = (gps.location.lat());
  Long = (gps.location.lng());
  timehour = (gps.time.hour() + 1);

  //---------------------------------------------------------------------------------------//
  //--------------------------------Start Printing Prosess---------------------------------//
  //---------------------------------------------------------------------------------------//
  u8g.firstPage();

  do {
    u8g.setFont(u8g_font_unifont);

    u8g.setPrintPos(56, 43);
    u8g.print("km/h");


    u8g.setFont(u8g_font_profont29r);
    u8g.setPrintPos(0, 47);
    u8g.print(gps_speed , 0);
    u8g.setFont(u8g_font_6x10);
    u8g.setPrintPos(0, 62);
    u8g.print("N");
    u8g.setFont(u8g_font_6x10);
    u8g.setPrintPos(7, 62);
    u8g.print( Lat, 6);

    u8g.setPrintPos(73, 62);
    u8g.print("E");

    u8g.setPrintPos(80, 62);
    u8g.print( Long, 6);
    u8g.drawLine(0, 52, 128, 52);
    u8g.drawLine(0, 22, 128, 22);
    u8g.drawLine(89, 22, 89, 52);
    u8g.drawXBM(0, 0, u8g_logo_sat_width, u8g_logo_sat_height, u8g_logo_sat);
    u8g.setFont(u8g_font_unifont);
    u8g.setPrintPos(23, 15);
    if (((gps.course.deg()))  >= 0 && ((gps.course.deg())) <= 22.5) {
      u8g.print("Noord");
    }
    if (((gps.course.deg())) > 22.5 && ((gps.course.deg())) <= 67.5) {
      u8g.print("Noord - Oost");
    }
    if (((gps.course.deg())) > 67.5 && ((gps.course.deg())) <=  112.5 ) {
      u8g.print("Oost");
    }

    if (((gps.course.deg())) > 112.5 && (gps.course.deg()) <= 157.5) {
      u8g.print("Zuid - Oost");

    }
    if ((gps.course.deg()) > 157.5 && (gps.course.deg()) <= 202.5) {
      u8g.print("Zuid");
    }
    if ((gps.course.deg()) > 202.5 && (gps.course.deg()) <= 247.5) {
      u8g.print("Zuid - West");
    }
    if ((gps.course.deg()) > 247.5 && (gps.course.deg()) <= 292.5) {
      u8g.print("West");
    }
    if ((gps.course.deg()) > 292.5 && (gps.course.deg()) <= 337.5) {
      u8g.print("Noord - West");
    }
    if ((gps.course.deg()) > 337.5 && (gps.course.deg()) <= 361) {
      u8g.print("Noord");
    }
    u8g.setPrintPos(92, 49);
    u8g.setFont(u8g_font_6x10);
    if (traveleddistance < 1000 ) {


      u8g.print((traveleddistance), 0);

      u8g.setPrintPos(120, 49);
      u8g.print("M");
    }

    if (traveleddistance1 > 1 && traveleddistance1 < 100 ) {
      u8g.print((traveleddistance1));

    }
    if (traveleddistance1 > 100 ) {
      u8g.print((traveleddistance1), 1);

    }
    u8g.setFont(u8g_font_unifont);
    u8g.setPrintPos(90, 35);
    if (timehour > 23) {
      u8g.print("00");

    }


    else   {

      u8g.print(timehour, 0);
    }
    u8g.drawLine(89, 38, 128, 38);
    u8g.setPrintPos(111, 35);
    u8g.setFont(u8g_font_unifont);
    u8g.print(gps.time.minute());
    if ( (gps.time.second() % 2) == 0) { // this makes the dots blink (in the time bar)
      u8g.setFont(u8g_font_unifont);
      u8g.setPrintPos(105, 35);
      u8g.print(":");

    }
  }

  while (u8g.nextPage());



}
//---------------------------------------------------------------------------------------//
//--------------------------------Run the GPS setup once--------------------------------//
//---------------------------------------------------------------------------------------//
void GPSSETUP() {
  serial_connection.begin(9600);//
  // send configuration data in UBX protocol
  for (unsigned int i = 0; i < sizeof(UBLOX_INIT); i++) {
    serial_connection.write( pgm_read_byte(UBLOX_INIT + i) );
    delay(5); // simulating a 38400baud pace (or less), otherwise commands are not accepted by the device.

  }
  serial_connection.begin(38400);
//serial_connection.begin(115200);
  // send configuration data in UBX protocol
  for (unsigned int i = 0; i < sizeof(UBLOX_INIT); i++) {
    serial_connection.write( pgm_read_byte(UBLOX_INIT + i) );
    delay(5); // simulating a 38400baud pace (or less), otherwise commands are not accepted by the device.

  }

} */

// turn off all NMEA except GGA
/*
char RMC_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X04, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X03, 0X3F};
char VTG_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X05, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X04, 0X46};
char GSA_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X02, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X01, 0X31};
char GSV_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X03, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X02, 0X38};
char GLL_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X01, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X2A};
// char GGA_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0XFF, 0X23};
char GGA_On[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X00, 0X00, 0X01, 0X01, 0X00, 0X00, 0X00, 0X01, 0X2C};
char ZDA_Off[] = { 0XB5, 0X62, 0X06, 0X01, 0X08, 0X00, 0XF0, 0X08, 0X00, 0X00, 0X00, 0X00, 0X00, 0X00, 0X07, 0X5B};
*/

/*#include "FS.h"
//#include "SPIFFS.h" 
#include "LittleFS.h"
#include <time.h> 
#include <WiFi.h>

#define SPIFFS LittleFS
*/
/* This examples uses "quick re-define" of SPIFFS to run 
   an existing sketch with LittleFS instead of SPIFFS

   You only need to format LittleFS the first time you run a
   test or else use the LittleFS plugin to create a partition
   https://github.com/lorol/arduino-esp32littlefs-plugin */
   
/*
#define FORMAT_LITTLEFS_IF_FAILED true

const char* ssid     = "yourssid";
const char* password = "yourpass";

long timezone = 1; 
byte daysavetime = 1;

void listDir(fs::FS &fs, const char * dirname, uint8_t levels){
    Serial.printf("Listing directory: %s\n", dirname);

    File root = fs.open(dirname);
    if(!root){
        Serial.println("Failed to open directory");
        return;
    }
    if(!root.isDirectory()){
        Serial.println("Not a directory");
        return;
    }

    File file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            Serial.print("  DIR : ");
            Serial.print (file.name());
            time_t t= file.getLastWrite();
            struct tm * tmstruct = localtime(&t);
            Serial.printf("  LAST WRITE: %d-%02d-%02d %02d:%02d:%02d\n",(tmstruct->tm_year)+1900,( tmstruct->tm_mon)+1, tmstruct->tm_mday,tmstruct->tm_hour , tmstruct->tm_min, tmstruct->tm_sec);
            if(levels){
                listDir(fs, file.path(), levels -1);
            }
        } else {
            Serial.print("  FILE: ");
            Serial.print(file.name());
            Serial.print("  SIZE: ");
            Serial.print(file.size());
            time_t t= file.getLastWrite();
            struct tm * tmstruct = localtime(&t);
            Serial.printf("  LAST WRITE: %d-%02d-%02d %02d:%02d:%02d\n",(tmstruct->tm_year)+1900,( tmstruct->tm_mon)+1, tmstruct->tm_mday,tmstruct->tm_hour , tmstruct->tm_min, tmstruct->tm_sec);
        }
        file = root.openNextFile();
    }
}

void createDir(fs::FS &fs, const char * path){
    Serial.printf("Creating Dir: %s\n", path);
    if(fs.mkdir(path)){
        Serial.println("Dir created");
    } else {
        Serial.println("mkdir failed");
    }
}

void removeDir(fs::FS &fs, const char * path){
    Serial.printf("Removing Dir: %s\n", path);
    if(fs.rmdir(path)){
        Serial.println("Dir removed");
    } else {
        Serial.println("rmdir failed");
    }
}

void readFile(fs::FS &fs, const char * path){
    Serial.printf("Reading file: %s\n", path);

    File file = fs.open(path);
    if(!file){
        Serial.println("Failed to open file for reading");
        return;
    }

    Serial.print("Read from file: ");
    while(file.available()){
        Serial.write(file.read());
    }
    file.close();
}

void writeFile(fs::FS &fs, const char * path, const char * message){
    Serial.printf("Writing file: %s\n", path);

    File file = fs.open(path, FILE_WRITE);
    if(!file){
        Serial.println("Failed to open file for writing");
        return;
    }
    if(file.print(message)){
        Serial.println("File written");
    } else {
        Serial.println("Write failed");
    }
    file.close();
}

void appendFile(fs::FS &fs, const char * path, const char * message){
    Serial.printf("Appending to file: %s\n", path);

    File file = fs.open(path, FILE_APPEND);
    if(!file){
        Serial.println("Failed to open file for appending");
        return;
    }
    if(file.print(message)){
        Serial.println("Message appended");
    } else {
        Serial.println("Append failed");
    }
    file.close();
}

void renameFile(fs::FS &fs, const char * path1, const char * path2){
    Serial.printf("Renaming file %s to %s\n", path1, path2);
    if (fs.rename(path1, path2)) {
        Serial.println("File renamed");
    } else {
        Serial.println("Rename failed");
    }
}

void deleteFile(fs::FS &fs, const char * path){
    Serial.printf("Deleting file: %s\n", path);
    if(fs.remove(path)){
        Serial.println("File deleted");
    } else {
        Serial.println("Delete failed");
    }
}

void setup(){
    Serial.begin(115200);
    // We start by connecting to a WiFi network
    Serial.println();
    Serial.println();
    Serial.print("Connecting to ");
    Serial.println(ssid);

    WiFi.begin(ssid, password);

    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println("WiFi connected");
    Serial.println("IP address: ");
    Serial.println(WiFi.localIP());
    Serial.println("Contacting Time Server");
	configTime(3600*timezone, daysavetime*3600, "time.nist.gov", "0.pool.ntp.org", "1.pool.ntp.org");
	struct tm tmstruct ;
    delay(2000);
    tmstruct.tm_year = 0;
    getLocalTime(&tmstruct, 5000);
	Serial.printf("\nNow is : %d-%02d-%02d %02d:%02d:%02d\n",(tmstruct.tm_year)+1900,( tmstruct.tm_mon)+1, tmstruct.tm_mday,tmstruct.tm_hour , tmstruct.tm_min, tmstruct.tm_sec);
    Serial.println("");
    
    if(!SPIFFS.begin(FORMAT_LITTLEFS_IF_FAILED)){
        Serial.println("LittleFS Mount Failed");
        return;
    }

    Serial.println("----list 1----");
    listDir(SPIFFS, "/", 1);
	
    Serial.println("----remove old dir----");
    removeDir(SPIFFS, "/mydir");
	
    Serial.println("----create a new dir----");
    createDir(SPIFFS, "/mydir");
	
    Serial.println("----remove the new dir----");
    removeDir(SPIFFS, "/mydir");
	
    Serial.println("----create the new again----");
    createDir(SPIFFS, "/mydir");
	
    Serial.println("----create and work with file----");
    writeFile(SPIFFS, "/mydir/hello.txt", "Hello ");
    appendFile(SPIFFS, "/mydir/hello.txt", "World!\n");

    Serial.println("----list 2----");
    listDir(SPIFFS, "/", 1);
	
    Serial.println("----attempt to remove dir w/ file----");
    removeDir(SPIFFS, "/mydir");
	
    Serial.println("----remove dir after deleting file----");
    deleteFile(SPIFFS, "/mydir/hello.txt");
    removeDir(SPIFFS, "/mydir");
	
	Serial.println("----list 3----");
    listDir(SPIFFS, "/", 1);
	
	Serial.println( "Test complete" );

}

void loop(){

}
*/
/*
#include <esp-fs-webserver.h>  // https://github.com/cotestatnt/esp-fs-webserver

#include <FS.h>
#include <LittleFS.h>
#define FILESYSTEM LittleFS

#ifndef LED_BUILTIN
#define LED_BUILTIN 2
#endif

// In order to set SSID and password open the /setup webserver page
// const char* ssid;
// const char* password;

uint8_t ledPin = LED_BUILTIN;
bool apMode = false;

#ifdef ESP8266
  ESP8266WebServer server(80);
#elif defined(ESP32)
  WebServer server(80);
#endif
FSWebServer myWebServer(FILESYSTEM, server);


////////////////////////////////  Filesystem  /////////////////////////////////////////
void startFilesystem(){
  // FILESYSTEM INIT
  if ( FILESYSTEM.begin()){
    File root = FILESYSTEM.open("/", "r");
    File file = root.openNextFile();
    while (file){
      const char* fileName = file.name();
      size_t fileSize = file.size();
      Serial.printf("FS File: %s, size: %lu\n", fileName, (long unsigned)fileSize);
      file = root.openNextFile();
    }
    Serial.println();
  }
  else {
    Serial.println("ERROR on mounting filesystem. It will be formmatted!");
    FILESYSTEM.format();
    ESP.restart();
  }
}

////////////////////////////  HTTP Request Handlers  ////////////////////////////////////
void handleLed() {
  WebServerClass* webRequest = myWebServer.getRequest();

  // http://xxx.xxx.xxx.xxx/led?val=1
  if(webRequest->hasArg("val")) {
    int value = webRequest->arg("val").toInt();
    digitalWrite(ledPin, value);
  }

  String reply = "LED is now ";
  reply += digitalRead(ledPin) ? "OFF" : "ON";
  webRequest->send(200, "text/plain", reply);
}


void setup(){
  Serial.begin(115200);

  // FILESYSTEM INIT
  startFilesystem();

  // Try to connect to flash stored SSID, start AP if fails after timeout
  IPAddress myIP = myWebServer.startWiFi(15000, "ESP8266_AP", "123456789" );

  // Add custom page handlers to webserver
  myWebServer.addHandler("/led", HTTP_GET, handleLed);

  // Start webserver
  if (myWebServer.begin()) {
    Serial.print(F("ESP Web Server started on IP Address: "));
    Serial.println(myIP);
    Serial.println(F("Open /setup page to configure optional parameters"));
    Serial.println(F("Open /edit page to view and edit files"));
    Serial.println(F("Open /update page to upload firmware and filesystem updates"));
  }

  pinMode(LED_BUILTIN, OUTPUT);
}


void loop() {
  myWebServer.run();

}*/