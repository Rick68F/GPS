#include "icons.hpp"

// ça c'est crée par moi

enum { STATUS_ACTIF = 0,
       STATUS_CACHE,
       STATUS_BARRE,
       STATUS_BARRE2
};

// copie de la fonction arduino long -> int car erreur a la compilation

int my_map(int x, int in_min, int in_max, int out_min, int out_max) {
  const int run = in_max - in_min;
  if (run == 0) {
    log_e("map(): Invalid input range, min == max");
    return -1;  // AVR returns -1, SAM returns 0
  }
  const int rise = out_max - out_min;
  const int delta = x - in_min;
  return (delta * rise) / run + out_min;
}

class ProgressBar {
public:

  int x;
  int y;
  int width;
  int height;
  int mini;
  int maxi;
  uint16_t coul_fill;
  uint16_t coul_back;
  int txtfont;
  uint16_t coul_text;
  int valeur_progress;

  ProgressBar() {
  }

  void initProgressBar(int16_t xPos, int16_t yPos, int16_t pWidth, int16_t pHeight, int16_t pMin = 0, int16_t pMax = 100, uint16_t couleur_fill = TFT_WHITE, uint16_t couleur_back = TFT_RED, uint8_t textfont = 2, uint16_t textcolor = TFT_GREEN) {
    x = xPos;
    y = yPos;
    width = pWidth;
    height = pHeight;
    mini = pMin;
    maxi = pMax;

    coul_back = couleur_back;
    coul_fill = couleur_fill;
    switch (textfont) {
      case 0:
      case 2:
      case 4: txtfont = textfont; break;  // 0 , 2, 4
      default: txtfont = 2; break;        // par default fonte n°2
    }
    coul_text = textcolor;
    valeur_progress = mini;
    render();
  }

  void rendu(int16_t valeur) {
    valeur_progress = valeur;
    if ((valeur >= mini) && (valeur <= maxi)) render();
    else Serial.printf("valeur en dehors des limites min %d max %d val %d\n", mini, maxi, valeur);
  }

  void render() {
    // float niveau = (width / (max - min)) * valeur_progress;
    // map(value, fromLow, fromHigh, toLow, toHigh)
    int niveau = my_map(valeur_progress, mini, maxi, x, width);
    // Serial.printf("val=%d niv=%d\n", valeur_progress, niveau);
    lcd.drawRect(x, y, width, height, coul_fill);
    lcd.fillRect(x, y, niveau, height, coul_fill);                   // draw rectangle
    lcd.fillRect(x + niveau, y, width - niveau, height, coul_back);  // draw rectangle
    // lcd.drawRect(x, y, width, height, coul_contour);     // draw rectangle
    lcd.setTextColor(coul_text, TFT_BLACK);
    lcd.setTextFont(txtfont);
    // lcd.setFont(&helvB12);
    // lcd.setTextDatum(MC_DATUM);
    // lcd.setTextDatum(textdatum_t::top_center);
    lcd.setCursor(x + (width / 2), y + height - 1);
    lcd.printf("%d/%d", valeur_progress, maxi);
    // lcd.drawString(text, x + 3, y + 1, txtsize);
  }
};


// LA NON copie de ce que j'ai touvé sur internet mais adaptation

class ScreenPoint {
public:
  int16_t x;
  int16_t y;

  ScreenPoint() {
    // default contructor
  }

  ScreenPoint(int16_t xIn, int16_t yIn) {
    x = xIn;
    y = yIn;
  }
};

class Button {
public:

  int16_t x;
  int16_t y;
  int16_t width;
  int16_t height;
  const char *text;
  const uint16_t *Bitmap;
  uint8_t actif;
  uint8_t txtfont;
  uint16_t coul_contour;
  uint16_t coul_fill;
  uint16_t coul_text;
  bool rev;

  Button() {
  }

  //  void initButton(int xPos, int yPos, int butWidth, int butHeight, char *butText) {
  void initButton(int16_t xPos, int16_t yPos, int16_t butWidth, int16_t butHeight, const char *butText, const uint16_t *bufBitmap = NULL, uint8_t boutonactif = 0, uint8_t textfont = 2, uint16_t couleur_contour = TFT_WHITE, uint16_t fill = TFT_BLACK, uint16_t textcolor = TFT_GREEN) {
    x = xPos;
    y = yPos;
    width = butWidth;
    height = butHeight;
    text = butText;
    switch (textfont) {
      case 0:
      case 2:
      case 4: txtfont = textfont; break;  // 0 , 2, 4
      default: txtfont = 2; break;        // par default fonte n°2
    }
    actif = boutonactif;
    Bitmap = bufBitmap;
    coul_contour = couleur_contour;
    coul_fill = fill;
    coul_text = textcolor;
    rev = false;
    render();
  }

  void changeBitmap(const uint16_t *bufBitmap) {
    Bitmap = bufBitmap;
    render();
  }

  void changeStatus(uint8_t boutonactif) {
    actif = boutonactif;
    render();
  }

  void revert() {
    rev = !rev;
    render();
  }

  void render() {
    if (Bitmap == NULL) {
      lcd.fillRect(x, y, width, height, (rev ? coul_text : coul_fill));  // draw rectangle
      lcd.drawRect(x, y, width, height, coul_contour);                   // draw rectangle
      lcd.setTextColor((rev ? coul_fill : coul_text));
      lcd.setTextFont(txtfont);
      lcd.drawString(text, x + 3, y + height - 2);
    } else {
      switch (actif) {
        case STATUS_ACTIF: lcd.pushImage(x, y, width, height, Bitmap); break;
        case STATUS_CACHE: lcd.fillRect(x, y, width, height, TFT_BLACK); break;
        case STATUS_BARRE:
          lcd.pushImage(x, y, width, height, Bitmap);
          lcd.drawLine(x, y, x + width, y + height, TFT_WHITE);
          lcd.drawLine(x + 1, y, x + width - 1, y + height, TFT_BLACK);
          lcd.drawLine(x, y + 1, x + width, y + height - 1, TFT_BLACK);
          lcd.drawLine(x, y + height, x + width, y, TFT_WHITE);
          lcd.drawLine(x + 1, y + height, x + width - 1, y, TFT_BLACK);
          lcd.drawLine(x, y + height + 1, x + width, y + 1, TFT_BLACK);
          break;
        case STATUS_BARRE2:
          lcd.pushImage(x, y, width, height, Bitmap);
          lcd.drawLine(x, y, x + (width - 1), y + (height - 1), TFT_WHITE);
          lcd.drawLine(x + 1, y, x + (width - 1), y + (height - 1) - 1, TFT_BLACK);
          lcd.drawLine(x, y + 1, x + (width - 1) - 1, y + (height - 1), TFT_BLACK);
          lcd.drawLine(x, y + (height - 1), x + (width - 1), y, TFT_WHITE);
          lcd.drawLine(x + 1, y + (height - 1), x + (width - 1), y + 1, TFT_BLACK);
          lcd.drawLine(x, y + (height - 1) - 1, x + (width - 1) - 1, y, TFT_BLACK);
          break;
      }
    }
  }

  bool isClicked(ScreenPoint sp) {
    if ((sp.x >= x) && (sp.x <= (x + width)) && (sp.y >= y) && (sp.y <= (y + height)) && (actif == STATUS_ACTIF)) {
      return true;
    } else {
      return false;
    }
  }
};

#define NBRE_ITEM_MENU 10
uint8_t menu_depart = 0;
Button boutons_Menu[NBRE_ITEM_MENU];
char ButtonBuf[NBRE_ITEM_MENU][32];
#define NBRE_ITEM_ACTION 12
uint8_t choix_action = 0;
Button boutons_Action[NBRE_ITEM_ACTION];

// Button button;
class Liste {
public:
  std::vector<std::string> LaListeFichiers;
  int nbreDeFichiers;
  int16_t x;
  int16_t y;
  int16_t width;
  int nbreLigneAff;  //nbre de Ligne affichée dans le choix
  uint8_t txtfont;
  uint16_t coul_contour;
  uint16_t coul_fill;
  uint16_t coul_text;
  uint16_t up;
  uint16_t down;
  uint16_t depart;

  Liste() {
  }

  void initListe(char *Titre, std::vector<std::string> &Llf, int16_t xPos, int16_t yPos, int16_t listWidth, int16_t listNligne, int LUp, int LDown, uint8_t textfont = 2, uint16_t couleur_contour = RGB565_WHITE, uint16_t fill = RGB565_BLACK, uint16_t textcolor = RGB565_GREEN) {

    LaListeFichiers = Llf;
    nbreDeFichiers = Llf.size();

    x = xPos;
    y = yPos;
    depart = 0;
    width = listWidth;
    nbreLigneAff = listNligne;
    up = LUp;      // n° du bouton Up
    down = LDown;  // n° du bouton Down
    switch (textfont) {
      case 0:
      case 2:
      case 4: txtfont = textfont; break;  // 0 , 2, 4
      default: txtfont = 2; break;        // par default fonte n°2
    }
    coul_contour = couleur_contour;
    coul_fill = fill;
    coul_text = textcolor;
    lcd.setTextFont(2);
    lcd.setTextColor(textcolor, fill);
    lcd.drawString(Titre, x + (width / 2) - ((strlen(Titre) / 2) * 8), y + 20);

    render(0);
  }

  void render(uint16_t MenuDepart) {
    lcd.setTextFont(0);
    Serial.printf("menu %d %d %d\n", MenuDepart, (nbreDeFichiers > nbreLigneAff ? nbreLigneAff : nbreDeFichiers), nbreDeFichiers);
    for (int b = 0; b < min(nbreLigneAff, nbreDeFichiers); b++) {
      cout << LaListeFichiers[MenuDepart + b].c_str() << endl;
      string tempo = LaListeFichiers[MenuDepart + b];
      boutons_Menu[b].initButton(0, y + 40 + 20 * b + 5, lcd.width() - 23, 18, LaListeFichiers[MenuDepart + b].c_str(), NULL, STATUS_ACTIF);  //, 1);
    }
    lcd.fillRect(lcd.width() - TAILLE_MINI_ICONE - 3, y + 2 + 40, TAILLE_MINI_ICONE + 2, TAILLE_MINI_ICONE * nbreLigneAff + 4, TFT_BLACK);
    lcd.drawRect(lcd.width() - TAILLE_MINI_ICONE - 3, y + 2 + 40, TAILLE_MINI_ICONE + 2, TAILLE_MINI_ICONE * nbreLigneAff + 4, TFT_WHITE);
    boutons_Action[up].initButton(lcd.width() - TAILLE_MINI_ICONE - 2, y + 4 + 40, TAILLE_MINI_ICONE, TAILLE_MINI_ICONE, (char *)"u", (MenuDepart == 0 ? icons8_multiplier_20 : icons8_tri_croissant_20));
    boutons_Action[down].initButton(lcd.width() - TAILLE_MINI_ICONE - 2, y + 4 + 40 + TAILLE_MINI_ICONE * (nbreLigneAff - 1), TAILLE_MINI_ICONE, TAILLE_MINI_ICONE, (char *)"d", (MenuDepart + nbreLigneAff > nbreDeFichiers - 1 ? icons8_multiplier_20 : icons8_tri_decroissant_20));
    Serial.printf("menu  %d %d %d\n", MenuDepart, nbreLigneAff, nbreDeFichiers);
  }

  void move_up() {
    if (depart > 0) {
      depart--;
      render(depart);
    }
    //MenuDepart + NBRE_ITEM_MENU == Nbre_Fichier - 1
  }
  void move_down() {
    if (depart + nbreLigneAff < nbreDeFichiers) {
      depart++;
      render(depart);
    }
  }
  /*bool isClicked(ScreenPoint sp) {
    if ((sp.x >= x) && (sp.x <= (x + width)) && (sp.y >= y) && (sp.y <= (y + height)) && (actif == STATUS_ACTIF)) {
      return true;
    } else {
      return false;
    }
  }*/
};

enum MENUP { MENUP_CARTE = 0,
             MENUP_GPX,
             MENUP_SD,
             MENUP_MONTRE,
             MENUP_TOOLS,
             MENUP_PAYS,
             MENUP_CPTE
};

bool menu_princ() {
  lcd.fillScreen(TFT_BLACK);
  boutons_Action[MENUP_CARTE].initButton(20, 20, 80, 80, (char *)"A", icons8_adventures_80);
  boutons_Action[MENUP_PAYS].initButton(20, 120, 80, 80, (char *)"C", icons8_country_80, (gps.location.isValid() ? STATUS_ACTIF : STATUS_BARRE2));
  boutons_Action[MENUP_SD].initButton(120, 20, 80, 80, (char *)"S", icons8_micro_sd_80, (CarteSD_presente ? STATUS_ACTIF : STATUS_BARRE2));
  boutons_Action[MENUP_MONTRE].initButton(120, 120, 80, 80, (char *)"M", icons8_clock_80);
  boutons_Action[MENUP_GPX].initButton(20, 220, 80, 80, (char *)"G", icons8_map_80);
  boutons_Action[MENUP_TOOLS].initButton(120, 220, 80, 80, (char *)"P", icons8_tools_80);
  return (true);
}

//