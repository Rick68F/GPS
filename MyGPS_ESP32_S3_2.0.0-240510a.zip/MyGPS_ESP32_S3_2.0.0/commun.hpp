#ifndef __COMMUN_HPP__
#define __COMMUN_HPP__

#define READBUFFER
#define SDMMC

#define DICO_POLY 3   // polygone fermé
#define DICO_LINE 2   // des lignes
#define DICO_POINT 0  // rien
#define DICO_TEXT 1   // du texte

// pour rappel dans DICO
// Les elements affichée sont ceux qui  superieur ou egal au niveau demande
// Donc 1 element en VISU_TOUT ne sera affiché que si VISU _TOUT est demande mais du coup beaucoup plus long es ce que le proc et l'affichage suit ????
enum {
  VISU_TOUT = 0,
  VISU_MAXI = 1,
  VISU_SANS_BAT = 2,  // sans batiments
  VISU_MINI = 7,
  VISU_STRICT = 8,  // juste les routes
  VISU_RIEN = 9     // Ne pas afficher
};


static const int32_t TAILLE_ICONE = 30;
static const int32_t TAILLE_MINI_ICONE = 20;
static const int32_t NOM_MAX_LITTLEFS = 30;
static const int32_t NBRE_ITEM_FICH = 30;
static const int32_t NBRE_ITEM_MNU_MAP = 3;


#endif