// ex de calib en fin de fichier
// calibration values
float xCalM = 0.0, yCalM = 0.0;  // gradients
float xCalC = 0.0, yCalC = 0.0;  // y axis crossing points

// int8_t blockWidth = 20;  // block size
// int8_t blockHeight = 20;
// int16_t blockX = 0, blockY = 0;  // block position (pixels)




// ecran 8bits parallel config 517
// x1 = 3511, y1 = 474 x2 = 399, y2 = 3578
// xCalM = -0.09, xCalC = 335.90 yCalM = 0.06, yCalC = -10.54
// calibrateTouchScreen();
// calibrateCalc(3513, 484, 420, 3622);
/*x1 = 3715, y1 = 524, x2 = 539, y2 = 3612
xCalM = -0.09, xCalC = 347.52, yCalM = 0.06, yCalC = -13.94
x1 = 3513, y1 = 484x2 = 420, y2 = 3622
xCalM = -0.09, xCalC = 338.02yCalM = 0.06, yCalC = -10.85
x1 = 3695, y1 = 512, x2 = 565, y2 = 3627
x1 = 3685, y1 = 552, x2 = 561, y2 = 3669
xCalM = -0.09, xCalC = 350.28, yCalM = 0.06, yCalC = -15.42
*/
// config ecran spi config 518 (ili9488 480x320)
// x1 = 3797, y1 = 3652, x2 = 361, y2 = 421
// xCalM = -0.13, xCalC = 506.23, yCalM = -0.09, yCalC = 336.48
//x1 = 3790, y1 = 3663, x2 = 368, y2 = 425
//xCalM = -0.13, xCalC = 507.32, yCalM = -0.09, yCalC = 336.75
//x1 = 3816, y1 = 3665, x2 = 346, y2 = 425
//xCalM = -0.13, xCalC = 503.87, yCalM = -0.09, yCalC = 336.73


//