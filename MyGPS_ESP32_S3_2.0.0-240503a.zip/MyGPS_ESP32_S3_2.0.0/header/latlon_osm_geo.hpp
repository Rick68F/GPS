#ifndef __LATLON_HPP__
#define __TATLON_HPP__

int long2tilex(double lon, int z);
int lat2tiley(double lat, int z);
double tilex2long(int x, int z);
double tiley2lat(int y, int z);
double long2tilex_d(double lon, int z);
double lat2tiley_d(double lat, int z);
void tile_Bounds(uint32_t tx, uint32_t ty, uint32_t zoom, double &minx, double &miny, double &maxx, double &maxy);
#endif
//