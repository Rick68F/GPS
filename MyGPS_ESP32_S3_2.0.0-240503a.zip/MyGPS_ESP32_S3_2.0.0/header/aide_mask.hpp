#ifndef __MASK_HPP__
#define __MASK_HPP__

#define BITMASK_INDEX_OFFSET 0x7FFFFFFFFFL
/**
     * Bitmask to extract the water information from an index entry.
     */
#define BITMASK_INDEX_WATER 0x8000000000L
/**
     * Default start zoom level.
     */
#define DEFAULT_START_ZOOM_LEVEL 12
/**
     * Amount of cache blocks that the index cache should store.
     */
#define INDEX_CACHE_SIZE 64
/**
     * Error message for an invalid first way offset.
     */
#define INVALID_FIRST_WAY_OFFSET "invalid first way offset: "
/**
     * Bitmask for the optional POI feature "elevation".
     */
#define POI_FEATURE_ELEVATION 0x20
/**
     * Bitmask for the optional POI feature "house number".
     */
#define POI_FEATURE_HOUSE_NUMBER 0x40
/**
     * Bitmask for the optional POI feature "name".
     */
#define POI_FEATURE_NAME 0x80
/**
     * Bitmask for the POI layer.
     */
#define POI_LAYER_BITMASK 0xf0
/**
     * Bit shift for calculating the POI layer.
     */
#define POI_LAYER_SHIFT 4
/**
     * Bitmask for the number of POI tags.
     */
#define POI_NUMBER_OF_TAGS_BITMASK 0x0f
/**
     * Length of the debug signature at the beginning of each block.
     */
#define SIGNATURE_LENGTH_BLOCK 32
/**
     * Length of the debug signature at the beginning of each POI.
     */
#define SIGNATURE_LENGTH_POI 32
/**
     * Length of the debug signature at the beginning of each way.
     */
#define SIGNATURE_LENGTH_WAY 32
/**
     * The key of the elevation OpenStreetMap tag.
     */
#define TAG_KEY_ELE "ele"
/**
     * The key of the house number OpenStreetMap tag.
     */
#define TAG_KEY_HOUSE_NUMBER "addr:housenumber"
/**
     * The key of the name OpenStreetMap tag.
     */
#define TAG_KEY_NAME "name"
/**
     * The key of the reference OpenStreetMap tag.
     */
#define TAG_KEY_REF "ref"
/**
     * Bitmask for the optional way data blocks byte.
     */
#define WAY_FEATURE_DATA_BLOCKS_BYTE 0x08
/**
     * Bitmask for the optional way double delta encoding.
     */
#define WAY_FEATURE_DOUBLE_DELTA_ENCODING 0x04
/**
     * Bitmask for the optional way feature "house number".
     */
#define WAY_FEATURE_HOUSE_NUMBER 0x40
/**
     * Bitmask for the optional way feature "label position".
     */
#define WAY_FEATURE_LABEL_POSITION 0x10
/**
     * Bitmask for the optional way feature "name".
     */
#define WAY_FEATURE_NAME 0x80
/**
     * Bitmask for the optional way feature "reference".
     */
#define WAY_FEATURE_REF 0x20
/**
     * Bitmask for the way layer.
     */
#define WAY_LAYER_BITMASK 0xf0
/**
     * Bit shift for calculating the way layer.
     */
#define WAY_LAYER_SHIFT 4
/**
     * Bitmask for the number of way tags.
     */
#define WAY_NUMBER_OF_TAGS_BITMASK 0x0f

/**
     * Bitmask for the comment field in the file header.
     */
#define HEADER_BITMASK_COMMENT 0x08

/**
     * Bitmask for the created by field in the file header.
     */
#define HEADER_BITMASK_CREATED_BY 0x04

/**
     * Bitmask for the debug flag in the file header.
     */
#define HEADER_BITMASK_DEBUG 0x80

/**
     * Bitmask for the language(s) preference field in the file header.
     */
#define HEADER_BITMASK_LANGUAGES_PREFERENCE 0x10

/**
     * Bitmask for the start position field in the file header.
     */
#define HEADER_BITMASK_START_POSITION 0x40

/**
     * Bitmask for the start zoom level field in the file header.
     */
#define HEADER_BITMASK_START_ZOOM_LEVEL 0x20

/**
     * Maximum valid start zoom level.
     */
#define START_ZOOM_LEVEL_MAX 22


/**
     * Maximum valid base zoom level of a sub-file.
     */
#define BASE_ZOOM_LEVEL_MAX 20

/**
     * Minimum size of the file header in bytes.
     */
#define HEADER_SIZE_MIN 70

/**
     * Length of the debug signature at the beginning of the index.
     */
#define SIGNATURE_LENGTH_INDEX 16

/**
     * Magic byte at the beginning of a valid binary map file.
     */
#define BINARY_OSM_MAGIC_BYTE "mapsforge binary OSM"

/**
     * Magic header size
     */
#define HEADER_MAGIC_SIZE 20

/**
     * Maximum size of the file header in bytes.
     */
#define HEADER_SIZE_MAX 1000000

/**
     * Minimum size of the file header in bytes.
     */
#define HEADER_SIZE_MIN 70

/**
     * The name of the Mercator projection as stored in the file header.
     */
#define MERCATOR "Mercator"

/**
     * Lowest version of the map file format supported by this implementation.
     */
#define SUPPORTED_FILE_VERSION_MIN 3

/**
     * Highest version of the map file format supported by this implementation.
     */
#define SUPPORTED_FILE_VERSION_MAX 5

#endif
