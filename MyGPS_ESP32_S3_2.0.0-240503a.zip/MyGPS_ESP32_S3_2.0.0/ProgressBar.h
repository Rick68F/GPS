// ça c'est crée par moi

class ProgressBar {
public:

  int16_t x;
  int16_t y;
  int16_t width;
  int16_t height;
  int16_t min;
  int16_t max;
  uint16_t coul_fill;
  uint16_t coul_back;
  uint8_t txtsize;
  uint16_t coul_text;
  int16_t valeur_progress;

  ProgressBar() {
  }

  void initProgressBar(int16_t xPos, int16_t yPos, int16_t pWidth, int16_t pHeight, int16_t pMin = 0, int16_t pMax = 100, uint16_t couleur_fill = TFT_WHITE, uint16_t couleur_back = TFT_RED, uint8_t textsize = 2, uint16_t textcolor = TFT_GREEN) {
    x = xPos;
    y = yPos;
    width = pWidth;
    height = pHeight;
    min = pMin;
    max = pMax;

    coul_back = couleur_back;
    coul_fill = couleur_fill;
    txtsize = textsize;
    coul_text = textcolor;
    valeur_progress = min;
    render();
  }

  void rendu(int16_t valeur) {
    valeur_progress = valeur;
    if ((valeur >= min) && (valeur <= max)) render();
    else Serial.printf("valeur en dehors des limites min %d max %d val %d\n", min, max, valeur);
  }

  void render() {
    // float niveau = (width / (max - min)) * valeur_progress;
    // map(value, fromLow, fromHigh, toLow, toHigh)
    int niveau = map(valeur_progress, min, max, x, width);
    // Serial.printf("val=%d niv=%d\n", valeur_progress, niveau);
    lcd.drawRect(x, y, width, height, coul_fill);
    lcd.fillRect(x, y, niveau, height, coul_fill);                   // draw rectangle
    lcd.fillRect(x + niveau, y, width - niveau, height, coul_back);  // draw rectangle
    // lcd.drawRect(x, y, width, height, coul_contour);     // draw rectangle
    lcd.setTextColor(coul_text);
    lcd.setTextSize(txtsize);
    // lcd.setTextDatum(MC_DATUM);
    lcd.setTextDatum(textdatum_t::top_center);
    lcd.setCursor(x + (width / 2), y + 2);
    lcd.printf("%d/%d", valeur_progress, max);
    // lcd.drawString(text, x + 3, y + 1, txtsize);
  }
};


//