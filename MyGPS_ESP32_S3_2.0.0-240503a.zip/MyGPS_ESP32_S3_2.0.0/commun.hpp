#ifndef __COMMUN_HPP__
#define __COMMUN_HPP__

#define READBUFFER
#define SDMMC

#define DICO_POLY 3
#define DICO_LINE 2
#define DICO_POINT 0
#define DICO_TEXT 1

enum {
  VISU_TOUT = 0,
  VISU_MAXI = 1,
  VISU_SANS_BAT = 2,  // sans batiments
  VISU_MINI = 7,
  VISU_STRICT = 8,  // juste les routes
  VISU_RIEN = 9
};

#endif