#ifndef __DICO_HPP__
#define __DICO_HPP__

// https://wiki.openstreetmap.org/wiki/FR:%C3%89l%C3%A9ments_cartographiques#Routes

struct DICO {
  char type[20];
  char name[24];
  uint8_t priorite;
  uint8_t niv_detail;  // 0-9
  uint8_t epais;
  uint8_t zoom;
  uint8_t coul_remplis;
  uint8_t coul_contour;
  const uint_fast8_t *style;

  uint8_t *image;
};

struct DICO_WAYS_AND_POIS {
  const DICO *ptr;
};
// PTR_DICO ptr_dico_ways[400];

DICO_WAYS_AND_POIS *ptr_diko_Ways;
DICO_WAYS_AND_POIS *ptr_diko_POIs;

extern const uint_fast8_t Dash0[];
extern const uint_fast8_t Dash1[];
extern const uint_fast8_t Dash2[];
extern const uint_fast8_t Dash3[];
extern const uint_fast8_t Dash4[];
extern const uint_fast8_t Dash5[];
extern const uint_fast8_t Dash6[];
extern const uint_fast8_t Dash8[];
extern const uint_fast8_t Dash9[];

// grep roof:material ici.txt|grep "TAG Liste" |cut -b89-105|while read a; do echo "${a}"; done
// pour capture du fichier laisser console ouverte puis la fermer
// cat /dev/ttyACM0 > /tmp/tutu
// reset sur le proc
//

// https://wiki.openstreetmap.org/wiki/FR:%C3%89l%C3%A9ments_cartographiques#Routes
const DICO dico_ways[] PROGMEM = {
  { "roof:direction", "*", DICO_LINE, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },     // 45 135 315 225 112 247 0 67 292 22 180 270 157 202
  { "building:material", "*", DICO_LINE, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },  // glass stone sandstone metal plaster concrete brick wood mirror steel
  { "roof:material", "*", DICO_LINE, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },      // roof_tiles glass slate metal concrete tar_paper copper stone grass gravel wood plants thatch
  { "access", "*", DICO_LINE, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },             // private destination
  { "admin_level", "*", DICO_LINE, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },        // 2 4 5 6
  { "amenity", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKGREY, 0x0000, NULL, NULL },    // bench restaurant recycling post_box bank fast_food parking drinking_water pharmacy fountain charging_station shelter cafe
                                                                                              // atm fuel school toilets post_office bar townhall pub fire_station library bicycle_rental place_of_worship kindergarten
                                                                                              // motorcycle_parking police theatre cinema university hospital bus_station telephone grave_yard parking shelter school restaurant
                                                                                              // bank fountain fast_food fuel toilets hospital university pharmacy grave_yard cafe college theatre motorcycle_parking pub drinking_water atm
  { "aeroway", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },         // gate helipad taxiway runway apron terminal aerodrome helipad
  { "aerialway", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },       // drag_lift rope_tow chair_lift magic_carpet
  { "barrier", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },         // gate bollard lift_gate cycle_barrier toll_booth fence wall retaining_wall city_wall
  { "boundary", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_CYAN, 0x0000, NULL, NULL },       // contour  de la tuile ? administrative protected_area
  { "building", "*", DICO_POLY, VISU_MAXI, 0, 0, RGB332_DARKGREY, 0x0000, NULL, NULL },       //  yes detached apartments house garage shed residential garages retail industrial church school roof civic service farm_auxiliary
                                                                                              // terrace semidetached_house commercial chapel barn greenhouse hospital office public hangar farm ruins warehouse hotel
                                                                                              // hut university cabin government train_station manufacture mosque castle transportation supermarket cathedral monastery shop factory
  { "emergency", "*", DICO_POINT, VISU_SANS_BAT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },      // phone
  { "highway", "bus_stop", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "cycleway", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BLUE, 0x0000, Dash1, NULL },
  { "highway", "footway", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "living_street", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "mini_roundabout", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "motorway", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "motorway_junction", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "motorway_link", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "path", DICO_LINE, VISU_STRICT, 0, 0, RGB332_ORANGE, 0x0000, Dash3, NULL },
  { "highway", "pedestrian", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, Dash1, NULL },
  { "highway", "primary", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "primary_link", DICO_LINE, VISU_STRICT, 2, 0, RGB332_ORANGE, RGB332_RED, NULL, NULL },
  { "highway", "residential", DICO_LINE, VISU_STRICT, 2, 0, RGB332_GRAY, RGB332_WHITE, NULL, NULL },
  { "highway", "raceway", DICO_LINE, VISU_STRICT, 0, 0, RGB332_GRAY, 0x0000, NULL, NULL },
  { "highway", "road", DICO_LINE, VISU_STRICT, 0, 0, RGB332_GRAY, 0x0000, NULL, NULL },
  { "highway", "secondary", DICO_LINE, VISU_STRICT, 2, 0, RGB332_GRAY, TFT_YELLOW, NULL, NULL },
  { "highway", "secondary_link", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "service", DICO_LINE, VISU_STRICT, 2, 0, RGB332_GRAY, RGB332_WHITE, NULL, NULL },
  { "highway", "services", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "steps", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "tertiary", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "track", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash6, NULL },
  { "highway", "trunk", DICO_LINE, VISU_STRICT, 4, 0, RGB332_RED, RGB332_TAN, NULL, NULL },
  { "highway", "trunk_link", DICO_LINE, VISU_STRICT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },
  { "highway", "turning_circle", DICO_LINE, VISU_STRICT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },
  { "highway", "unclassified", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },
  { "highway", "*", DICO_LINE, VISU_STRICT, 0, 0, RGB332_SADDLEBROWN, 0x0000, NULL, NULL },     // bus_stop turning_circle traffic_signals mini_roundabout motorway_junction track service residential path tertiary footway secondary unclassified
                                                                                                // primary cycleway trunk motorway trunk_link steps motorway_link pedestrian living_street construction primary_link secondary_link raceway
                                                                                                // tertiary_link bridleway services road
  { "historic", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_GREENYELLOW, 0x0000, NULL, NULL },  // memorial monument castle castle ruins
  { "landuse", "allotments", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_GREEN, 0x0000, NULL, NULL },
  { "landuse", "basin", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_RED /* RGB332_LIGHTBLUE */, 0x0000, NULL, NULL },
  { "landuse", "brownfield", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_BROWN, 0x0000, NULL, NULL },
  { "landuse", "cemetery", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_GRAY, 0x0000, NULL, NULL },
  { "landuse", "commercial", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKRED, 0x0000, NULL, NULL },
  { "landuse", "construction", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKGREY, 0x0000, NULL, NULL },
  { "landuse", "education", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_WHITE, 0x0000, NULL, NULL },
  { "landuse", "fairground", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_WHITE, 0x0000, NULL, NULL },
  { "landuse", "farmland", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "farmyard", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_RED, 0x0000, NULL, NULL },
  { "landuse", "forest", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKGREEN, 0x0000, NULL, NULL },
  { "landuse", "grass", DICO_POLY, VISU_TOUT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },  // on affiche pas couleur de fond
  { "landuse", "greenfield", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "greenhouse_horticulture", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_KHAKI, 0x0000, NULL, NULL },
  { "landuse", "industrial", DICO_POLY, VISU_TOUT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },
  { "landuse", "institutional", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_WHITE, 0x0000, NULL, NULL },
  { "landuse", "landfill", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKGREY, 0x0000, NULL, NULL },
  { "landuse", "meadow", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "military", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_DARKBLUE, 0x0000, NULL, NULL },
  { "landuse", "orchard", DICO_POLY, VISU_TOUT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },  //platation fruitier
  { "landuse", "plant_nursery", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "quarry", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGRAY, 0x0000, NULL, NULL },
  { "landuse", "railway", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_VIOLET, 0x0000, NULL, NULL },
  { "landuse", "recreation_ground", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "reservoir", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTBLUE, 0x0000, NULL, NULL },
  { "landuse", "residential", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGRAY, 0x0000, NULL, NULL },
  { "landuse", "retail", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },
  { "landuse", "salt_pond", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTBLUE, 0x0000, NULL, NULL },
  { "landuse", "village_green", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "vineyard", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },
  { "landuse", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_LIGHTGREEN, 0x0000, NULL, NULL },  // grass forest meadow farmland orchard residential farmyard industrial vineyard cemetery basin allotments construction retail
                                                                                              // quarry railway reservoir recreation_ground military commercial village_green landfill brownfield greenfield
  { "leisure", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },        // playground slipway swimming_pool pitch garden park playground sports_centre nature_reserve track golf_course common dog_park stadium water_park
  { "man_made", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_PINK, 0x0000, NULL, NULL },       //tower surveillance pier
  { "military", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_GREEN, 0x0000, NULL, NULL },      // barracks
  { "natural", "water", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_GREEN, 0x0000, NULL, NULL },
  { "natural", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_GREEN, 0x0000, NULL, NULL },  // peak spring cave_entrance water wood scrub grassland heath scree wetland beach
  { "place", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_KHAKI, 0x0000, NULL, NULL },    // locality village hamlet suburb town city locality
  { "power", "*", DICO_POLY, VISU_SANS_BAT, 0, 0, RGB332_KHAKI, 0x0000, NULL, NULL },    // tower generator
  { "railway", "level_crossing", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },
  { "railway", "rail", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },
  { "railway", "station", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },
  { "railway", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },   // level_crossing tram_stop station halt rail tram disused platform railway light_rail preserved miniature station monorail narrow_gauge funicular
  { "religion", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },  // christian jewish muslin
  { "route", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },     // ferry
  { "shop", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },      // bakery hairdresser supermarket bicycle laundry motorcycle mall motorcycle_repair organic supermarket mall motorcycle
  { "sport", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_ORANGE, 0x0000, NULL, NULL },     // soccer tennis multi basketball boules equestrian swimming climbing shooting skiing volleyball football baseball skating bowls
  { "tracktype", "grade1", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash0, NULL },
  { "tracktype", "grade2", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash1, NULL },
  { "tracktype", "grade3", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash2, NULL },
  { "tracktype", "grade4", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash4, NULL },
  { "tracktype", "grade5", DICO_LINE, VISU_STRICT, 0, 0, RGB332_BROWN, 0x0000, Dash5, NULL },
  { "tracktype", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_BROWN, 0x0000, Dash6, NULL },  // grade2 grade3 grade4 grade1 grade5
  { "tourism", "view", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_DARKMAGENTA, 0x0000, NULL, NULL },
  { "tourism", "picnic_site", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_DARKMAGENTA, 0x0000, NULL, NULL },
  { "tourism", "hotel", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_DARKMAGENTA, 0x0000, NULL, NULL },
  { "tourism", "hostel", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_DARKMAGENTA, 0x0000, NULL, NULL },
  { "tourism", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_DARKMAGENTA, 0x0000, NULL, NULL },  // information viewDICO_POIN picnic_site attraction hotel museum caravan_site camp_site alpine_hut hostel attraction hotel camp_site picnic_site caravan_site hostel viewDICO_POIN zoo
  { "waterway", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_BLUE, 0x0000, NULL, NULL },        // stream river canal drain dam
  { "wood", "*", DICO_LINE, VISU_SANS_BAT, 0, 0, RGB332_BLUE, 0x0000, NULL, NULL },            // coniferous deciduous
};

#endif