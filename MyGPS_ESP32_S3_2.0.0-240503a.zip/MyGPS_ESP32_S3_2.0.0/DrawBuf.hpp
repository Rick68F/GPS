// Utilisation
//
// Declaration
// #include "DrawBuf.hpp"
// DrawBuf bufosm;  // la classe
//
//
// Init:
//
//
//                                       min x min y  max x      max y
// bufosm.initBuff(osmtiles.getBuffer(),    0,     0,   512, TILE_SIZE);
// apres la creation du sprite
//
// ex:
//
// #include "DrawBuf.hpp"
//
// static LGFX_Sprite osmtiles;
// DrawBuf bufosm;  // la classe
// ..
// init()
// ..
// osmtiles.setPsram(true);
// osmtiles.setColorDepth(lgfx::rgb332_1Byte);
// osmtiles.createSprite(TILE_SIZE * 3, TILE_SIZE * 3);
// bufosm.initBuff(osmtiles.getBuffer(),    0,     0,   TILE_SIZE * 3, TILE_SIZE * 3);
// © Eric


// http://members.chello.at/easyfilter/bresenham.html ATT: different pou DrawLineAA les autres pas verifié
// fichier telecharger

/********************************************************************
*                                                                   *
*                    Curve Rasterizing Algorithm                    *
*                                                                   *
********************************************************************/
#include <cstdint>
#include <cmath>
#include <algorithm>
#include <iostream>
#include "couleurs.hpp"

#include <vector>
#include <unordered_map>
#include <stdbool.h>
// #include "ThickLine.h"
/*
 * Overlap means drawing additional pixel when changing minor direction
 * Needed for drawThickLine, otherwise some pixels will be missing in the thick line
 */
#define LINE_OVERLAP_NONE 0      // No line overlap, like in standard Bresenham
#define LINE_OVERLAP_MAJOR 0x01  // Overlap - first go major then minor direction. Pixel is drawn as extension after actual line
#define LINE_OVERLAP_MINOR 0x02  // Overlap - first go minor then major direction. Pixel is drawn as extension before next line
#define LINE_OVERLAP_BOTH 0x03   // Overlap - both

#define LINE_THICKNESS_MIDDLE 0                 // Start point is on the line at center of the thick line
#define LINE_THICKNESS_DRAW_CLOCKWISE 1         // Start point is on the counter clockwise border line
#define LINE_THICKNESS_DRAW_COUNTERCLOCKWISE 2  // Start point is on the clockwise border line


/* Many free ressource from the internet */
/* Based on bresenham from  * @author Zingl Alois * @date 22.08.2016 * @version 1.2 */

// modif pour pouvoir dessiner le plus rapidement dans la PSRAM de l'ESP (mode 8 bits)
// pour les ligne avec motif et autre avec "Cohen Sutherland Line Clipping"

// code pour affichage Route
const int ROAD = 0;    // une route epaiiseur + BORD
const int THICK = 1;   // epaisseur
const int BORDER = 2;  // ligne parallele Bord

#define MAX_POLY_CORNERS 255

// #define DECAL 50

struct POLYCORNER {
  int_fast16_t x;
  int_fast16_t y;
};

POLYCORNER Poly_Zone[MAX_POLY_CORNERS];

// const uint_fast8_t *Dash1 = Styles[0];
// const uint_fast8_t *Dash2 = Styles[1];
const uint_fast8_t Dash0[] = { 4, 1, 1, 1, 1 };  // ne marche pas dans certaine orientation 1 pixels est trop petit
const uint_fast8_t Dash1[] = { 6, 1, 1, 1, 1, 0, 0 };
const uint_fast8_t Dash2[] = { 10, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0 };
const uint_fast8_t Dash3[] = { 8, 1, 1, 0, 0, 1, 1, 0, 0 };
const uint_fast8_t Dash4[] = { 8, 1, 1, 1, 1, 0, 0, 0, 0 };
const uint_fast8_t Dash5[] = { 8, 1, 1, 1, 0, 0, 0, 0, 0 };
const uint_fast8_t Dash6[] = { 12, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0 };
const uint_fast8_t Dash8[] = { 8, 1, 1, 1, 1, 1, 0, 0, 0 };
const uint_fast8_t Dash9[] = { 8, 1, 1, 1, 1, 1, 1, 0, 0 };
const uint_fast8_t Dash12[] = { 12, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0 };
const uint_fast8_t *STyles[] = { Dash0, Dash1, Dash2, Dash4, Dash8, Dash9, Dash12 };

inline void setColor(uint8_t c);
inline void setColorBorder(int16_t c);

inline void setPixel(int x, int y);
inline void setPixel(int x, int y, uint8_t color);


void drawLine(int x0, int y0, int x1, int y1);
void drawLine(int x0, int y0, int x1, int y1, uint8_t color);


void drawRect(int x, int y, int w, int h);
void drawRect(int x, int y, int w, int h, uint8_t color);

void drawFilledRect(int x, int y, int w, int h);
void drawFilledRect(int x, int y, int w, int h, uint8_t color);

void drawDashedLine(int x0, int y0, int x1, int y1, int color, const uint_fast8_t line_type[]);
// inline void setPixel(int x, int y);

void drawHLine(int x1, int x2, int y);
void drawHLine(int x1, int x2, int y, uint8_t color);

void drawFilledTriangle(int px0, int py0, int px1, int py1, int px2, int py2, uint8_t color);
// void drawThickLine(unsigned int aXStart, unsigned int aYStart, unsigned int aXEnd, unsigned int aYEnd, unsigned int aThickness, uint8_t aThicknessMode, uint16_t aColor);

#define CARE 16
#define CARRE 30
/* void palette() {
  int c;
  for (int i = 0; i < 16; i++)
    for (int j = 0; j < 16; j++) {
      // uint8_t c = i * CARE + j;

      bufosm.setColor(c++);
      bufosm.drawFilledRect(j * CARRE, i * CARE, CARRE, CARE);
    }
}*/

uint8_t Rset[252] = {
  0, 1, 1, 2, 2, 1, 2, 3, 3, 1, 3, 3, 4, 4, 2, 3, 4, 5, 5, 5, 2, 4, 5, 5,
  6, 6, 6, 2, 4, 5, 6, 6, 7, 7, 7, 2, 4, 5, 6, 7, 7, 8, 8, 8, 2, 5, 6, 7,
  8, 8, 8, 9, 9, 9, 3, 5, 6, 7, 8, 9, 9, 10, 10, 10, 10, 3, 5, 7, 8, 9,
  9, 10, 10, 11, 11, 11, 11, 3, 5, 7, 8, 9, 10, 10, 11, 11, 12, 12,
  12, 12, 3, 6, 7, 9, 10, 10, 11, 12, 12, 12, 13, 13, 13, 13, 3, 6,
  8, 9, 10, 11, 12, 12, 13, 13, 13, 14, 14, 14, 14, 3, 6, 8, 9, 10,
  11, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 3, 6, 8, 10, 11, 12,
  13, 13, 14, 14, 15, 15, 15, 16, 16, 16, 16, 4, 7, 8, 10, 11, 12,
  13, 14, 14, 15, 16, 16, 16, 17, 17, 17, 17, 17, 4, 7, 9, 10, 12,
  13, 14, 14, 15, 16, 16, 17, 17, 17, 18, 18, 18, 18, 18, 4, 7, 9,
  11, 12, 13, 14, 15, 16, 16, 17, 17, 18, 18, 18, 19, 19, 19, 19,
  19, 7, 9, 11, 12, 13, 15, 15, 16, 17, 18, 18, 19, 19, 20, 20, 20,
  20, 20, 20, 20, 20, 7, 9, 11, 12, 14, 15, 16, 17, 17, 18, 19, 19,
  20, 20, 21, 21, 21, 21, 21, 21, 21, 21
};

using namespace std;
class DrawBuf {
public:

  int_fast16_t x_min;
  int_fast16_t x_max;
  int_fast16_t y_min;
  int_fast16_t y_max;
  int_fast16_t w_buf;
  int_fast16_t h_buf;
  int_fast32_t t_buf;
  uint8_t couleur;
  uint8_t couleur_bord;
  uint8_t couleur_mem;
  uint8_t *LeBuffer;
  uint8_t *LaWindow;  // pour pouvoir copier du LeBuffer vers LaWindow
  DrawBuf() {
  }

  // pour algo clipping line

  // Defining region codes
  const int INSIDE = 0;  // 0000
  const int LEFT = 1;    // 0001
  const int RIGHT = 2;   // 0010
  const int BOTTOM = 4;  // 0100
  const int TOP = 8;     // 1000

  void fillScreen(uint8_t color = 0) {
    uint8_t *Ptr = &LeBuffer[0];
    int t = t_buf;  // h_buf * w_buf;
    for (int i = 0; i < t; i++) *Ptr++ = color;
  }

  // Function to compute region code for a point(x, y)
  inline int computeCode(float x, float y) {
    // initialized as being inside
    int code = INSIDE;

    if (x < x_min) code |= LEFT;        // to the left of rectangle
    else if (x > x_max) code |= RIGHT;  // to the right of rectangle
    if (y < y_min) code |= BOTTOM;      // below the rectangle
    else if (y > y_max) code |= TOP;    // above the rectangle

    return code;
  }

  inline void setColor(uint8_t c) {
    couleur = c;
  }

  inline void setColorBorder(int16_t c) {
    if (c < 0) couleur_bord = couleur;
    else couleur_bord = c;
  }

  void initBuff(void *Buf, int16_t xMin, int16_t yMin, int16_t width, int16_t height, void *Win) {
    LeBuffer = reinterpret_cast<uint8_t *>(Buf);
    LaWindow = reinterpret_cast<uint8_t *>(Win);
    // LeBuffer = Buf;
    x_min = xMin;
    x_max = xMin + width - 1;
    y_min = yMin;
    y_max = xMin + height - 1;
    w_buf = width;
    h_buf = height;
    t_buf = h_buf * w_buf;
    couleur = 0;
    couleur_bord = 0;
    couleur_mem = 0;
  }

  struct CLIP {
    int x1, y1, x2, y2;
  };

  // Implementing Cohen-Sutherland algorithm
  // Clipping a line from P1 = (x2, y2) to P2 = (x2, y2)
  // bool cohenSutherlandClip(int &x1, int &y1, int &x2, int &y2) {
  inline bool cohenSutherlandClip(CLIP &clipping_area) {
    // Compute region codes for P1, P2
    int code1 = computeCode(clipping_area.x1, clipping_area.y1);
    int code2 = computeCode(clipping_area.x2, clipping_area.y2);

    // Initialize line as outside the rectangular window
    bool accept = false;

    while (true) {
      if ((code1 == 0) && (code2 == 0)) {
        // If both endpoints lie within rectangle
        accept = true;
        break;
      } else if (code1 & code2) {
        // If both endpoints are outside rectangle,
        // in same region
        break;
      } else {
        // Some segment of line lies within the
        // rectangle
        int code_out;
        float x, y;

        // At least one endpoint is outside the
        // rectangle, pick it.
        if (code1 != 0) code_out = code1;
        else code_out = code2;

        // Find intersection point;
        // using formulas y = y1 + slope * (x - x1),
        // x = x1 + (1 / slope) * (y - y1)
        if (code_out & TOP) {
          // point is above the clip rectangle
          x = clipping_area.x1 + (clipping_area.x2 - clipping_area.x1) * (y_max - clipping_area.y1) / (clipping_area.y2 - clipping_area.y1);
          y = y_max;
        } else if (code_out & BOTTOM) {
          // point is below the rectangle
          x = clipping_area.x1 + (clipping_area.x2 - clipping_area.x1) * (y_min - clipping_area.y1) / (clipping_area.y2 - clipping_area.y1);
          y = y_min;
        } else if (code_out & RIGHT) {
          // point is to the right of rectangle
          y = clipping_area.y1 + (clipping_area.y2 - clipping_area.y1) * (x_max - clipping_area.x1) / (clipping_area.x2 - clipping_area.x1);
          x = x_max;
        } else if (code_out & LEFT) {
          // point is to the left of rectangle
          y = clipping_area.y1 + (clipping_area.y2 - clipping_area.y1) * (x_min - clipping_area.x1) / (clipping_area.x2 - clipping_area.x1);
          x = x_min;
        }

        // Now intersection point x, y is found
        // We replace point outside rectangle
        // by intersection point
        if (code_out == code1) {
          clipping_area.x1 = x;
          clipping_area.y1 = y;
          code1 = computeCode(clipping_area.x1, clipping_area.y1);
        } else {
          clipping_area.x2 = x;
          clipping_area.y2 = y;
          code2 = computeCode(clipping_area.x2, clipping_area.y2);
        }
      }
    }
    /* if (accept) {
      cout << "Line accepted from " << clipping_area.x1 << ", " << clipping_area.y1 << " to " << clipping_area.x2 << ", " << clipping_area.y2 << endl;
      // Here the user can add code to display the rectangle
      // along with the accepted (portion of) lines
      // osmtiles.drawLine(x1, y1, x2, y2, TFT_ORANGE);
    } else {
      cout << "Line rejected " << endl;
    } */
    return (accept);
  }

  inline void setClippedPixel(int x, int y) {  // fct substitution draw direct dans le buffer
    LeBuffer[y * w_buf + x] = couleur;
  }

  inline void setPixel(int x, int y) {  // fct substitution draw direct dans le buffer
    if (x < x_min) return;
    if (x > x_max) return;
    if (y < y_min) return;
    if (y > y_max) return;
    LeBuffer[y * w_buf + x] = couleur;
  }

  inline void setPixel(int x, int y, uint8_t color) {
    setColor(color);
    setPixel(x, y);
  }

  void drawHLine(int x1, int x2, int y) {
    if (y < y_min) return;
    if (y > y_max) return;
    // y est valide reste a tester x
    if (x1 > x2) std::swap(x1, x2);
    if (x2 < x_min) return;
    if (x1 > x_max) return;
    x1 = max(x_min, x1);
    x2 = min(x_max, x2);

    uint8_t *Ptr = &LeBuffer[y * w_buf + x1];
    for (; x1 <= x2; x1++) *Ptr++ = couleur;  // setPixel(x1, y);
  }

  void drawHLine(int x1, int x2, int y, uint8_t color) {
    setColor(color);
    drawHLine(x1, x2, y);
  }

  void pushToWindow(int x1, int y1) {
    // LeBuffer = reinterpret_cast<uint8_t *>(Buf);
    // LaWindow = reinterpret_cast<uint8_t *>(Win);
    int maxx_y = std::min(std::max(h_buf - y1, 0), Taille_Fenetre_Y);
    int maxx_x = std::min(std::max(w_buf - x1, 0), Taille_Fenetre_X);
    Serial.printf("maxx %d maxy %d \n", maxx_x, maxx_y);
    uint8_t *Ptr_Dst = LaWindow;
    for (int y = 0; y < maxx_y; y++) {
      uint8_t *Ptr_Src = &LeBuffer[(y + y1) * w_buf + x1];
      // printf("%d %d %d\n", y, Ptr_Src, Ptr_Dst);
      for (int x = 0; x < maxx_x; x++) {
        *Ptr_Dst++ = *Ptr_Src++;
        // printf("%d ", Ptr_Src);
      }
      Ptr_Dst += Taille_Fenetre_X - maxx_x;
    }
  }

  void drawVLine(int x, int y1, int y2) {
    if (x < x_min) return;
    if (x > x_max) return;
    // y est valide reste a tester x
    if (y1 > y2) std::swap(y1, y2);
    if (y2 < y_min) return;
    if (y1 > y_max) return;
    y1 = max(y_min, y1);
    y2 = min(y_max, y2);

    uint8_t *Ptr = &LeBuffer[y1 * w_buf + x];
    for (; y1 <= y2; y1++) {
      *Ptr = couleur;  // setPixel(x1, y);
      Ptr += w_buf;
    }
  }

  void drawVLine(int x, int y1, int y2, uint8_t color) {
    setColor(color);
    drawVLine(x, y1, y2);
  }

  inline void drawClippedLine(int x0, int y0, int x1, int y1) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2; /* error value e_xy */

    for (;;) { /* loop */
               // setPixel(x0, y0);
      LeBuffer[y0 * w_buf + x0] = couleur;
      e2 = 2 * err;
      if (e2 >= dy) { /* e_xy+e_x > 0 */
        if (x0 == x1) break;
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) { /* e_xy+e_y < 0 */
        if (y0 == y1) break;
        err += dx;
        y0 += sy;
      }
    }
  }

  void drawLine(int x0, int y0, int x1, int y1) {

    CLIP clip_area = { x0, y0, x1, y1 };
    //cout << "Line sended   :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
    if (cohenSutherlandClip(clip_area)) {
      //cout << "Line received :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
      x0 = clip_area.x1, y0 = clip_area.y1, x1 = clip_area.x2, y1 = clip_area.y2;
      //cout << "Line returned :  " << aXStart << ", " << aYStart << " to " << aXEnd << ", " << aYEnd << endl;
      drawClippedLine(x0, y0, x1, y1);
    }
  }

  void drawLine(int x0, int y0, int x1, int y1, uint8_t color) {
    setColor(color);
    drawLine(x0, y0, x1, y1);
  }

  void drawTriangle(int x0, int y0, int x1, int y1, int x2, int y2) {
    drawLine(x0, y0, x1, y1);
    drawLine(x1, y1, x2, y2);
    drawLine(x2, y2, x0, y0);
  }

  void drawRect(int x, int y, int w, int h) {
    int x0, y0, x1, y1;

    x0 = max(x, x_min);
    x1 = min(x + w - 1, x_max);
    y0 = max(y, y_min);
    y1 = min(y + h - 1, y_max);

    ESP_LOGW("Rect", " x %d y %d w %d h %d x0 %d y0 %d x1 %d y1 %d", x, y, w, h, x0, y0, x1, y1);

    uint8_t *Ptr = &LeBuffer[y0 * w_buf + x0];
    for (int i = x0; i <= x1; i++) *Ptr++ = couleur;
    Ptr = &LeBuffer[y1 * w_buf + x0];
    for (int i = x0; i <= x1; i++) *Ptr++ = couleur;

    for (int i = y0; i <= y1; i++) LeBuffer[i * w_buf + x0] = couleur;
    for (int i = y0; i <= y1; i++) LeBuffer[i * w_buf + x1] = couleur;
  }

  void drawRect(int x, int y, int w, int h, uint8_t color) {
    couleur = color;
    drawRect(x, y, w, h);
  }

  void drawRectDA(int x0, int y0, int x1, int y1) {
    if (x0 < x1) std::swap(x0, x1);
    if (y0 < y1) std::swap(y0, y1);

    if (x0 < x_min) x0 = x_min;
    if (x1 > x_max) x1 = x_max;
    if (y0 < y_min) y0 = y_min;
    if (y1 > y_max) y1 = y_max;

    uint8_t *Ptr = &LeBuffer[y0 * w_buf + x0];
    for (int i = x0; i <= x1; i++) *Ptr++ = couleur;
    Ptr = &LeBuffer[y1 * w_buf + x0];
    for (int i = x0; i <= x1; i++) *Ptr++ = couleur;

    for (int i = y0; i <= y1; i++) LeBuffer[i * w_buf + x0] = couleur;
    for (int i = y0; i <= y1; i++) LeBuffer[i * w_buf + x1] = couleur;
  }

  void drawRectDA(int x0, int y0, int x1, int y1, uint8_t color) {
    couleur = color;
    drawRect(x0, y0, x1, y1);
  }

  void drawFilledRect(int x, int y, int w, int h) {
    int x0, y0, x1, y1;

    x0 = max(x, x_min);
    x1 = min(x + w - 1, x_max);
    y0 = max(y, y_min);
    y1 = min(y + h - 1, y_max);

    ESP_LOGW("FillRect", " x %d y %d w %d h %d x0 %d y0 %d x1 %d y1 %d", x, y, w, h, x0, y0, x1, y1);

    uint8_t *Ptr;
    for (int i = y0; i <= y1; i++) {
      Ptr = &LeBuffer[i * w_buf + x0];
      for (int j = x0; j <= x1; j++) *Ptr++ = couleur;
    }
  }
  void drawFilledRect(int x, int y, int w, int h, uint8_t color) {
    couleur = color;
    drawFilledRect(x, y, w, h);
  }
  ////////////////////////////////////////////
  void drawFilledTriangle(int px0, int py0, int px1, int py1, int px2, int py2) {

    if (py0 > py1) {
      std::swap(px0, px1);
      std::swap(py0, py1);
    }
    if (py1 > py2) {
      std::swap(px1, px2);
      std::swap(py1, py2);
    }
    if (py0 > py1) {
      std::swap(px0, px1);
      std::swap(py0, py1);
    }
    if (py0 == py1 && px0 > px1) std::swap(px0, px1);
    if (py1 == py2 && px1 > px2) std::swap(px1, px2);

    float slope1 = ((float)(px1 - px0) / (py1 - py0));
    float slope2 = ((float)(px2 - px1) / (py2 - py1));
    float slope3 = ((float)(px2 - px0) / (py2 - py0));

    float x1;
    float x2;
    if (py0 == py1) {
      // printf("p0 %d p1 %d p2 %d\n",  px0, px1, px2);

      x1 = px0;
      x2 = px1;
      // color = 'T'; Top line

      for (int y = py0; y < py2; y++) {
        drawHLine(x1, x2, y);
        x1 += slope3;
        x2 += slope2;
      }

    } else if (py1 == py2) {
      // printf("p0 %d p1 %d p2 %d\n",  px0, px1, px2);

      x1 = px0;
      x2 = px0;
      // color = 'B';  Bottom Line

      for (int y = py0; y < py2; y++) {
        drawHLine(x1, x2, y);
        x1 += slope3;
        x2 += slope1;
      }

    } else {

      x1 = px0;
      x2 = px0;
      // color = '+';  top line

      for (int y = py0; y < py1; y++) {
        drawHLine(x1, x2, y);
        x1 += slope3;
        x2 += slope1;
      }

      // color = '-'; bottom lin
      for (int y = py1; y < py2; y++) {
        drawHLine(x1, x2, y);
        x1 += slope3;
        x2 += slope2;
      }
    }
    // setColor(couleur + 20);
    // drawTriangle(px0, py0, px1, py1, px2, py2);

    //setPixel(ySwap.p[0].x,  py0, '7');
    //setPixel(px1,  py1, '8');
    //setPixel(px2,  py2, '9');
  }

  void drawFilledTriangle(int px0, int py0, int px1, int py1, int px2, int py2, uint8_t color) {
    couleur = color;
    drawFilledTriangle(px0, py0, px1, py1, px2, py2);
  }

  ////////////////////////////////////////////

  void draw_polygon(POLYCORNER TabPolyCorners[], uint16_t polyCorners, uint8_t color) {
    couleur = color;

    //  Loop through the rows of the image.
    int16_t nodes, nodeX[MAX_POLY_CORNERS], pixelX, pixelY, i, j, swap;
    for (pixelY = y_min; pixelY < y_max; pixelY++) {
      // Serial.printf("pixelY %d \n", pixelY);
      //  Build a list of nodes.
      nodes = 0;
      j = polyCorners - 1;

      for (i = 0; i < polyCorners; i++) {
        // Serial.printf("poly i %d nodes %d x %d y %d\n", i, nodes,TabPolyCorners[i].x,TabPolyCorners[i].y);
        if (TabPolyCorners[i].y < (float)pixelY && TabPolyCorners[j].y >= (float)pixelY || TabPolyCorners[j].y < (float)pixelY && TabPolyCorners[i].y >= (float)pixelY) {
          nodeX[nodes++] = (int)(TabPolyCorners[i].x + (pixelY - TabPolyCorners[i].y) / (float)(TabPolyCorners[j].y - TabPolyCorners[i].y) * (TabPolyCorners[j].x - TabPolyCorners[i].x));
        }
        j = i;
      }

      //  Sort the nodes, via a simple “Bubble” sort.
      i = 0;
      while (i < nodes - 1) {
        if (nodeX[i] > nodeX[i + 1]) {
          swap = nodeX[i];
          nodeX[i] = nodeX[i + 1];
          nodeX[i + 1] = swap;
          if (i) i--;
        } else {
          i++;
        }
      }

      //  Fill the pixels between node pairs.
      for (i = 0; i < nodes; i += 2) {
        if (nodeX[i] >= x_max) break;
        if (nodeX[i + 1] > x_min) {
          if (nodeX[i] < x_min) nodeX[i] = x_min;
          if (nodeX[i + 1] > x_max) nodeX[i + 1] = x_max;
          // Serial.printf("poly %d %d \n", nodeX[i], pixelY);
          uint8_t *Ptr = &LeBuffer[pixelY * w_buf + nodeX[i]];
          for (pixelX = nodeX[i]; pixelX < nodeX[i + 1]; pixelX++) *Ptr++ = couleur;
        }
      }
    }
  }

  void draw_polygon_zone(POLYCORNER TabPolyCorners[], uint16_t polyCorners, int16_t bb_top, int16_t bb_botom, int16_t bb_left, int16_t bb_right, uint8_t color) {
    couleur = color;

    //  Loop through the rows of the image.
    int16_t nodes, nodeX[MAX_POLY_CORNERS], pixelX, pixelY, i, j, swap;
    for (pixelY = bb_top; pixelY < bb_botom; pixelY++) {

      //  Build a list of nodes.
      nodes = 0;
      j = polyCorners - 1;

      for (i = 0; i < polyCorners; i++) {
        if (TabPolyCorners[i].y < (double)pixelY && TabPolyCorners[j].y >= (double)pixelY || TabPolyCorners[j].y < (double)pixelY && TabPolyCorners[i].y >= (double)pixelY) {
          nodeX[nodes++] = (int)(TabPolyCorners[i].x + (pixelY - TabPolyCorners[i].y) / (double)(TabPolyCorners[j].y - TabPolyCorners[i].y) * (TabPolyCorners[j].x - TabPolyCorners[i].x));
        }
        j = i;
      }

      //  Sort the nodes, via a simple “Bubble” sort.
      i = 0;
      while (i < nodes - 1) {
        if (nodeX[i] > nodeX[i + 1]) {
          std::swap(nodeX[i], nodeX[i + 1]);
          if (i) i--;
        } else {
          i++;
        }
      }

      //  Fill the pixels between node pairs.
      for (i = 0; i < nodes; i += 2) {
        if (nodeX[i] >= bb_right) break;
        if (nodeX[i + 1] > bb_left) {
          if (nodeX[i] < bb_left) nodeX[i] = bb_left;
          if (nodeX[i + 1] > bb_right) nodeX[i + 1] = bb_right;
          uint8_t *Ptr = &LeBuffer[pixelY * w_buf + nodeX[i]];
          for (pixelX = nodeX[i]; pixelX < nodeX[i + 1]; pixelX++) *Ptr++ = couleur;
        }
      }
    }
  }

  // cette methode est plus rapide que la V0 source je ne sais plus d'ou viens la source
  void drawRoadSegment(int x0, int y0, int x1, int y1, uint8_t couleur_externe, uint8_t couleur_interne, float offsetPixels, int_fast8_t mode) {

    offsetPixels = offsetPixels / 2;

    float L = std::sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1));

    // float offsetPixels = 2.0;

    // This is the second line
    int x1p = round(x0 + offsetPixels * (y1 - y0) / L);
    int x2p = round(x1 + offsetPixels * (y1 - y0) / L);
    int y1p = round(y0 + offsetPixels * (x0 - x1) / L);
    int y2p = round(y1 + offsetPixels * (x0 - x1) / L);

    int x3p = round(x0 - offsetPixels * (y1 - y0) / L);
    int x4p = round(x1 - offsetPixels * (y1 - y0) / L);
    int y3p = round(y0 - offsetPixels * (x0 - x1) / L);
    int y4p = round(y1 - offsetPixels * (x0 - x1) / L);

    if (mode != BORDER) {  // valide pour ROAD et THICK
      couleur = couleur_interne;
      drawFilledTriangle(x1p, y1p, x2p, y2p, x3p, y3p, couleur_interne);
      drawFilledTriangle(x2p, y2p, x3p, y3p, x4p, y4p, couleur_interne);
    }
    if (mode != THICK) {  // valide pour ROAD et BORDER
      couleur_bord = couleur_externe;
      drawLine(x1p, y1p, x2p, y2p);
      drawLine(x3p, y3p, x4p, y4p);
    }
  }

  void drawRoadSegment_V0(int x1, int y1, int x2, int y2, uint8_t couleur_externe, uint8_t couleur_interne, float thickness, int_fast8_t mode) {

    thickness = thickness / 2;

    float angle = atan2(y2 - y1, x2 - x1);
    int_fast16_t bx1 = round(x1 + thickness * cos(angle + PI / 2));
    int_fast16_t by1 = round(y1 + thickness * sin(angle + PI / 2));
    int_fast16_t bx2 = round(x2 + thickness * cos(angle + PI / 2));
    int_fast16_t by2 = round(y2 + thickness * sin(angle + PI / 2));
    int_fast16_t bx3 = round(x2 + thickness * cos(angle - PI / 2));
    int_fast16_t by3 = round(y2 + thickness * sin(angle - PI / 2));
    int_fast16_t bx4 = round(x1 + thickness * cos(angle - PI / 2));
    int_fast16_t by4 = round(y1 + thickness * sin(angle - PI / 2));

    if (mode != BORDER) {  // valide pour ROAD et THICK
      couleur = couleur_interne;
      drawFilledTriangle(bx1, by1, bx2, by2, bx3, by3, couleur_interne);
      drawFilledTriangle(bx1, by1, bx4, by4, bx3, by3, couleur_interne);
    }
    if (mode != THICK) {  // valide pour ROAD et BORDER
      couleur_bord = couleur_externe;
      drawLine(bx1, by1, bx2, by2);
      drawLine(bx3, by3, bx4, by4);
    }
  }


  void drawRoadSegmentB(int x1, int y1, int x2, int y2, uint8_t couleur_externe, uint8_t couleur_interne, float thickness, int_fast8_t mode) {

    thickness = thickness / 2;

    float angle = atan2(y2 - y1, x2 - x1);
    int_fast16_t bx1 = round(x1 + thickness * cos(angle + PI / 2));
    int_fast16_t by1 = round(y1 + thickness * sin(angle + PI / 2));
    int_fast16_t bx2 = round(x2 + thickness * cos(angle + PI / 2));
    int_fast16_t by2 = round(y2 + thickness * sin(angle + PI / 2));
    int_fast16_t bx3 = round(x2 + thickness * cos(angle - PI / 2));
    int_fast16_t by3 = round(y2 + thickness * sin(angle - PI / 2));
    int_fast16_t bx4 = round(x1 + thickness * cos(angle - PI / 2));
    int_fast16_t by4 = round(y1 + thickness * sin(angle - PI / 2));

    if (mode != BORDER) {  // valide pour ROAD et THICK
      setColor(couleur_interne);
      // drawFilledTriangle(bx1, by1, bx2, by2, bx3, by3, couleur_interne);
      // drawFilledTriangle(bx1, by1, bx4, by4, bx3, by3, couleur_interne);
      drawThickLine(x1, y1, x2, y2, thickness, LINE_THICKNESS_MIDDLE, 128);
    }
    if (mode != THICK) {  // valide pour ROAD et BORDER
      setColor(couleur_externe);
      drawLine(bx1, by1, bx2, by2);
      drawLine(bx3, by3, bx4, by4);
    }
  }


  // http://members.chello.at/easyfilter/bresenham.html ATT: different pour DrawLineAA les autres pas verifié
  // Base de la modif plotDashedLine et plotDashedLineWidth




  // C++ program to draw a circle without
  // floating point arithmetic
  // https://www.geeksforgeeks.org/draw-circle-without-floating-point-arithmetic-unpublished/
  void drawCircle(int r) {
    // Consider a rectangle of size N*N
    int N = 2 * r + 1;

    int x, y;  // Coordinates inside the rectangle

    // Draw a square of size N*N.
    for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) {
        // Start from the left most corner point
        x = i - r;
        y = j - r;

        // If this point is inside the circle, print it
        if (x * x + y * y <= r * r + 1)
          printf(".");
        else  // If outside the circle, print space
          printf(" ");
        printf(" ");
      }
      printf("\n");
    }
  }
  // http://www.cpp-home.com/archives/256.html
  void spiral(int rx, int ry) {
    int x, y;
    double d;  //detail
    double r;
    const double pi = 3.14159265;                         //more or less
    for (d = 0, r = 0; d <= 8 * pi; d += 0.01, r += 0.1)  //you can play with the value to be added to d
    {
      x = rx + sin(d) * r;
      y = ry + sin(d + (pi / 2)) * r;
      setPixel(x, y);
    }
  }

  void spiral2(int rx, int ry) {
    int x, y, p = rx, q = ry;
    double d;                            //detail
    double r(10);                        //this alters the distance between different tracks of spiral
    const double pi = 3.14159265;        //more or less
    for (d = 0; d <= 8 * pi; d += 0.01)  //you can play with the value to be added to d
    {
      x = rx + (sin(d) * d) * r;
      y = ry + (sin(d + (pi / 2)) * (d + (pi / 2))) * r;  // ajout d'un parentese ???
      drawLine(x, y, p, q);
      p = x;
      q = y;
    }
  }

  void drawDashedLine(int x0, int y0, int x1, int y1, int color, const uint_fast8_t line_type[]) {

    couleur = color;
    CLIP clip_area = { x0, y0, x1, y1 };
    //cout << "Line sended   :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
    if (cohenSutherlandClip(clip_area)) {
      //cout << "Line received :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
      x0 = clip_area.x1, y0 = clip_area.y1, x1 = clip_area.x2, y1 = clip_area.y2;
      //cout << "Line returned :  " << aXStart << ", " << aYStart << " to " << aXEnd << ", " << aYEnd << endl;

      int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
      int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
      int err = dx + dy, e2; /* error value e_xy */
      int count = 1;
      for (;;) { /* loop */
        // lcd.drawPixel(x0, y0, color);

        if (line_type[(count % line_type[0]) + 1]) LeBuffer[y0 * w_buf + x0] = color;
        count++;

        e2 = 2 * err;
        if (e2 >= dy) { /* e_xy+e_x > 0 */
          if (x0 == x1) break;
          err += dy;
          x0 += sx;
        }
        if (e2 <= dx) { /* e_xy+e_y < 0 */
          if (y0 == y1) break;
          err += dx;
          y0 += sy;
        }
      }
    }
  }

  void plotDashedLineWidth(int x0, int y0, int x1, int y1, int color, const uint_fast8_t line_type[], float offsetPixels) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2; /* error value e_xy */
    int count = 1;
    bool pixel_on = false;
    int xw1, yw1, xw2, yw2;
    bool to_draw = false;
    float L = std::sqrt((x0 - x1) * (x0 - x1) + (y0 - y1) * (y0 - y1));

    offsetPixels = offsetPixels / 2;

    for (;;) { /* loop */
      // lcd.drawPixel(x0, y0, color);

      pixel_on = line_type[(count % line_type[0]) + 1];
      count++;

      if (pixel_on) {
        xw2 = x0;
        yw2 = y0;
        if (!to_draw) {
          xw1 = x0;
          yw1 = y0;
          to_draw = true;
        }
      }

      //  drawThickLine(x1, y1, x2, y2, thickness, LINE_THICKNESS_DRAW_CLOCKWISE, couleur_interne);
      if ((to_draw) && (!pixel_on)) {
        int x1p = round(x0 + offsetPixels * (y1 - y0) / L);
        int x2p = round(x1 + offsetPixels * (y1 - y0) / L);
        int y1p = round(y0 + offsetPixels * (x0 - x1) / L);
        int y2p = round(y1 + offsetPixels * (x0 - x1) / L);

        int x3p = round(x0 - offsetPixels * (y1 - y0) / L);
        int x4p = round(x1 - offsetPixels * (y1 - y0) / L);
        int y3p = round(y0 - offsetPixels * (x0 - x1) / L);
        int y4p = round(y1 - offsetPixels * (x0 - x1) / L);
        // Serial.printf("V3 %d %d %d %d %d %d %d %d\n", bx1, by1, bx2, by2, bx3, by3, bx4, by4);
        couleur = color;
        drawFilledTriangle(x1p, y1p, x2p, y2p, x3p, y3p);
        drawFilledTriangle(x2p, y2p, x3p, y3p, x4p, y4p);
        to_draw = false;
      }

      e2 = 2 * err;
      if (e2 >= dy) { /* e_xy+e_x > 0 */
        if (x0 == x1) break;
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) { /* e_xy+e_y < 0 */
        if (y0 == y1) break;
        err += dx;
        y0 += sy;
      }
    }

    //  drawThickLine(x1, y1, x2, y2, thickness, LINE_THICKNESS_DRAW_CLOCKWISE, couleur_interne);
    if (to_draw) {

      int x1p = round(x0 + offsetPixels * (y1 - y0) / L);
      int x2p = round(x1 + offsetPixels * (y1 - y0) / L);
      int y1p = round(y0 + offsetPixels * (x0 - x1) / L);
      int y2p = round(y1 + offsetPixels * (x0 - x1) / L);

      int x3p = round(x0 - offsetPixels * (y1 - y0) / L);
      int x4p = round(x1 - offsetPixels * (y1 - y0) / L);
      int y3p = round(y0 - offsetPixels * (x0 - x1) / L);
      int y4p = round(y1 - offsetPixels * (x0 - x1) / L);
      drawFilledTriangle(x1p, y1p, x2p, y2p, x3p, y3p);
      drawFilledTriangle(x2p, y2p, x3p, y3p, x4p, y4p);
      to_draw = false;
    }
  }


  struct COORDDASH {
    int_fast16_t x0, y0, x1, y1;
  };

  void drawDashedLineB(int dx0, int dy0, int dx1, int dy1, int color, const uint_fast8_t line_type[], float thickness) {
    COORDDASH CoordDash[10];
    int n_dash = 0;

    float angle = atan2(dy1 - dy0, dx1 - dx0);

    n_dash = 1;
    CoordDash[0].x0 = dx0;
    CoordDash[0].y0 = dy0;
    CoordDash[0].x1 = dx1;
    CoordDash[0].y1 = dy1;
    if (thickness == 1) {
      // thickness = 0.9;
      n_dash = 3;
      CoordDash[1].x0 = round(dx0 + thickness * cos(angle + PI / 2));
      CoordDash[1].y0 = round(dy0 + thickness * sin(angle + PI / 2));
      CoordDash[1].x1 = round(dx1 + thickness * cos(angle + PI / 2));
      CoordDash[1].y1 = round(dy1 + thickness * sin(angle + PI / 2));
      CoordDash[2].x0 = round(dx0 + thickness * cos(angle - PI / 2));
      CoordDash[2].y0 = round(dy0 + thickness * sin(angle - PI / 2));
      CoordDash[2].x1 = round(dx1 + thickness * cos(angle - PI / 2));
      CoordDash[2].y1 = round(dy1 + thickness * sin(angle - PI / 2));
    }
    if (thickness == 1.5) {
      int_fast16_t bx0 = round(dx0 + thickness * cos(angle + PI / 2));
      int_fast16_t by0 = round(dy0 + thickness * sin(angle + PI / 2));
      int_fast16_t bx1 = round(dx1 + thickness * cos(angle + PI / 2));
      int_fast16_t by1 = round(dy1 + thickness * sin(angle + PI / 2));
      int_fast16_t bx00 = round(dx0 + thickness * cos(angle - PI / 2));
      int_fast16_t by00 = round(dy0 + thickness * sin(angle - PI / 2));
      int_fast16_t bx01 = round(dx1 + thickness * cos(angle - PI / 2));
      int_fast16_t by01 = round(dy1 + thickness * sin(angle - PI / 2));

      // calculate dx & dy
      int dx = bx00 - bx0;
      int dy = by00 - by0;

      // calculate steps required for generating pixels
      int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy);
      n_dash = steps + 1;
      // calculate increment in x & y for each steps
      float Xinc = dx / (float)steps;
      float Yinc = dy / (float)steps;

      // Put pixel for each step
      float X = bx0;
      float Y = by0;
      float XX = bx1;
      float YY = by1;
      Serial.printf("step %d\n", steps);
      for (int i = 0; i <= steps; i++) {
        Serial.printf("putpixel x %f   y %f \n", round(X), round(Y));
        // putpixel(round(X), round(Y), RED);  // put pixel at (X,Y)
        X += Xinc;   // increment in x at each step
        Y += Yinc;   // increment in y at each step
        XX += Xinc;  // increment in x at each step
        YY += Yinc;  // increment in y at each step

        CoordDash[i].x0 = X;
        CoordDash[i].y0 = Y;
        CoordDash[i].x1 = XX;
        CoordDash[i].y1 = YY;
        // delay(100);                         // for visualization of line-
        // generation step by step
      }
      CoordDash[n_dash].x0 = CoordDash[0].x0;
      CoordDash[n_dash].y0 = CoordDash[0].y0;
      CoordDash[n_dash].x1 = CoordDash[n_dash - 1].x1;
      CoordDash[n_dash].y1 = CoordDash[n_dash - 1].y1;
      n_dash++;
    }


    for (int width = 0; width < n_dash; width++) {
      int_fast16_t x0 = CoordDash[width].x0;
      int_fast16_t y0 = CoordDash[width].y0;
      int_fast16_t x1 = CoordDash[width].x1;
      int_fast16_t y1 = CoordDash[width].y1;

      Serial.printf("thickLine %d %d %d %d\n", x0, y0, x1, y1);

      int code1 = computeCode(x0, y0);
      int code2 = computeCode(x1, y1);

      // Initialize line as outside the rectangular window
      bool accept = false;

      while (true) {
        if ((code1 == 0) && (code2 == 0)) {
          accept = true;
          break;
        } else if (code1 & code2) {
          break;
        } else {
          int code_out;
          float x, y;

          if (code1 != 0) code_out = code1;
          else code_out = code2;

          if (code_out & TOP) {
            // point is above the clip rectangle
            x = x0 + (x1 - x0) * (y_max - y0) / (y1 - y0);
            y = y_max;
          } else if (code_out & BOTTOM) {
            // point is below the rectangle
            x = x0 + (x1 - x0) * (y_min - y0) / (y1 - y0);
            y = y_min;
          } else if (code_out & RIGHT) {
            // point is to the right of rectangle
            y = y0 + (y1 - y0) * (x_max - x0) / (x1 - x0);
            x = x_max;
          } else if (code_out & LEFT) {
            // point is to the left of rectangle
            y = y0 + (y1 - y0) * (x_min - x0) / (x1 - x0);
            x = x_min;
          }

          if (code_out == code1) {
            x0 = x;
            y0 = y;
            code1 = computeCode(x0, y0);
          } else {
            x1 = x;
            y1 = y;
            code2 = computeCode(x1, y1);
          }
        }
      }
      if (accept) {
        int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
        int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
        int err = dx + dy, e2; /* error value e_xy */
        int count = 1;
        for (;;) { /* loop */
          // lcd.drawPixel(x0, y0, color);

          if (line_type[(count % line_type[0]) + 1]) LeBuffer[y0 * w_buf + x0] = color;
          count++;

          e2 = 2 * err;
          if (e2 >= dy) { /* e_xy+e_x > 0 */
            if (x0 == x1) break;
            err += dy;
            x0 += sx;
          }
          if (e2 <= dx) { /* e_xy+e_y < 0 */
            if (y0 == y1) break;
            err += dx;
            y0 += sy;
          }
        }
      }
    }
  }


  void drawDashedThickLine(int x0, int y0, int x1, int y1, int color, const uint_fast8_t line_type[], float thickness) {
    int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
    int err = dx + dy, e2; /* error value e_xy */
    int count = 1;
    bool pixel_on = false;
    int xw1, yw1, xw2, yw2;
    thickness = thickness / 2;
    bool to_draw = false;
    float angle = atan2(y1 - y0, x1 - x0);

    for (;;) { /* loop */
      // lcd.drawPixel(x0, y0, color);

      pixel_on = line_type[(count % line_type[0]) + 1];
      count++;

      if (pixel_on) {
        xw2 = x0;
        yw2 = y0;
        if (!to_draw) {
          xw1 = x0;
          yw1 = y0;
          to_draw = true;
        }
      }

      //  drawThickLine(x1, y1, x2, y2, thickness, LINE_THICKNESS_DRAW_CLOCKWISE, couleur_interne);
      if ((to_draw) && (!pixel_on)) {
        int_fast16_t bx1 = round(xw1 + thickness * cos(angle + PI / 2));
        int_fast16_t by1 = round(yw1 + thickness * sin(angle + PI / 2));
        int_fast16_t bx2 = round(xw2 + thickness * cos(angle + PI / 2));
        int_fast16_t by2 = round(yw2 + thickness * sin(angle + PI / 2));
        int_fast16_t bx3 = round(xw2 + thickness * cos(angle - PI / 2));
        int_fast16_t by3 = round(yw2 + thickness * sin(angle - PI / 2));
        int_fast16_t bx4 = round(xw1 + thickness * cos(angle - PI / 2));
        int_fast16_t by4 = round(yw1 + thickness * sin(angle - PI / 2));
        // Serial.printf("V3 %d %d %d %d %d %d %d %d\n", bx1, by1, bx2, by2, bx3, by3, bx4, by4);
        drawFilledTriangle(bx1, by1, bx2, by2, bx3, by3, color);
        drawFilledTriangle(bx1, by1, bx4, by4, bx3, by3, color);
        to_draw = false;
      }

      e2 = 2 * err;
      if (e2 >= dy) { /* e_xy+e_x > 0 */
        if (x0 == x1) break;
        err += dy;
        x0 += sx;
      }
      if (e2 <= dx) { /* e_xy+e_y < 0 */
        if (y0 == y1) break;
        err += dx;
        y0 += sy;
      }
    }

    //  drawThickLine(x1, y1, x2, y2, thickness, LINE_THICKNESS_DRAW_CLOCKWISE, couleur_interne);
    if (to_draw) {

      int_fast16_t bx1 = round(xw1 + thickness * cos(angle + PI / 2));
      int_fast16_t by1 = round(yw1 + thickness * sin(angle + PI / 2));
      int_fast16_t bx2 = round(xw2 + thickness * cos(angle + PI / 2));
      int_fast16_t by2 = round(yw2 + thickness * sin(angle + PI / 2));
      int_fast16_t bx3 = round(xw2 + thickness * cos(angle - PI / 2));
      int_fast16_t by3 = round(yw2 + thickness * sin(angle - PI / 2));
      int_fast16_t bx4 = round(xw1 + thickness * cos(angle - PI / 2));
      int_fast16_t by4 = round(yw1 + thickness * sin(angle - PI / 2));

      drawFilledTriangle(bx1, by1, bx2, by2, bx3, by3, color);
      drawFilledTriangle(bx1, by1, bx4, by4, bx3, by3, color);
      // to_draw = false;
    }
  }


  // https://www.geeksforgeeks.org/mid-point-line-generation-algorithm/
  // C++ program for Mid-point line generation

  // midPoint function for line generation
  void midPoint(int X1, int Y1, int X2, int Y2) {
    // calculate dx & dy

    int dx = X2 - X1;
    int dy = Y2 - Y1;

    if (dy <= dx) {
      // initial value of decision parameter d
      int d = dy - (dx / 2);
      int x = X1, y = Y1;

      // Plot initial given point
      // putpixel(x,y) can be used to print pixel
      // of line in graphics
      // cout << x << "," << y << "\n";
      LeBuffer[y * w_buf + x] = couleur;

      // iterate through value of X
      while (x < X2) {
        x++;

        // E or East is chosen
        if (d < 0)
          d = d + dy;

        // NE or North East is chosen
        else {
          d += (dy - dx);
          y++;
        }

        // Plot intermediate points
        // putpixel(x,y) is used to print pixel
        // of line in graphics
        // cout << x << "," << y << "\n";
        LeBuffer[y * w_buf + x] = couleur;
      }
    }

    else if (dx < dy) {
      // initial value of decision parameter d
      int d = dx - (dy / 2);
      int x = X1, y = Y1;

      // Plot initial given point
      // putpixel(x,y) can be used to print pixel
      // of line in graphics
      //cout << x << "," << y << "\n";
      LeBuffer[y * w_buf + x] = couleur;

      // iterate through value of X
      while (y < Y2) {
        y++;

        // E or East is chosen
        if (d < 0)
          d = d + dx;

        // NE or North East is chosen
        // NE or North East is chosen
        else {
          d += (dx - dy);
          x++;
        }

        // Plot intermediate points
        // putpixel(x,y) is used to print pixel
        // of line in graphics
        //cout << x << "," << y << "\n";
        LeBuffer[y * w_buf + x] = couleur;
      }
    }
  }

  // https://www.geeksforgeeks.org/dda-line-generation-algorithm-computer-graphics/
  // C++ program for DDA line generation

  // function for rounding off the pixels
  int round(float n) {
    if (n - (int)n < 0.5) return (int)n;
    return (int)(n + 1);
  }

  // Function for line generation
  void DDALine(int x0, int y0, int x1, int y1) {

    // Calculate dx and dy
    int dx = x1 - x0;
    int dy = y1 - y0;

    // calculate steps required for generating pixels
    int step = abs(dx) > abs(dy) ? abs(dx) : abs(dy);

    // Calculate x-increment and y-increment for each step
    float x_incr = (float)dx / step;
    float y_incr = (float)dy / step;

    // Take the initial points as x and y
    float x = x0;
    float y = y0;

    for (int i = 0; i < step; i++) {

      // putpixel(round(x), round(y), WHITE);
      LeBuffer[round(y) * w_buf + round(x)] = couleur;
      //cout << round(x) << " " << round(y) << "\n";
      x += x_incr;
      y += y_incr;
      // delay(10);
    }
  }

  // https://www.geeksforgeeks.org/bresenhams-line-generation-algorithm/
  // C++ program for Bresenham’s Line Generation
  // Assumptions :
  // 1) Line is drawn from left to right.
  // 2) x1 < x2 and y1 < y2
  // 3) Slope of the line is between 0 and 1.
  // We draw a line from lower left to upper
  // right.

  // function for line generation
  void bresenham(int x1, int y1, int x2, int y2) {
    int m_new = 2 * (y2 - y1);
    int slope_error_new = m_new - (x2 - x1);
    for (int x = x1, y = y1; x <= x2; x++) {
      cout << "(" << x << "," << y << ")\n";
      LeBuffer[y * w_buf + x] = couleur;

      // Add slope to increment angle formed
      slope_error_new += m_new;

      // Slope error reached limit, time to
      // increment y and update slope error.
      if (slope_error_new >= 0) {
        y++;
        slope_error_new -= 2 * (x2 - x1);
      }
    }
  }

  void plotEllipse(int xm, int ym, int a, int b) {
    int x = -a, y = 0;                                        /* II. quadrant from bottom left to top right */
    long e2 = (long)b * b, err = (long)x * (2 * e2 + x) + e2; /* error of 1.step */

    do {
      setPixel(xm - x, ym + y); /*   I. Quadrant */
      setPixel(xm + x, ym + y); /*  II. Quadrant */
      setPixel(xm + x, ym - y); /* III. Quadrant */
      setPixel(xm - x, ym - y); /*  IV. Quadrant */
      e2 = 2 * err;
      if (e2 >= (x * 2 + 1) * (long)b * b) /* e_xy+e_x > 0 */
        err += (++x * 2 + 1) * (long)b * b;
      if (e2 <= (y * 2 + 1) * (long)a * a) /* e_xy+e_y < 0 */
        err += (++y * 2 + 1) * (long)a * a;
    } while (x <= 0);

    while (y++ < b) {       /* too early stop of flat ellipses a=1, */
      setPixel(xm, ym + y); /* -> finish tip of ellipse */
      setPixel(xm, ym - y);
    }
  }

  void plotOptimizedEllipse(int xm, int ym, int a, int b) {
    long x = -a, y = 0;                      /* II. quadrant from bottom left to top right */
    long e2 = b, dx = (1 + 2 * x) * e2 * e2; /* error increment  */
    long dy = x * x, err = dx + dy;          /* error of 1.step */

    do {
      setPixel(xm - x, ym + y); /*   I. Quadrant */
      setPixel(xm + x, ym + y); /*  II. Quadrant */
      setPixel(xm + x, ym - y); /* III. Quadrant */
      setPixel(xm - x, ym - y); /*  IV. Quadrant */
      e2 = 2 * err;
      if (e2 >= dx) {
        x++;
        err += dx += 2 * (long)b * b;
      } /* x step */
      if (e2 <= dy) {
        y++;
        err += dy += 2 * (long)a * a;
      } /* y step */
    } while (x <= 0);

    while (y++ < b) {       /* too early stop for flat ellipses with a=1, */
      setPixel(xm, ym + y); /* -> finish tip of ellipse */
      setPixel(xm, ym - y);
    }
  }

  void plotCircle(int xm, int ym, int r) {
    int x = -r, y = 0, err = 2 - 2 * r; /* bottom left to top right */
    do {
      setPixel(xm - x, ym + y); /*   I. Quadrant +x +y */
      setPixel(xm - y, ym - x); /*  II. Quadrant -x +y */
      setPixel(xm + x, ym - y); /* III. Quadrant -x -y */
      setPixel(xm + y, ym + x); /*  IV. Quadrant +x -y */
      r = err;
      if (r <= y) err += ++y * 2 + 1; /* e_xy+e_y < 0 */
      if (r > x || err > y)           /* e_xy+e_x > 0 or no 2nd y-step */
        err += ++x * 2 + 1;           /* -> x-step now */
    } while (x < 0);
  }

  void plotEllipseRect(int x0, int y0, int x1, int y1) {          /* rectangular parameter enclosing the ellipse */
    long a = abs(x1 - x0), b = abs(y1 - y0), b1 = b & 1;          /* diameter */
    double dx = 4 * (1.0 - a) * b * b, dy = 4 * (b1 + 1) * a * a; /* error increment */
    double err = dx + dy + b1 * a * a, e2;                        /* error of 1.step */

    if (x0 > x1) {
      x0 = x1;
      x1 += a;
    }                     /* if called with swapped points */
    if (y0 > y1) y0 = y1; /* .. exchange them */
    y0 += (b + 1) / 2;
    y1 = y0 - b1; /* starting pixel */
    a = 8 * a * a;
    b1 = 8 * b * b;

    do {
      setPixel(x1, y0); /*   I. Quadrant */
      setPixel(x0, y0); /*  II. Quadrant */
      setPixel(x0, y1); /* III. Quadrant */
      setPixel(x1, y1); /*  IV. Quadrant */
      e2 = 2 * err;
      if (e2 <= dy) {
        y0++;
        y1--;
        err += dy += a;
      } /* y step */
      if (e2 >= dx || 2 * err > dy) {
        x0++;
        x1--;
        err += dx += b1;
      } /* x step */
    } while (x0 <= x1);

    while (y0 - y1 <= b) {  /* too early stop of flat ellipses a=1 */
      setPixel(x0 - 1, y0); /* -> finish tip of ellipse */
      setPixel(x1 + 1, y0++);
      setPixel(x0 - 1, y1);
      setPixel(x1 + 1, y1--);
    }
  }

  // https://rosettacode.org/wiki/Bitmap/Bresenham%27s_line_algorithm#C
  void Line(float x1, float y1, float x2, float y2) {
    // Bresenham's line algorithm
    const bool steep = (fabs(y2 - y1) > fabs(x2 - x1));
    if (steep) {
      std::swap(x1, y1);
      std::swap(x2, y2);
    }

    if (x1 > x2) {
      std::swap(x1, x2);
      std::swap(y1, y2);
    }

    const float dx = x2 - x1;
    const float dy = fabs(y2 - y1);

    float error = dx / 2.0f;
    const int ystep = (y1 < y2) ? 1 : -1;
    int y = (int)y1;

    const int maxX = (int)x2;

    for (int x = (int)x1; x <= maxX; x++) {
      if (steep) {
        setPixel(y, x);
      } else {
        setPixel(x, y);
      }

      error -= dy;
      if (error < 0) {
        y += ystep;
        error += dx;
      }
    }
  }


  /**
 * thickLine.hpp
 *
 *  @brief Draw a solid line with thickness using a modified Bresenhams algorithm.
 *
 *  Copyright (C) 2013-2022  Armin Joachimsmeyer
 *  armin.joachimsmeyer@gmail.com
 *
 *  This file is part of STMF3-Discovery-Demos https://github.com/ArminJo/STMF3-Discovery-Demos/blob/master/lib/graphics/src/thickLine.cpp.
 *                                             https://gist.github.com/ArminJo/8dc4e61847a693e99bdde919cc7005cc
 *
 *  STMF3-Discovery-Demos is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *  See the GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program. If not, see <http://www.gnu.org/licenses/gpl.html>.
 */

  // Orginal from

  /**
 * Draws a line from aXStart/aYStart to aXEnd/aYEnd including both ends
 * @param aOverlap One of LINE_OVERLAP_NONE, LINE_OVERLAP_MAJOR, LINE_OVERLAP_MINOR, LINE_OVERLAP_BOTH
 */
  void drawLineOverlap(int aXStart, int aYStart, int aXEnd, int aYEnd, uint8_t aOverlap) {
    int16_t tDeltaX, tDeltaY, tDeltaXTimes2, tDeltaYTimes2, tError, tStepX, tStepY;

    // horizontal or vertical line -> fillRect() is faster than drawLine()
    // fillRect(aXStart, aYStart, aXEnd, aYEnd, aColor);  // you can remove the check and this line if you have no fillRect() or drawLine() available.
    // mais pas si HLine et Vline
    if (aYStart == aYEnd) drawHLine(aXStart, aXEnd, aYStart);
    else if (aXStart == aXEnd) drawVLine(aXStart, aYStart, aYEnd);
    else {

      /*
     * Clip to display size
     */
      CLIP clip_area = { aXStart, aYStart, aXEnd, aYEnd };
      // cout << "Line sended   :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
      if (cohenSutherlandClip(clip_area)) {
        // cout << "Line received :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
        aXStart = clip_area.x1, aYStart = clip_area.y1, aXEnd = clip_area.x2, aYEnd = clip_area.y2;
        // cout << "Line returned :  " << aXStart << ", " << aYStart << " to " << aXEnd << ", " << aYEnd << endl;

        // calculate direction
        tDeltaX = aXEnd - aXStart;
        tDeltaY = aYEnd - aYStart;
        if (tDeltaX < 0) {
          tDeltaX = -tDeltaX;
          tStepX = -1;
        } else {
          tStepX = +1;
        }
        if (tDeltaY < 0) {
          tDeltaY = -tDeltaY;
          tStepY = -1;
        } else {
          tStepY = +1;
        }
        tDeltaXTimes2 = tDeltaX << 1;
        tDeltaYTimes2 = tDeltaY << 1;
        // draw start pixel
        // drawPixel(aXStart, aYStart, aColor);
        LeBuffer[aYStart * w_buf + aXStart] = couleur;
        if (tDeltaX > tDeltaY) {
          // start value represents a half step in Y direction
          tError = tDeltaYTimes2 - tDeltaX;
          while (aXStart != aXEnd) {
            // step in main direction
            aXStart += tStepX;
            if (tError >= 0) {
              if (aOverlap & LINE_OVERLAP_MAJOR) {
                // draw pixel in main direction before changing
                // drawPixel(aXStart, aYStart, aColor);
                LeBuffer[aYStart * w_buf + aXStart] = couleur;
              }
              // change Y
              aYStart += tStepY;
              if (aOverlap & LINE_OVERLAP_MINOR) {
                // draw pixel in minor direction before changing
                //drawPixel(aXStart - tStepX, aYStart, aColor);
                LeBuffer[aYStart * w_buf + aXStart - tStepX] = couleur;
              }
              tError -= tDeltaXTimes2;
            }
            tError += tDeltaYTimes2;
            // drawPixel(aXStart, aYStart, aColor);
            LeBuffer[aYStart * w_buf + aXStart] = couleur;
          }
        } else {
          tError = tDeltaXTimes2 - tDeltaY;
          while (aYStart != aYEnd) {
            aYStart += tStepY;
            if (tError >= 0) {
              if (aOverlap & LINE_OVERLAP_MAJOR) {
                // draw pixel in main direction before changing
                // drawPixel(aXStart, aYStart, aColor);
                LeBuffer[aYStart * w_buf + aXStart] = couleur;
              }
              aXStart += tStepX;
              if (aOverlap & LINE_OVERLAP_MINOR) {
                // draw pixel in minor direction before changing
                //drawPixel(aXStart, aYStart - tStepY, aColor);
                LeBuffer[(aYStart - tStepY) * w_buf + aXStart] = couleur;
              }
              tError -= tDeltaYTimes2;
            }
            tError += tDeltaXTimes2;
            // drawPixel(aXStart, aYStart, aColor);
            LeBuffer[aYStart * w_buf + aXStart] = couleur;
          }
        }
      }
    }
  }

  // https://github.com/ArminJo/Arduino-BlueDisplay/blob/master/src/LocalGUI/ThickLine.hpp
  /**
 * Bresenham with thickness
 * No pixel missed and every pixel only drawn once!
 * The code is bigger and more complicated than drawThickLineSimple() but it tends to be faster, since drawing a pixel is often a slow operation.
 * aThicknessMode can be one of LINE_THICKNESS_MIDDLE, LINE_THICKNESS_DRAW_CLOCKWISE, LINE_THICKNESS_DRAW_COUNTERCLOCKWISE
 */
  void drawThickLine(int aXStart, int aYStart, int aXEnd, int aYEnd, int aThickness, uint8_t aThicknessMode) {
    int16_t i, tDeltaX, tDeltaY, tDeltaXTimes2, tDeltaYTimes2, tError, tStepX, tStepY;

    if (aThickness <= 1) {
      drawLineOverlap(aXStart, aYStart, aXEnd, aYEnd, LINE_OVERLAP_NONE);
    }
    /*
     * Clip to display size
     */
    // original method is not working he cut the line without interpretation if horizontal or vertial ok but not in diagonal
    /* if (aXStart >= w_buf) {      aXStart = w_buf - 1;    }
    if (aXEnd >= w_buf) {      aXEnd = w_buf - 1;    }
    if (aYStart >= h_buf) {      aYStart = h_buf - 1;    }
    if (aYEnd >= h_buf) {      aYEnd = h_buf - 1;    } */
    CLIP clip_area = { aXStart, aYStart, aXEnd, aYEnd };
    //cout << "Line sended   :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
    if (cohenSutherlandClip(clip_area)) {
      //cout << "Line received :  " << clip_area.x1 << ", " << clip_area.y1 << " to " << clip_area.x2 << ", " << clip_area.y2 << endl;
      aXStart = clip_area.x1, aYStart = clip_area.y1, aXEnd = clip_area.x2, aYEnd = clip_area.y2;
      //cout << "Line returned :  " << aXStart << ", " << aYStart << " to " << aXEnd << ", " << aYEnd << endl;

      /**
     * For coordinate system with 0.0 top left
     * Swap X and Y delta and calculate clockwise (new delta X inverted)
     * or counterclockwise (new delta Y inverted) rectangular direction.
     * The right rectangular direction for LINE_OVERLAP_MAJOR toggles with each octant
     */
      tDeltaY = aXEnd - aXStart;
      tDeltaX = aYEnd - aYStart;
      // mirror 4 quadrants to one and adjust deltas and stepping direction
      bool tSwap = true;  // count effective mirroring
      if (tDeltaX < 0) {
        tDeltaX = -tDeltaX;
        tStepX = -1;
        tSwap = !tSwap;
      } else {
        tStepX = +1;
      }
      if (tDeltaY < 0) {
        tDeltaY = -tDeltaY;
        tStepY = -1;
        tSwap = !tSwap;
      } else {
        tStepY = +1;
      }
      tDeltaXTimes2 = tDeltaX << 1;
      tDeltaYTimes2 = tDeltaY << 1;
      bool tOverlap;
      // adjust for right direction of thickness from line origin
      int tDrawStartAdjustCount = aThickness / 2;
      if (aThicknessMode == LINE_THICKNESS_DRAW_COUNTERCLOCKWISE) {
        tDrawStartAdjustCount = aThickness - 1;
      } else if (aThicknessMode == LINE_THICKNESS_DRAW_CLOCKWISE) {
        tDrawStartAdjustCount = 0;
      }

      /*
     * Now tDelta* are positive and tStep* define the direction
     * tSwap is false if we mirrored only once
     */
      // which octant are we now
      if (tDeltaX >= tDeltaY) {
        // Octant 1, 3, 5, 7 (between 0 and 45, 90 and 135, ... degree)
        if (tSwap) {
          tDrawStartAdjustCount = (aThickness - 1) - tDrawStartAdjustCount;
          tStepY = -tStepY;
        } else {
          tStepX = -tStepX;
        }
        /*
         * Vector for draw direction of the starting points of lines is rectangular and counterclockwise to main line direction
         * Therefore no pixel will be missed if LINE_OVERLAP_MAJOR is used on change in minor rectangular direction
         */
        // adjust draw start point
        tError = tDeltaYTimes2 - tDeltaX;
        for (i = tDrawStartAdjustCount; i > 0; i--) {
          // change X (main direction here)
          aXStart -= tStepX;
          aXEnd -= tStepX;
          if (tError >= 0) {
            // change Y
            aYStart -= tStepY;
            aYEnd -= tStepY;
            tError -= tDeltaXTimes2;
          }
          tError += tDeltaYTimes2;
        }
        // draw start line. We can alternatively use drawLineOverlap(aXStart, aYStart, aXEnd, aYEnd, LINE_OVERLAP_NONE, aColor) here.
        //drawLine(aXStart, aYStart, aXEnd, aYEnd, aColor);
        drawClippedLine(aXStart, aYStart, aXEnd, aYEnd);
        // draw aThickness number of lines
        tError = tDeltaYTimes2 - tDeltaX;
        for (i = aThickness; i > 1; i--) {
          // change X (main direction here)
          aXStart += tStepX;
          aXEnd += tStepX;
          tOverlap = LINE_OVERLAP_NONE;
          if (tError >= 0) {
            // change Y
            aYStart += tStepY;
            aYEnd += tStepY;
            tError -= tDeltaXTimes2;
            /*
                 * Change minor direction reverse to line (main) direction
                 * because of choosing the right (counter)clockwise draw vector
                 * Use LINE_OVERLAP_MAJOR to fill all pixel
                 *
                 * EXAMPLE:
                 * 1,2 = Pixel of first 2 lines
                 * 3 = Pixel of third line in normal line mode
                 * - = Pixel which will additionally be drawn in LINE_OVERLAP_MAJOR mode
                 *           33
                 *       3333-22
                 *   3333-222211
                 * 33-22221111
                 *  221111                     /\
                 *  11                          Main direction of start of lines draw vector
                 *  -> Line main direction
                 *  <- Minor direction of counterclockwise of start of lines draw vector
                 */
            tOverlap = LINE_OVERLAP_MAJOR;
          }
          tError += tDeltaYTimes2;
          drawLineOverlap(aXStart, aYStart, aXEnd, aYEnd, tOverlap);
        }
      } else {
        // the other octant 2, 4, 6, 8 (between 45 and 90, 135 and 180, ... degree)
        if (tSwap) {
          tStepX = -tStepX;
        } else {
          tDrawStartAdjustCount = (aThickness - 1) - tDrawStartAdjustCount;
          tStepY = -tStepY;
        }
        // adjust draw start point
        tError = tDeltaXTimes2 - tDeltaY;
        for (i = tDrawStartAdjustCount; i > 0; i--) {
          aYStart -= tStepY;
          aYEnd -= tStepY;
          if (tError >= 0) {
            aXStart -= tStepX;
            aXEnd -= tStepX;
            tError -= tDeltaYTimes2;
          }
          tError += tDeltaXTimes2;
        }
        //draw start line
        // drawLine(aXStart, aYStart, aXEnd, aYEnd, aColor);
        drawClippedLine(aXStart, aYStart, aXEnd, aYEnd);
        // draw aThickness number of lines
        tError = tDeltaXTimes2 - tDeltaY;
        for (i = aThickness; i > 1; i--) {
          aYStart += tStepY;
          aYEnd += tStepY;
          tOverlap = LINE_OVERLAP_NONE;
          if (tError >= 0) {
            aXStart += tStepX;
            aXEnd += tStepX;
            tError -= tDeltaYTimes2;
            tOverlap = LINE_OVERLAP_MAJOR;
          }
          tError += tDeltaXTimes2;
          if ((i == aThickness) || (i == 2)) couleur_mem = couleur, couleur = couleur_bord;
          else couleur = couleur_mem;
          drawLineOverlap(aXStart, aYStart, aXEnd, aYEnd, tOverlap);
        }
      }
    }
  }
  void drawThickLine(int aXStart, int aYStart, int aXEnd, int aYEnd, int aThickness, uint8_t aThicknessMode, uint8_t aColor) {
    couleur = aColor;
    drawThickLine(aXStart, aYStart, aXEnd, aYEnd, aThickness, aThicknessMode);
  }
  void drawThickLine(int aXStart, int aYStart, int aXEnd, int aYEnd, int aThickness, uint8_t aThicknessMode, uint8_t aColor, uint8_t bColor) {
    couleur = aColor;
    couleur_bord = bColor;
    drawThickLine(aXStart, aYStart, aXEnd, aYEnd, aThickness, aThicknessMode);
  }

  //https :  //stackoverflow.com/questions/1201200/fast-algorithm-for-drawing-filled-circles
  // ok mais a voir avec le clipping
  void forcebrutecercle(int x0, int y0, int radius) {
    for (int y = -radius; y <= radius; y++)
      for (int x = -radius; x <= radius; x++)
        if (x * x + y * y <= radius * radius)
          setPixel(x0 + x, y0 + y);  // setpixel(origin.x+x, origin.y+y);
  }

  // https://stackoverflow.com/questions/1201200/fast-algorithm-for-drawing-filled-circles
  // Daniel Massicotte
  // this must be declared anywhere, as static or global
  // as long as the function can access it !

  // SOLUTION 1: (the fastest)

  void FillCircle_v1(uint16_t x, uint16_t y, uint16_t r) {
    // all needed variables are created and set to their value...
    uint16_t radius = (r < 1) ? 1 : r;
    if (radius > 21) { radius = 21; }
    uint16_t diam = (radius * 2) + 1;
    uint16_t ymir = 0, cur_y = 0;
    radius--;
    uint16_t target = (radius * radius + 3 * radius) / 2;
    radius++;
    // this part draws directly into the ILI94xx TFT buffer mem.
    // using pointers..2 versions where you can draw
    // pixels and lines with coordinates will follow
    for (uint16_t yy = 0; yy < diam; yy++) {
      ymir = (yy <= radius) ? yy + target : target + diam - (yy + 1);
      cur_y = y - radius + yy;
      uint8_t *pixel = LeBuffer + x - Rset[ymir] + cur_y * w_buf;
      for (uint16_t xx = 0; xx <= (2 * Rset[ymir]); xx++) { *pixel++ = couleur; }
    }
  }

  /*
Bitmap bmp = new Bitmap(200, 200);

int r = 50; // radius
int ox = 100, oy = 100; // origin

for (int x = -r; x < r ; x++)
{
    int height = (int)Math.Sqrt(r * r - x * x);

    for (int y = -height; y < height; y++)
        bmp.SetPixel(x + ox, y + oy, Color.Red);
}

bmp.Save(@"c:\users\dearwicker\Desktop\circle.bmp");

void DrawFilledCircle(int x0, int y0, int radius)
{
    int x = radius;
    int y = 0;
    int xChange = 1 - (radius << 1);
    int yChange = 0;
    int radiusError = 0;

    while (x >= y)
    {
        for (int i = x0 - x; i <= x0 + x; i++)
        {
            SetPixel(i, y0 + y);
            SetPixel(i, y0 - y);
        }
        for (int i = x0 - y; i <= x0 + y; i++)
        {
            SetPixel(i, y0 + x);
            SetPixel(i, y0 - x);
        }

        y++;
        radiusError += yChange;
        yChange += 2;
        if (((radiusError << 1) + xChange) > 0)
        {
            x--;
            radiusError += xChange;
            xChange += 2;
        }
    }
}

int r2 = r * r;
int area = r2 << 2;
int rr = r << 1;

for (int i = 0; i < area; i++)
{
    int tx = (i % rr) - r;
    int ty = (i / rr) - r;

    if (tx * tx + ty * ty <= r2)
        SetPixel(x + tx, y + ty, c);
}

            int r2 = r * r;
            for (int cy = -r; cy <= r; cy++)
            {
                int cx = (int)(Math.Sqrt(r2 - cy * cy) + 0.5);
                int cyy = cy + y;

                lineDDA(x - cx, cyy, x + cx, cyy, c);
            }

demi cercle  point 7
int largestX = circle.radius;
for (int y = 0; y <= radius; ++y) {
    for (int x = largestX; x >= 0; --x) {
        if ((x * x) + (y * y) <= (circle.radius * circle.radius)) {
            drawLine(circle.center.x - x, circle.center.x + x, circle.center.y + y);
            drawLine(circle.center.x - x, circle.center.x + x, circle.center.y - y);
            largestX = x;
            break; // go to next y coordinate
        }
    }
}

 */

  // https://stackoverflow.com/questions/1201200/fast-algorithm-for-drawing-filled-circles
  // Daniel Massicotte
  // this must be declared anywhere, as static or global
  // as long as the function can access it !
  /*
  uint8_t Rset[252] = {
    0, 1, 1, 2, 2, 1, 2, 3, 3, 1, 3, 3, 4, 4, 2, 3, 4, 5, 5, 5, 2, 4, 5, 5,
    6, 6, 6, 2, 4, 5, 6, 6, 7, 7, 7, 2, 4, 5, 6, 7, 7, 8, 8, 8, 2, 5, 6, 7,
    8, 8, 8, 9, 9, 9, 3, 5, 6, 7, 8, 9, 9, 10, 10, 10, 10, 3, 5, 7, 8, 9,
    9, 10, 10, 11, 11, 11, 11, 3, 5, 7, 8, 9, 10, 10, 11, 11, 12, 12,
    12, 12, 3, 6, 7, 9, 10, 10, 11, 12, 12, 12, 13, 13, 13, 13, 3, 6,
    8, 9, 10, 11, 12, 12, 13, 13, 13, 14, 14, 14, 14, 3, 6, 8, 9, 10,
    11, 12, 13, 13, 14, 14, 14, 15, 15, 15, 15, 3, 6, 8, 10, 11, 12,
    13, 13, 14, 14, 15, 15, 15, 16, 16, 16, 16, 4, 7, 8, 10, 11, 12,
    13, 14, 14, 15, 16, 16, 16, 17, 17, 17, 17, 17, 4, 7, 9, 10, 12,
    13, 14, 14, 15, 16, 16, 17, 17, 17, 18, 18, 18, 18, 18, 4, 7, 9,
    11, 12, 13, 14, 15, 16, 16, 17, 17, 18, 18, 18, 19, 19, 19, 19,
    19, 7, 9, 11, 12, 13, 15, 15, 16, 17, 18, 18, 19, 19, 20, 20, 20,
    20, 20, 20, 20, 20, 7, 9, 11, 12, 14, 15, 16, 17, 17, 18, 19, 19,
    20, 20, 21, 21, 21, 21, 21, 21, 21, 21
  };

  // SOLUTION 1: (the fastest)

  void FillCircle_v1(uint16_t x, uint16_t y, uint16_t r) {
    // all needed variables are created and set to their value...
    uint16_t radius = (r < 1) ? 1 : r;
    if (radius > 21) { radius = 21; }
    uint16_t diam = (radius * 2) + 1;
    uint16_t ymir = 0, cur_y = 0;
    radius--;
    uint16_t target = (radius * radius + 3 * radius) / 2;
    radius++;
    // this part draws directly into the ILI94xx TFT buffer mem.
    // using pointers..2 versions where you can draw
    // pixels and lines with coordinates will follow
    for (uint16_t yy = 0; yy < diam; yy++) {
      ymir = (yy <= radius) ? yy + target : target + diam - (yy + 1);
      cur_y = y - radius + yy;
      uint16_t *pixel = buffer_start_addr + x - Rset[ymir] + cur_y * buffer_width;
      for (uint16_t xx = 0; xx <= (2 * Rset[ymir]); xx++) { *pixel++ = CANVAS::draw_color; }
    }
  }

  // SOLUTION 2: adaptable to any system that can
  // add a pixel at a time: (drawpixel or add_pixel,etc_)

  void FillCircle_v2(uint16_t x, uint16_t y, uint16_t r) {
    // all needed variables are created and set to their value...
    uint16_t radius = (r < 1) ? 1 : r;
    if (radius > 21) { radius = 21; }
    uint16_t diam = (radius * 2) + 1;
    uint16_t ymir = 0, cur_y = 0;
    radius--;
    uint16_t target = (radius * radius + 3 * radius) / 2;
    radius++;
    for (uint16_t yy = 0; yy < diam; yy++) {
      ymir = (yy <= radius) ? yy + target : target + diam - (yy + 1);
      cur_y = y - radius + yy;
      uint16_t Pixel_x = x - Rset[ymir];
      for (uint16_t xx = 0; xx <= (2 * Rset[ymir]); xx++) {  //use your add_pixel or draw_pixel here
                                                             // using those coordinates:
                                                             // X position will be... (Pixel_x+xx)
                                                             // Y position will be... (cur_y)
                                                             // and add those 3 brackets at the end
      }
    }
  }

  // SOLUTION 3: adaptable to any system that can draw fast
  //                horizontal lines
  void FillCircle_v3(uint16_t x, uint16_t y, uint16_t r) {
    // all needed variables are created and set to their value...
    uint16_t radius = (r < 1) ? 1 : r;
    if (radius > 21) { radius = 21; }
    uint16_t diam = (radius * 2) + 1;
    uint16_t ymir = 0, cur_y = 0;
    radius--;
    uint16_t target = (radius * radius + 3 * radius) / 2;
    radius++;
    for (uint16_t yy = 0; yy < diam; yy++) {
      ymir = (yy <= radius) ? yy + target : target + diam - (yy + 1);
      cur_y = y - radius + yy;
      uint16_t start_x = x - Rset[ymir];
      uint16_t width_x = 2 * Rset[ymir];

      //  ... then use your best drawline function using those values:
      //  start_x:   position X of the start of the line
      //  cur_y:     position Y of the current line
      //  width_x:   length of the line
      //  if you need a 2nd coordinate then :end_x=start_x+width_x
      // and add those 2 brackets after !!!
    }
  }
  */
};

//