#ifndef __COMMUN_HPP__
#define __COMMUN_HPP__

#define READBUFFER
#define SDMMC
// #define TEST_TUILES

#define DICO_POLY 3   // polygone fermé
#define DICO_LINE 2   // des lignes
#define DICO_POINT 0  // rien
#define DICO_TEXT 1   // du texte

// pour rappel dans DICO
// Les elements affichée sont ceux qui sont inferieur ou egal au niveau demande
// Donc 1 element en VISU_BUIDING  ne sera affiché que si VIEW_BUILDING est demande + tot les niveau en dessous
// mais du coup beaucoup plus long es ce que le proc et l'affichage suit ????

enum {
  VIEW_LEVEL_NOTHING = 0,   //
  VIEW_LEVEL_LANDUSE = 1,   // Le decors de base sans certain element comme vinegard (vignoble) ...
  VIEW_LEVEL_ROAD = 2,      // Les routes
  VIEW_LEVEL_RAIL = 3,      // les voie de chemin de fer
  VIEW_LEVEL_BARRIER = 4,   //
  VIEW_LEVEL_LOISIR = 5,    //
  VIEW_LEVEL_TOURISM = 5,   //
  VIEW_LEVEL_RAILWAY = 6,   // gare
  VIEW_LEVEL_HISTORIC = 7,  // monument - religion
  VIEW_LEVEL_AMENITY = 7,   //  les magasin
  VIEW_LEVEL_SHOP = 7,      //  les magasin
  VIEW_LEVEL_BUILDING = 8,  // Les batiments
  VIEW_LEVEL_PRIVATE = 8,   //  chemin Privé
  VIEW_LEVEL_GREEN = 8,     //
  VIEW_LEVEL_ALL = 9        // Tout ne devrais pas etre utilise
};

enum { Maison,
       Balade,
       Bousole,
       Montre,
       Menu_GPX };

enum { LEMENU_LITTLEFS,
       LEMENU_SD };

enum { ETAT_RETOUR_OK = 1,
       ETAT_RETOUR_ANNUL,
       ETAT_RETOUR_SVG,
       ETAT_RETOUR_PARCOURS_VIDE,
       ETAT_RETOUR_LEAVE };

enum {
  LIT_SD,
  LIT_LFS
};

static const int32_t TAILLE_ICONE = 30;
static const int32_t TAILLE_MINI_ICONE = 20;
static const int32_t NOM_MAX_LITTLEFS = 30;
static const int32_t NBRE_ITEM_FICH = 30;
static const int32_t NBRE_ITEM_MNU_MAP = 3;

#include <QMC5883LCompass.h>

QMC5883LCompass compass;

#endif