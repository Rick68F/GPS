set -x 
ls -1 *.png | while read fic
do
echo "Fichier a traiter $fic"
# fic2=`echo $fic | rev | cut -f 2- -d '.' | rev`
#fic2=`echo $fic |cut -f1 -d '.'`
#ffmpeg -vcodec png -i "${fic}" -vcodec rawvideo -f rawvideo -pix_fmt rgb565 ${fic2}.raw
 
# /home/eric/Bureau/LangC/ficher2progmem 

done

